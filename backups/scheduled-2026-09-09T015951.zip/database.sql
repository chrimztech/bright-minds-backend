--
-- PostgreSQL database dump
--

\restrict pietQanvXflMzOBoeetumatoExUlN3UkjJ8LHIRy1bdJHqq7ciByXWGZLOTB9Ei

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transport_routes DROP CONSTRAINT IF EXISTS transport_routes_vehicle_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transport_pickup_points DROP CONSTRAINT IF EXISTS transport_pickup_points_route_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transport_assignments DROP CONSTRAINT IF EXISTS transport_assignments_route_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transport_assignments DROP CONSTRAINT IF EXISTS transport_assignments_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transport_assignments DROP CONSTRAINT IF EXISTS transport_assignments_pickup_point_id_fkey;
ALTER TABLE IF EXISTS ONLY public.timetable_slots DROP CONSTRAINT IF EXISTS timetable_slots_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.timetable_slots DROP CONSTRAINT IF EXISTS timetable_slots_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.timetable_slots DROP CONSTRAINT IF EXISTS timetable_slots_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.terms DROP CONSTRAINT IF EXISTS terms_academic_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_subjects DROP CONSTRAINT IF EXISTS teacher_subjects_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_subjects DROP CONSTRAINT IF EXISTS teacher_subjects_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_subjects DROP CONSTRAINT IF EXISTS teacher_subjects_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.report_card_remarks DROP CONSTRAINT IF EXISTS report_card_remarks_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.report_card_remarks DROP CONSTRAINT IF EXISTS report_card_remarks_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_order_items DROP CONSTRAINT IF EXISTS purchase_order_items_purchase_order_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_order_items DROP CONSTRAINT IF EXISTS purchase_order_items_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupils DROP CONSTRAINT IF EXISTS pupils_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_promotions DROP CONSTRAINT IF EXISTS pupil_promotions_to_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_promotions DROP CONSTRAINT IF EXISTS pupil_promotions_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_promotions DROP CONSTRAINT IF EXISTS pupil_promotions_promoted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_promotions DROP CONSTRAINT IF EXISTS pupil_promotions_from_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_promotions DROP CONSTRAINT IF EXISTS pupil_promotions_academic_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_enrollments DROP CONSTRAINT IF EXISTS pupil_enrollments_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_enrollments DROP CONSTRAINT IF EXISTS pupil_enrollments_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pupil_enrollments DROP CONSTRAINT IF EXISTS pupil_enrollments_academic_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ptc_sessions DROP CONSTRAINT IF EXISTS ptc_sessions_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ptc_meetings DROP CONSTRAINT IF EXISTS ptc_meetings_staff_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ptc_meetings DROP CONSTRAINT IF EXISTS ptc_meetings_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ptc_meetings DROP CONSTRAINT IF EXISTS ptc_meetings_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ptc_meetings DROP CONSTRAINT IF EXISTS ptc_meetings_guardian_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payslips DROP CONSTRAINT IF EXISTS payslips_staff_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payslips DROP CONSTRAINT IF EXISTS payslips_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_submitted_by_guardian_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_exam_id_fkey;
ALTER TABLE IF EXISTS ONLY public.library_loans DROP CONSTRAINT IF EXISTS library_loans_staff_id_fkey;
ALTER TABLE IF EXISTS ONLY public.library_loans DROP CONSTRAINT IF EXISTS library_loans_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.library_loans DROP CONSTRAINT IF EXISTS library_loans_book_id_fkey;
ALTER TABLE IF EXISTS ONLY public.leave_requests DROP CONSTRAINT IF EXISTS leave_requests_staff_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_fee_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.inventory_txns DROP CONSTRAINT IF EXISTS inventory_txns_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS inventory_items_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.homework DROP CONSTRAINT IF EXISTS homework_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.homework DROP CONSTRAINT IF EXISTS homework_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.health_records DROP CONSTRAINT IF EXISTS health_records_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.guardians DROP CONSTRAINT IF EXISTS guardians_user_id_fk;
ALTER TABLE IF EXISTS ONLY public.guardian_pupils DROP CONSTRAINT IF EXISTS guardian_pupils_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.guardian_pupils DROP CONSTRAINT IF EXISTS guardian_pupils_guardian_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_transactions DROP CONSTRAINT IF EXISTS gateway_transactions_payment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_transactions DROP CONSTRAINT IF EXISTS gateway_transactions_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_transactions DROP CONSTRAINT IF EXISTS gateway_transactions_guardian_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fee_items DROP CONSTRAINT IF EXISTS fee_items_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fee_items DROP CONSTRAINT IF EXISTS fee_items_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.exams DROP CONSTRAINT IF EXISTS exams_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_staff_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.discipline_records DROP CONSTRAINT IF EXISTS discipline_records_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_class_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.canteen_subscriptions DROP CONSTRAINT IF EXISTS canteen_subscriptions_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.canteen_subscriptions DROP CONSTRAINT IF EXISTS canteen_subscriptions_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.canteen_subscriptions DROP CONSTRAINT IF EXISTS canteen_subscriptions_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.canteen_sales DROP CONSTRAINT IF EXISTS canteen_sales_staff_id_fkey;
ALTER TABLE IF EXISTS ONLY public.canteen_sales DROP CONSTRAINT IF EXISTS canteen_sales_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.canteen_sales DROP CONSTRAINT IF EXISTS canteen_sales_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance DROP CONSTRAINT IF EXISTS attendance_pupil_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance DROP CONSTRAINT IF EXISTS attendance_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.admissions DROP CONSTRAINT IF EXISTS admissions_target_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.admissions DROP CONSTRAINT IF EXISTS admissions_pupil_id_fkey;
DROP INDEX IF EXISTS public.report_card_remarks_pupil_term_idx;
DROP INDEX IF EXISTS public.pupil_promotions_pupil_idx;
DROP INDEX IF EXISTS public.pupil_enrollments_year_idx;
DROP INDEX IF EXISTS public.pupil_enrollments_pupil_idx;
DROP INDEX IF EXISTS public.pupil_enrollments_active_uidx;
DROP INDEX IF EXISTS public.idx_transport_pickup_points_route;
DROP INDEX IF EXISTS public.idx_purchase_order_items_po;
DROP INDEX IF EXISTS public.idx_app_users_reset_token;
DROP INDEX IF EXISTS public.guardians_user_id_uidx;
DROP INDEX IF EXISTS public.guardian_pupils_guardian_pupil_uidx;
DROP INDEX IF EXISTS public.gateway_transactions_invoice_idx;
DROP INDEX IF EXISTS public.gateway_transactions_guardian_idx;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
DROP INDEX IF EXISTS public.attendance_pupil_date_idx;
ALTER TABLE IF EXISTS ONLY public.vehicles DROP CONSTRAINT IF EXISTS vehicles_reg_no_key;
ALTER TABLE IF EXISTS ONLY public.vehicles DROP CONSTRAINT IF EXISTS vehicles_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transport_routes DROP CONSTRAINT IF EXISTS transport_routes_pkey;
ALTER TABLE IF EXISTS ONLY public.transport_pickup_points DROP CONSTRAINT IF EXISTS transport_pickup_points_pkey;
ALTER TABLE IF EXISTS ONLY public.transport_assignments DROP CONSTRAINT IF EXISTS transport_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.timetable_slots DROP CONSTRAINT IF EXISTS timetable_slots_pkey;
ALTER TABLE IF EXISTS ONLY public.terms DROP CONSTRAINT IF EXISTS terms_pkey;
ALTER TABLE IF EXISTS ONLY public.teacher_subjects DROP CONSTRAINT IF EXISTS teacher_subjects_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.subjects DROP CONSTRAINT IF EXISTS subjects_pkey;
ALTER TABLE IF EXISTS ONLY public.subjects DROP CONSTRAINT IF EXISTS subjects_code_key;
ALTER TABLE IF EXISTS ONLY public.staff DROP CONSTRAINT IF EXISTS staff_staff_no_key;
ALTER TABLE IF EXISTS ONLY public.staff DROP CONSTRAINT IF EXISTS staff_pkey;
ALTER TABLE IF EXISTS ONLY public.school_settings DROP CONSTRAINT IF EXISTS school_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_name_key;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.report_card_remarks DROP CONSTRAINT IF EXISTS report_card_remarks_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_po_no_key;
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_order_items DROP CONSTRAINT IF EXISTS purchase_order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.pupils DROP CONSTRAINT IF EXISTS pupils_pkey;
ALTER TABLE IF EXISTS ONLY public.pupils DROP CONSTRAINT IF EXISTS pupils_admission_no_key;
ALTER TABLE IF EXISTS ONLY public.pupil_promotions DROP CONSTRAINT IF EXISTS pupil_promotions_pkey;
ALTER TABLE IF EXISTS ONLY public.pupil_enrollments DROP CONSTRAINT IF EXISTS pupil_enrollments_pkey;
ALTER TABLE IF EXISTS ONLY public.ptc_sessions DROP CONSTRAINT IF EXISTS ptc_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.ptc_meetings DROP CONSTRAINT IF EXISTS ptc_meetings_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_name_key;
ALTER TABLE IF EXISTS ONLY public.payslips DROP CONSTRAINT IF EXISTS payslips_staff_id_period_id_key;
ALTER TABLE IF EXISTS ONLY public.payslips DROP CONSTRAINT IF EXISTS payslips_pkey;
ALTER TABLE IF EXISTS ONLY public.payroll_periods DROP CONSTRAINT IF EXISTS payroll_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_receipt_no_key;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_pupil_id_exam_id_subject_id_key;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_pkey;
ALTER TABLE IF EXISTS ONLY public.library_loans DROP CONSTRAINT IF EXISTS library_loans_pkey;
ALTER TABLE IF EXISTS ONLY public.library_books DROP CONSTRAINT IF EXISTS library_books_pkey;
ALTER TABLE IF EXISTS ONLY public.leave_requests DROP CONSTRAINT IF EXISTS leave_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_invoice_no_key;
ALTER TABLE IF EXISTS ONLY public.inventory_txns DROP CONSTRAINT IF EXISTS inventory_txns_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS inventory_items_pkey;
ALTER TABLE IF EXISTS ONLY public.inquiries DROP CONSTRAINT IF EXISTS inquiries_pkey;
ALTER TABLE IF EXISTS ONLY public.homework DROP CONSTRAINT IF EXISTS homework_pkey;
ALTER TABLE IF EXISTS ONLY public.health_records DROP CONSTRAINT IF EXISTS health_records_pkey;
ALTER TABLE IF EXISTS ONLY public.guardians DROP CONSTRAINT IF EXISTS guardians_pkey;
ALTER TABLE IF EXISTS ONLY public.guardian_pupils DROP CONSTRAINT IF EXISTS guardian_pupils_pkey;
ALTER TABLE IF EXISTS ONLY public.gateway_transactions DROP CONSTRAINT IF EXISTS gateway_transactions_reference_key;
ALTER TABLE IF EXISTS ONLY public.gateway_transactions DROP CONSTRAINT IF EXISTS gateway_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
ALTER TABLE IF EXISTS ONLY public.fee_items DROP CONSTRAINT IF EXISTS fee_items_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.exams DROP CONSTRAINT IF EXISTS exams_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.discipline_records DROP CONSTRAINT IF EXISTS discipline_records_pkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_pkey;
ALTER TABLE IF EXISTS ONLY public.canteen_subscriptions DROP CONSTRAINT IF EXISTS canteen_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.canteen_sales DROP CONSTRAINT IF EXISTS canteen_sales_pkey;
ALTER TABLE IF EXISTS ONLY public.canteen_menu_items DROP CONSTRAINT IF EXISTS canteen_menu_items_pkey;
ALTER TABLE IF EXISTS ONLY public.canteen_meal_plans DROP CONSTRAINT IF EXISTS canteen_meal_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.attendance DROP CONSTRAINT IF EXISTS attendance_pkey;
ALTER TABLE IF EXISTS ONLY public.app_users DROP CONSTRAINT IF EXISTS app_users_pkey;
ALTER TABLE IF EXISTS ONLY public.app_users DROP CONSTRAINT IF EXISTS app_users_email_key;
ALTER TABLE IF EXISTS ONLY public.announcements DROP CONSTRAINT IF EXISTS announcements_pkey;
ALTER TABLE IF EXISTS ONLY public.admissions DROP CONSTRAINT IF EXISTS admissions_pkey;
ALTER TABLE IF EXISTS ONLY public.admissions DROP CONSTRAINT IF EXISTS admissions_application_no_key;
ALTER TABLE IF EXISTS ONLY public.academic_years DROP CONSTRAINT IF EXISTS academic_years_pkey;
DROP TABLE IF EXISTS public.vehicles;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.transport_routes;
DROP TABLE IF EXISTS public.transport_pickup_points;
DROP TABLE IF EXISTS public.transport_assignments;
DROP TABLE IF EXISTS public.timetable_slots;
DROP TABLE IF EXISTS public.terms;
DROP TABLE IF EXISTS public.teacher_subjects;
DROP TABLE IF EXISTS public.suppliers;
DROP TABLE IF EXISTS public.subjects;
DROP TABLE IF EXISTS public.staff;
DROP TABLE IF EXISTS public.school_settings;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP TABLE IF EXISTS public.report_card_remarks;
DROP TABLE IF EXISTS public.purchase_orders;
DROP TABLE IF EXISTS public.purchase_order_items;
DROP TABLE IF EXISTS public.pupils;
DROP TABLE IF EXISTS public.pupil_promotions;
DROP TABLE IF EXISTS public.pupil_enrollments;
DROP TABLE IF EXISTS public.ptc_sessions;
DROP TABLE IF EXISTS public.ptc_meetings;
DROP TABLE IF EXISTS public.permissions;
DROP TABLE IF EXISTS public.payslips;
DROP TABLE IF EXISTS public.payroll_periods;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.marks;
DROP TABLE IF EXISTS public.library_loans;
DROP TABLE IF EXISTS public.library_books;
DROP TABLE IF EXISTS public.leave_requests;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.inventory_txns;
DROP TABLE IF EXISTS public.inventory_items;
DROP TABLE IF EXISTS public.inquiries;
DROP TABLE IF EXISTS public.homework;
DROP TABLE IF EXISTS public.health_records;
DROP TABLE IF EXISTS public.guardians;
DROP TABLE IF EXISTS public.guardian_pupils;
DROP TABLE IF EXISTS public.gateway_transactions;
DROP TABLE IF EXISTS public.flyway_schema_history;
DROP TABLE IF EXISTS public.fee_items;
DROP TABLE IF EXISTS public.expenses;
DROP TABLE IF EXISTS public.exams;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.discipline_records;
DROP TABLE IF EXISTS public.classes;
DROP TABLE IF EXISTS public.canteen_subscriptions;
DROP TABLE IF EXISTS public.canteen_sales;
DROP TABLE IF EXISTS public.canteen_menu_items;
DROP TABLE IF EXISTS public.canteen_meal_plans;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.attendance;
DROP TABLE IF EXISTS public.app_users;
DROP TABLE IF EXISTS public.announcements;
DROP TABLE IF EXISTS public.admissions;
DROP TABLE IF EXISTS public.academic_years;
DROP CAST IF EXISTS (character varying AS public.staffstatus);
DROP CAST IF EXISTS (character varying AS public.pupilstatus);
DROP CAST IF EXISTS (character varying AS public.postatus);
DROP CAST IF EXISTS (character varying AS public.payrollstatus);
DROP CAST IF EXISTS (character varying AS public.paymentmethod);
DROP CAST IF EXISTS (character varying AS public.loanstatus);
DROP CAST IF EXISTS (character varying AS public.leavestatus);
DROP CAST IF EXISTS (character varying AS public.invoicestatus);
DROP CAST IF EXISTS (character varying AS public.invdirection);
DROP CAST IF EXISTS (character varying AS public.eventaudience);
DROP CAST IF EXISTS (character varying AS public.disciplinekind);
DROP CAST IF EXISTS (character varying AS public.attendancestatus);
DROP CAST IF EXISTS (character varying AS public.admissionstatus);
DROP CAST IF EXISTS (public.staffstatus AS character varying);
DROP CAST IF EXISTS (public.pupilstatus AS character varying);
DROP CAST IF EXISTS (public.postatus AS character varying);
DROP CAST IF EXISTS (public.payrollstatus AS character varying);
DROP CAST IF EXISTS (public.paymentmethod AS character varying);
DROP CAST IF EXISTS (public.loanstatus AS character varying);
DROP CAST IF EXISTS (public.leavestatus AS character varying);
DROP CAST IF EXISTS (public.invoicestatus AS character varying);
DROP CAST IF EXISTS (public.invdirection AS character varying);
DROP CAST IF EXISTS (public.eventaudience AS character varying);
DROP CAST IF EXISTS (public.disciplinekind AS character varying);
DROP CAST IF EXISTS (public.attendancestatus AS character varying);
DROP CAST IF EXISTS (public.admissionstatus AS character varying);
DROP TYPE IF EXISTS public.staffstatus;
DROP TYPE IF EXISTS public.staff_status;
DROP TYPE IF EXISTS public.pupilstatus;
DROP TYPE IF EXISTS public.pupil_status;
DROP TYPE IF EXISTS public.postatus;
DROP TYPE IF EXISTS public.po_status;
DROP TYPE IF EXISTS public.payrollstatus;
DROP TYPE IF EXISTS public.payroll_status;
DROP TYPE IF EXISTS public.paymentmethod;
DROP TYPE IF EXISTS public.payment_method;
DROP TYPE IF EXISTS public.loanstatus;
DROP TYPE IF EXISTS public.loan_status;
DROP TYPE IF EXISTS public.leavestatus;
DROP TYPE IF EXISTS public.leave_status;
DROP TYPE IF EXISTS public.invoicestatus;
DROP TYPE IF EXISTS public.invoice_status;
DROP TYPE IF EXISTS public.invdirection;
DROP TYPE IF EXISTS public.inv_direction;
DROP TYPE IF EXISTS public.eventaudience;
DROP TYPE IF EXISTS public.event_audience;
DROP TYPE IF EXISTS public.disciplinekind;
DROP TYPE IF EXISTS public.discipline_kind;
DROP TYPE IF EXISTS public.attendancestatus;
DROP TYPE IF EXISTS public.attendance_status;
DROP TYPE IF EXISTS public.app_role;
DROP TYPE IF EXISTS public.admissionstatus;
DROP TYPE IF EXISTS public.admission_status;
--
-- Name: admission_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.admission_status AS ENUM (
    'APPLIED',
    'REVIEWING',
    'INTERVIEWED',
    'ADMITTED',
    'REJECTED',
    'WAITLISTED',
    'ENROLLED'
);


--
-- Name: admissionstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.admissionstatus AS ENUM (
    'ADMITTED',
    'APPLIED',
    'ENROLLED',
    'INTERVIEWED',
    'REJECTED',
    'REVIEWING',
    'WAITLISTED'
);


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'SUPER_ADMIN',
    'HEAD_TEACHER',
    'DEPUTY_HEAD',
    'ADMIN',
    'ACCOUNTANT',
    'TEACHER',
    'CLASS_TEACHER',
    'PARENT',
    'LIBRARIAN',
    'STORE_OFFICER',
    'TRANSPORT_OFFICER',
    'NURSE',
    'SECURITY'
);


--
-- Name: attendance_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.attendance_status AS ENUM (
    'PRESENT',
    'ABSENT',
    'LATE',
    'SICK',
    'EXCUSED'
);


--
-- Name: attendancestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.attendancestatus AS ENUM (
    'ABSENT',
    'EXCUSED',
    'LATE',
    'PRESENT',
    'SICK'
);


--
-- Name: discipline_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.discipline_kind AS ENUM (
    'INCIDENT',
    'MERIT',
    'DEMERIT',
    'REWARD',
    'WARNING'
);


--
-- Name: disciplinekind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.disciplinekind AS ENUM (
    'DEMERIT',
    'INCIDENT',
    'MERIT',
    'REWARD',
    'WARNING'
);


--
-- Name: event_audience; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.event_audience AS ENUM (
    'ALL',
    'STAFF',
    'PARENTS',
    'PUPILS',
    'CLASS'
);


--
-- Name: eventaudience; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.eventaudience AS ENUM (
    'ALL',
    'CLASS',
    'PARENTS',
    'PUPILS',
    'STAFF'
);


--
-- Name: inv_direction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.inv_direction AS ENUM (
    'IN',
    'OUT',
    'ADJUST',
    'DAMAGE',
    'LOST'
);


--
-- Name: invdirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invdirection AS ENUM (
    'ADJUST',
    'DAMAGE',
    'IN',
    'LOST',
    'OUT'
);


--
-- Name: invoice_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invoice_status AS ENUM (
    'UNPAID',
    'PARTIAL',
    'PAID',
    'CANCELLED'
);


--
-- Name: invoicestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invoicestatus AS ENUM (
    'CANCELLED',
    'PAID',
    'PARTIAL',
    'UNPAID'
);


--
-- Name: leave_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.leave_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'CANCELLED'
);


--
-- Name: leavestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.leavestatus AS ENUM (
    'APPROVED',
    'CANCELLED',
    'PENDING',
    'REJECTED'
);


--
-- Name: loan_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.loan_status AS ENUM (
    'BORROWED',
    'RETURNED',
    'OVERDUE',
    'LOST'
);


--
-- Name: loanstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.loanstatus AS ENUM (
    'BORROWED',
    'LOST',
    'OVERDUE',
    'RETURNED'
);


--
-- Name: payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_method AS ENUM (
    'CASH',
    'BANK',
    'MOBILE_MONEY',
    'CARD',
    'CHEQUE',
    'ONLINE'
);


--
-- Name: paymentmethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.paymentmethod AS ENUM (
    'BANK',
    'CARD',
    'CASH',
    'CHEQUE',
    'MOBILE_MONEY',
    'ONLINE'
);


--
-- Name: payroll_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payroll_status AS ENUM (
    'DRAFT',
    'APPROVED',
    'PAID'
);


--
-- Name: payrollstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payrollstatus AS ENUM (
    'APPROVED',
    'DRAFT',
    'PAID'
);


--
-- Name: po_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.po_status AS ENUM (
    'DRAFT',
    'SENT',
    'RECEIVED',
    'CANCELLED',
    'PAID'
);


--
-- Name: postatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.postatus AS ENUM (
    'CANCELLED',
    'DRAFT',
    'PAID',
    'RECEIVED',
    'SENT'
);


--
-- Name: pupil_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.pupil_status AS ENUM (
    'ACTIVE',
    'TRANSFERRED',
    'SUSPENDED',
    'GRADUATED',
    'WITHDRAWN'
);


--
-- Name: pupilstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.pupilstatus AS ENUM (
    'ACTIVE',
    'GRADUATED',
    'SUSPENDED',
    'TRANSFERRED',
    'WITHDRAWN'
);


--
-- Name: staff_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.staff_status AS ENUM (
    'ACTIVE',
    'RESIGNED',
    'TERMINATED',
    'RETIRED',
    'SUSPENDED'
);


--
-- Name: staffstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.staffstatus AS ENUM (
    'ACTIVE',
    'RESIGNED',
    'RETIRED',
    'SUSPENDED',
    'TERMINATED'
);


--
-- Name: CAST (public.admissionstatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.admissionstatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.attendancestatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.attendancestatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.disciplinekind AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.disciplinekind AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.eventaudience AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.eventaudience AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.invdirection AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.invdirection AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.invoicestatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.invoicestatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.leavestatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.leavestatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.loanstatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.loanstatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.paymentmethod AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.paymentmethod AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.payrollstatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.payrollstatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.postatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.postatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.pupilstatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.pupilstatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (public.staffstatus AS character varying); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (public.staffstatus AS character varying) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.admissionstatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.admissionstatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.attendancestatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.attendancestatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.disciplinekind); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.disciplinekind) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.eventaudience); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.eventaudience) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.invdirection); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.invdirection) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.invoicestatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.invoicestatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.leavestatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.leavestatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.loanstatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.loanstatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.paymentmethod); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.paymentmethod) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.payrollstatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.payrollstatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.postatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.postatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.pupilstatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.pupilstatus) WITH INOUT AS IMPLICIT;


--
-- Name: CAST (character varying AS public.staffstatus); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.staffstatus) WITH INOUT AS IMPLICIT;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.academic_years (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_current boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: admissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    application_no character varying(255),
    full_name character varying(255) NOT NULL,
    gender character varying(255),
    dob date,
    previous_school character varying(255),
    parent_name character varying(255),
    parent_phone character varying(255),
    parent_email character varying(255),
    interview_date date,
    reg_fee_paid numeric(10,2),
    status public.admission_status DEFAULT 'APPLIED'::public.admission_status NOT NULL,
    target_class_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    reg_fee_paid_on date,
    reg_fee_payment_method character varying(255),
    pupil_id uuid
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    body text NOT NULL,
    audience character varying(255) DEFAULT 'all'::character varying NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(255) DEFAULT ''::character varying NOT NULL,
    phone character varying(255),
    avatar_url character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL,
    reset_token character varying(255),
    reset_token_expires_at timestamp with time zone
);


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    class_id uuid,
    date date NOT NULL,
    status public.attendance_status DEFAULT 'PRESENT'::public.attendance_status NOT NULL,
    notes character varying(255),
    recorded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action character varying(255) NOT NULL,
    entity character varying(255),
    entity_id character varying(255),
    details text,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: canteen_meal_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.canteen_meal_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    meals_per_day integer DEFAULT 1 NOT NULL,
    price_per_term numeric(10,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: canteen_menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.canteen_menu_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    description text,
    price numeric(10,2) DEFAULT 0 NOT NULL,
    image_url character varying(255),
    is_available boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: canteen_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.canteen_sales (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid,
    item_name character varying(255) NOT NULL,
    pupil_id uuid,
    staff_id uuid,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) DEFAULT 0 NOT NULL,
    payment_method character varying(255) DEFAULT 'cash'::character varying NOT NULL,
    served_on date DEFAULT CURRENT_DATE NOT NULL,
    notes character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: canteen_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.canteen_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    term_id uuid,
    start_date date DEFAULT CURRENT_DATE NOT NULL,
    end_date date,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    notes character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    stream character varying(255),
    level_order integer DEFAULT 1 NOT NULL,
    capacity integer,
    class_teacher_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discipline_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discipline_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    kind public.discipline_kind DEFAULT 'INCIDENT'::public.discipline_kind NOT NULL,
    description text NOT NULL,
    action_taken text,
    occurred_on date DEFAULT CURRENT_DATE NOT NULL,
    points integer,
    reported_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    category character varying(255),
    description character varying(255),
    pupil_id uuid,
    staff_id uuid,
    uploaded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    location character varying(255),
    audience public.event_audience DEFAULT 'ALL'::public.event_audience NOT NULL,
    class_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: exams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    term_id uuid,
    exam_date date,
    out_of integer DEFAULT 100 NOT NULL,
    weight double precision DEFAULT 1.0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    assessment_type character varying(255)
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category character varying(255) NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    payee character varying(255),
    description text,
    payment_method character varying(255),
    ref_no character varying(255),
    spent_on date DEFAULT CURRENT_DATE NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fee_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fee_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    class_id uuid,
    term_id uuid,
    is_recurring boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    category character varying(255) DEFAULT 'SCHOOL_FEE'::character varying NOT NULL,
    due_date date
);


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: gateway_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gateway_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider character varying(255) DEFAULT 'LENCO'::character varying NOT NULL,
    reference character varying(255) NOT NULL,
    lenco_id character varying(255),
    lenco_reference character varying(255),
    invoice_id uuid NOT NULL,
    guardian_id uuid,
    phone character varying(255) NOT NULL,
    operator character varying(255) NOT NULL,
    amount numeric(12,2) NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    payment_id uuid,
    failure_reason text,
    raw_response text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: guardian_pupils; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guardian_pupils (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    guardian_id uuid NOT NULL,
    pupil_id uuid NOT NULL,
    is_primary boolean DEFAULT false NOT NULL
);


--
-- Name: guardians; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guardians (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    full_name character varying(255) NOT NULL,
    relationship character varying(255),
    phone character varying(255),
    email character varying(255),
    address character varying(255),
    occupation character varying(255),
    national_id character varying(255),
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    visit_date date DEFAULT CURRENT_DATE NOT NULL,
    complaint character varying(255),
    diagnosis character varying(255),
    treatment character varying(255),
    medication character varying(255),
    notes text,
    attended_by character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: homework; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.homework (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    class_id uuid,
    subject_id uuid,
    due_date date,
    attachment_url character varying(255),
    assigned_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inquiries (
    id uuid NOT NULL,
    full_name character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(255),
    message text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    sku character varying(255),
    category character varying(255),
    unit character varying(255),
    location character varying(255),
    quantity integer DEFAULT 0 NOT NULL,
    reorder_level integer,
    unit_cost numeric(12,2),
    supplier_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_txns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_txns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid NOT NULL,
    direction public.inv_direction NOT NULL,
    quantity integer NOT NULL,
    reason character varying(255),
    reference character varying(255),
    occurred_on date DEFAULT CURRENT_DATE NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_no character varying(255) NOT NULL,
    pupil_id uuid NOT NULL,
    term_id uuid,
    total numeric(12,2) DEFAULT 0 NOT NULL,
    paid numeric(12,2) DEFAULT 0 NOT NULL,
    status public.invoice_status DEFAULT 'UNPAID'::public.invoice_status NOT NULL,
    due_date date,
    description character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    fee_item_id uuid,
    late_fee_applied boolean DEFAULT false NOT NULL
);


--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    staff_id uuid NOT NULL,
    leave_type character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    reason text,
    status public.leave_status DEFAULT 'PENDING'::public.leave_status NOT NULL,
    approver_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: library_books; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_books (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    author character varying(255),
    isbn character varying(255),
    category character varying(255),
    shelf character varying(255),
    copies_total integer DEFAULT 1 NOT NULL,
    copies_available integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: library_loans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_loans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    book_id uuid NOT NULL,
    pupil_id uuid,
    staff_id uuid,
    borrowed_on date DEFAULT CURRENT_DATE NOT NULL,
    due_on date NOT NULL,
    returned_on date,
    status public.loan_status DEFAULT 'BORROWED'::public.loan_status NOT NULL,
    fine numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    exam_id uuid NOT NULL,
    subject_id uuid NOT NULL,
    score double precision NOT NULL,
    comment character varying(255),
    entered_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    body text NOT NULL,
    subject character varying(255),
    channel character varying(255) DEFAULT 'sms'::character varying NOT NULL,
    audience character varying(255),
    class_id uuid,
    recipient_count integer,
    sent_by uuid,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    recipient_label character varying(255)
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    receipt_no character varying(255) NOT NULL,
    pupil_id uuid NOT NULL,
    invoice_id uuid,
    amount numeric(12,2) NOT NULL,
    method public.payment_method DEFAULT 'CASH'::public.payment_method NOT NULL,
    paid_on date DEFAULT CURRENT_DATE NOT NULL,
    reference character varying(255),
    notes character varying(255),
    recorded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(255) DEFAULT 'CONFIRMED'::character varying NOT NULL,
    submitted_by_guardian_id uuid,
    rejection_reason character varying(255)
);


--
-- Name: payroll_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    period_label character varying(255) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    status public.payroll_status DEFAULT 'DRAFT'::public.payroll_status NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payslips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payslips (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    staff_id uuid NOT NULL,
    period_id uuid NOT NULL,
    basic numeric(12,2) DEFAULT 0 NOT NULL,
    allowances numeric(12,2) DEFAULT 0 NOT NULL,
    deductions numeric(12,2) DEFAULT 0 NOT NULL,
    tax numeric(12,2) DEFAULT 0 NOT NULL,
    net_pay numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    module character varying(255) DEFAULT 'GENERAL'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ptc_meetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ptc_meetings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid,
    staff_id uuid,
    guardian_id uuid,
    pupil_id uuid,
    meeting_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone,
    venue character varying(255),
    status character varying(255) DEFAULT 'SCHEDULED'::character varying NOT NULL,
    agenda character varying(255),
    teacher_notes character varying(255),
    admin_notes character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: ptc_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ptc_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    session_date date NOT NULL,
    venue character varying(255),
    description character varying(255),
    start_time time without time zone,
    end_time time without time zone,
    term_id uuid,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: pupil_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pupil_enrollments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    class_id uuid NOT NULL,
    academic_year_id uuid,
    started_on date NOT NULL,
    ended_on date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pupil_enrollment_dates_chk CHECK (((ended_on IS NULL) OR (ended_on >= started_on)))
);


--
-- Name: pupil_promotions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pupil_promotions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    from_class_id uuid NOT NULL,
    to_class_id uuid NOT NULL,
    academic_year_id uuid,
    promoted_on date NOT NULL,
    promoted_by uuid,
    notes character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pupil_promotion_class_chk CHECK ((from_class_id <> to_class_id))
);


--
-- Name: pupils; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pupils (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admission_no character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(255),
    dob date,
    address character varying(255),
    town character varying(255),
    province character varying(255),
    postal_code character varying(255),
    nationality character varying(255),
    tribe character varying(255),
    religion character varying(255),
    home_language character varying(255),
    blood_group character varying(255),
    allergies character varying(255),
    medical_info character varying(255),
    special_needs character varying(255),
    nrc_no character varying(255),
    birth_cert_no character varying(255),
    previous_school character varying(255),
    referral_source character varying(255),
    siblings_in_school character varying(255),
    house character varying(255),
    boarding_status character varying(255),
    transport_mode character varying(255),
    emergency_contact character varying(255),
    photo_url character varying(255),
    notes character varying(255),
    admitted_on date DEFAULT CURRENT_DATE NOT NULL,
    status public.pupil_status DEFAULT 'ACTIVE'::public.pupil_status NOT NULL,
    class_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    purchase_order_id uuid NOT NULL,
    item_id uuid NOT NULL,
    quantity integer NOT NULL,
    unit_cost numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    po_no character varying(255),
    supplier_id uuid,
    order_date date DEFAULT CURRENT_DATE NOT NULL,
    status public.po_status DEFAULT 'DRAFT'::public.po_status NOT NULL,
    total numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    received_at timestamp with time zone
);


--
-- Name: report_card_remarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_card_remarks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    class_teacher_remark text,
    head_teacher_remark text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    term_id uuid NOT NULL
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: school_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_settings (
    id bigint DEFAULT 1 NOT NULL,
    name character varying(255) DEFAULT 'Bright Minds School'::character varying NOT NULL,
    address character varying(255),
    city character varying(255),
    district character varying(255),
    province character varying(255),
    country character varying(255),
    po_box character varying(255),
    postal_code character varying(255),
    plot_number character varying(255),
    phone character varying(255),
    email character varying(255),
    website character varying(255),
    motto character varying(255),
    head_teacher character varying(255),
    deputy_head character varying(255),
    registration_no character varying(255),
    tpin character varying(255),
    established_year integer,
    currency character varying(255) DEFAULT 'ZMW'::character varying NOT NULL,
    logo_url character varying(255),
    map_url character varying(255),
    latitude double precision,
    longitude double precision,
    grading_scale text DEFAULT '[]'::jsonb NOT NULL,
    current_academic_year_id uuid,
    current_term_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    head_teacher_signature_url character varying(255),
    banner_url text,
    dashboard_hero_heading character varying(255),
    dashboard_hero_subtext text,
    dashboard_hero_image_url text,
    dashboard_button_label character varying(255),
    dashboard_button_url character varying(255),
    dashboard_links text DEFAULT '[]'::text,
    login_button_label character varying(255),
    login_button_url character varying(255),
    landing_hero_heading character varying(255),
    landing_hero_subtext text,
    landing_hero_images text DEFAULT '[]'::text,
    landing_about_title character varying(255),
    landing_about_body text,
    facebook_url character varying(255)
);


--
-- Name: staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    staff_no character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(255),
    email character varying(255),
    phone character varying(255),
    address character varying(255),
    dob date,
    date_joined date,
    employment_type character varying(255),
    is_teacher boolean DEFAULT false NOT NULL,
    basic_salary numeric(12,2),
    qualifications character varying(255),
    next_of_kin character varying(255),
    bank_name character varying(255),
    bank_account character varying(255),
    photo_url character varying(255),
    status public.staff_status DEFAULT 'ACTIVE'::public.staff_status NOT NULL,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    role_category character varying(255),
    contract_end_date date,
    signature_url character varying(255)
);


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subjects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    contact_person character varying(255),
    phone character varying(255),
    email character varying(255),
    address character varying(255),
    tax_no character varying(255),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: teacher_subjects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_subjects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    teacher_id uuid NOT NULL,
    subject_id uuid NOT NULL,
    class_id uuid
);


--
-- Name: terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terms (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    academic_year_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_current boolean DEFAULT false NOT NULL
);


--
-- Name: timetable_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timetable_slots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    class_id uuid NOT NULL,
    subject_id uuid,
    teacher_id uuid,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    room character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: transport_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transport_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pupil_id uuid NOT NULL,
    route_id uuid NOT NULL,
    pickup_point character varying(255),
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pickup_point_id uuid
);


--
-- Name: transport_pickup_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transport_pickup_points (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    route_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    fee numeric(10,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: transport_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transport_routes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    pickup_points text,
    vehicle_id uuid,
    fee numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    reg_no character varying(255) NOT NULL,
    model character varying(255),
    capacity integer,
    driver_name character varying(255),
    driver_phone character varying(255),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.academic_years (id, name, start_date, end_date, is_current, created_at) FROM stdin;
\.


--
-- Data for Name: admissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admissions (id, application_no, full_name, gender, dob, previous_school, parent_name, parent_phone, parent_email, interview_date, reg_fee_paid, status, target_class_id, notes, created_at, updated_at, reg_fee_paid_on, reg_fee_payment_method, pupil_id) FROM stdin;
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, title, body, audience, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: app_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_users (id, email, password_hash, full_name, phone, avatar_url, created_at, updated_at, must_change_password, reset_token, reset_token_expires_at) FROM stdin;
f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	$2a$10$AwcqSc7JIQCFZsmwLyGbZe2/piXYV1gZae9sZwTlWkSmXE9ZE1PPm	System Administrator	\N	\N	2026-07-01 09:20:15.202806+02	2026-08-28 15:01:23.26824+02	f	Cxl9PrUCcIg1OJskJL02ZwFe6LytQmV-8ioa-qUr-uE	2026-08-28 16:01:19.498657+02
a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	$2a$10$4wYgFhUnjKK/Cz8gs.Xu/uwi4PmB0ryP1SjpITzQXFF1pwgAfDlJ.	Test Parent	0976911338	\N	2026-07-10 17:26:03.941343+02	2026-08-29 08:26:11.741332+02	f	\N	\N
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance (id, pupil_id, class_id, date, status, notes, recorded_by, created_at) FROM stdin;
38c50042-4fab-4ad8-baff-d82b1f5bf9b2	7451c3b1-3401-491a-874d-908b224fd662	b436c50e-1846-4110-a584-64d288106bdc	2026-07-10	PRESENT	\N	\N	2026-07-10 17:31:59.661487+02
27f6e2b4-8fd5-40b0-98d9-da9f84685de2	7451c3b1-3401-491a-874d-908b224fd662	b436c50e-1846-4110-a584-64d288106bdc	2026-08-23	PRESENT	\N	\N	2026-08-23 20:58:49.462107+02
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, entity, entity_id, details, user_id, created_at) FROM stdin;
f1646445-084c-4087-ae80-b5b3edc55501	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-01 09:24:10.077596+02
71cced48-fd38-4d25-bee7-f989db77146c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 12:17:20.359486+02
c02f470e-b0e2-4cc0-8b99-2f78ac876954	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 12:20:35.125242+02
58696d92-d418-46f8-b09c-ee7764d4b268	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 12:23:27.608568+02
8475003e-e9f5-4164-83d1-d35b3dc22372	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 12:25:56.952548+02
c89d628b-614a-4b89-ac8e-931358ed90e0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 12:43:23.397952+02
9e234a6c-4e77-48fa-bfd9-dd5cdcea0042	LOGIN	AppUser	2ce0121c-8e69-461f-83cd-499550941d22	codex.parent.1783680203543@school.test	\N	2026-07-10 12:43:23.97148+02
9898a09d-5da5-449f-ac98-f955cf9d7495	PROMOTE_PUPILS	SchoolClass	81bdd8c0-c147-4e2c-98f3-9cb041d6d484	1 pupil(s) promoted to Codex Grade 2 1783680203543 A	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-07-10 12:43:24.557636+02
9dea91d7-5c81-435d-98d7-22f08e2f6e19	DELETE_USER	AppUser	2ce0121c-8e69-461f-83cd-499550941d22	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-07-10 12:43:24.769635+02
15a96861-44f8-4603-bf7e-e7bb9965c9a3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 12:44:51.703388+02
e640063a-5eeb-4fff-b01c-1cabb3931ca6	LOGIN	AppUser	447d8593-90fc-44f7-9f8d-40bde3499d48	codex.parent.1783680291852@school.test	\N	2026-07-10 12:44:52.333384+02
c23ffce7-f63e-4b6f-897c-58c7426dcb99	PROMOTE_PUPILS	SchoolClass	3d95450e-474a-46ed-bdc9-b20bd2d829e1	1 pupil(s) promoted to Codex Grade 2 1783680291852 A	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-07-10 12:44:52.842227+02
c915e48b-f46a-472a-b654-43065c3802c6	DELETE_USER	AppUser	447d8593-90fc-44f7-9f8d-40bde3499d48	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-07-10 12:44:53.098229+02
50c0b7bc-626e-4e12-8694-3443c0fbb5b8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 12:47:29.006208+02
45dd67ac-816d-42a3-8305-448d930d67e2	LOGIN	AppUser	a57aff3a-126f-4a53-834c-15cb43d15e11	linked.parent.1783680449150@school.test	\N	2026-07-10 12:47:30.130183+02
6c7d0f1f-795a-4cca-a7c4-e0af995b9381	DELETE_USER	AppUser	a57aff3a-126f-4a53-834c-15cb43d15e11	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-07-10 12:47:30.636706+02
358bb9c5-5366-4d3f-beca-530886fcd332	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 17:01:25.459377+02
2313f409-c2bb-4e61-8445-466c79ee99d2	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-07-10 17:26:59.80653+02
e86eaae6-cda9-4640-901a-19d34725f3af	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-07-10 17:28:53.607432+02
417ce496-f228-4f89-a4cd-6101c00e24c9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-07-10 17:29:09.234607+02
4c23678f-d684-4e9b-87b1-d87725fa722d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-10 15:58:33.553519+02
5c3ac1c1-ce45-4fa9-b833-38bba1f2eb2e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-10 15:58:47.429025+02
3bdf774e-92e9-401d-b20e-95c20124254b	RESET_PASSWORD	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-10 16:00:31.460406+02
88ebd088-ffb1-4a50-90aa-7a5fc8cb59b4	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-10 16:00:31.667573+02
aab06525-ea68-4d2c-8438-0c402407dc23	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-10 16:00:42.828717+02
68f1e738-17a5-46ab-80b3-7f883480d9d8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:29:57.311237+02
f9d5b0d2-f0e5-496b-8dc0-fdb298bf59c0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:30:27.945597+02
3ebd7ab6-be94-4d0d-899b-d4be5b96f38a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:34:33.668699+02
d850b4a8-56b2-4b87-863e-e620f6ede5e4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:46:24.579552+02
0585d583-9ef6-449b-8927-493ac66088f3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:46:38.73286+02
e6fc4cbb-70ed-4fd2-94fa-4275cb32e329	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:55:11.860229+02
6cb3de85-b4f9-4664-ae91-73e466b74b4a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:55:26.730681+02
86a7a846-86c5-4238-80d5-f0a3f087c231	LOGIN	AppUser	4a9ecf80-e2c5-440b-adcf-40177bd63016	qateacher@test.com	\N	2026-08-13 18:56:09.156808+02
fec4d70b-e19f-4079-b315-5d0bdb9c4fb9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 18:56:22.585569+02
f1465945-ca4e-4b8a-bd75-eebe753ccb5e	DELETE_USER	AppUser	4a9ecf80-e2c5-440b-adcf-40177bd63016	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-13 18:56:23.344543+02
0da375dc-832d-44a6-9d14-aa9f7dfdc032	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:12:00.148634+02
05f25562-d12a-4645-b351-3505b3ea89c2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:12:00.484805+02
e281c7a3-8114-496d-be09-b2e4a0a883ff	LOGIN	AppUser	6938abe6-6bec-4f48-84a7-e95f5a450111	qaphoneparent@test.com	\N	2026-08-13 19:12:01.497204+02
23ddef0e-2d91-4814-b7e8-cecf1db435b3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:12:25.810067+02
af406bde-fd0f-4566-af3c-a3c9759e7b2c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:12:44.637386+02
07904e1c-ba6f-4631-bd87-d9602d66a2a0	DELETE_USER	AppUser	6938abe6-6bec-4f48-84a7-e95f5a450111	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-13 19:12:45.595114+02
5c36518b-41d3-4f7f-9cca-23e6c6c03b56	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:51:48.957389+02
e8dcf630-26ba-425f-8bb1-34fc3c714111	LOGIN	AppUser	a45c4b1e-49e8-4feb-b285-99f70c716044	qaclaimparent@test.com	\N	2026-08-13 19:51:51.031549+02
3773356a-6ae0-406a-bc2e-6be75cf1f082	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:52:20.803458+02
8406b018-9071-4e21-aa70-418845ebfbed	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:54:03.300114+02
8443aa08-dcd7-4bb5-84df-d60c5bd7c2f8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 19:56:46.931322+02
d74094db-c74c-4169-8dda-5e184ad556c8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 20:09:57.532081+02
7e3b9b4d-d25e-47dc-8b51-9d235f0d4468	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 20:11:53.815309+02
c0e2f718-01bd-4f63-b6b4-4ead3d43c439	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 20:12:55.114399+02
f8fce1bb-e04b-45b4-86d2-71b6983ef4fd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 20:15:16.889571+02
272fbe73-de63-4fd8-b13f-9e37a7c6c0a7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 20:36:01.683476+02
c7369602-e360-4628-b55e-92aa1d88b15d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 20:37:03.631699+02
8516f4e7-93b4-4006-944e-1c67a49feeb4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 21:00:34.116047+02
c87ae8eb-7b03-4147-82d0-0b031d4a6f72	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 21:02:06.173806+02
1d40a1db-577f-422b-8f16-0291fcafef4b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-13 21:34:03.265657+02
ce4c3da2-ed43-445a-8845-f57091d6ce18	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 06:55:36.202324+02
c98e1288-ae83-4168-b7bc-a971190ecb60	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 06:56:14.750383+02
d0ec1edc-e967-4969-802a-f449bc73d8e7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 06:59:27.040683+02
ca096987-f6a1-4cfd-b8d7-e17b0a943ece	CREATE_USER	AppUser	33b69c83-06d3-4848-9589-fb1354b2268f	ghosttest@qa.local	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-14 06:59:27.41523+02
26dd748b-9d64-4503-9a8b-cd5043f704c2	LOGIN	AppUser	33b69c83-06d3-4848-9589-fb1354b2268f	ghosttest@qa.local	\N	2026-08-14 06:59:27.693752+02
37610a62-84d8-44b1-b246-4fda6392ab21	DELETE_USER	AppUser	33b69c83-06d3-4848-9589-fb1354b2268f	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-14 06:59:27.961106+02
965cc37d-291c-4762-be4e-2b77b8a5e647	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 06:59:28.168419+02
34fc9438-fe3f-477f-a160-40ebac64c323	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 07:05:32.878231+02
19c10a6f-47b6-4bd5-8ed3-fd293d8c83d1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 07:06:00.639121+02
e1b32146-0461-4511-b7c8-ee444cfb048f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 07:07:13.301669+02
f7e3a62b-3a1d-4469-967d-d0093959a1d4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 08:13:22.113686+02
92e0c244-52a7-488e-9faa-7af7708dccaf	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 08:13:22.39744+02
4f05578d-e5ab-430e-94ef-4ddd14b0bcf4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 08:16:06.423234+02
460db1c7-08d9-4553-a42f-7f9362bd4124	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 08:21:18.529106+02
746db08c-0e83-4ce7-926f-f1ac97c2698f	PROVISION_PARENT_LOGIN	Guardian	2f1633d1-3fa8-4d90-9ede-c252560781ff	testparent@test.com	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-14 08:26:23.205243+02
e580cbda-5bb2-48c5-b29f-f64a98e87254	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-14 08:26:44.983822+02
372cd265-9250-4f9f-864d-071f951c2bea	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-14 08:35:55.364219+02
4f29940a-8e9c-4b2b-a2ed-23b9c8aa28bb	LOGIN	AppUser	68bf04ed-14d2-4853-a89f-9fe81fafb6ec	verify-temp@brightminds.test	\N	2026-08-14 09:11:03.236928+02
c1a809e1-05c9-4c68-a52d-363d38cbf55e	LOGIN	AppUser	538218ad-0763-47a4-9ebd-09380add98ff	verify-teacher@brightminds.test	\N	2026-08-14 09:20:08.802845+02
8618834a-0f7e-4f84-b2bc-0de3c7ba7731	LOGIN	AppUser	6a578054-5a0c-47c9-b704-4d0ecbbd7613	verify-admin@brightminds.test	\N	2026-08-14 09:20:09.14585+02
777e186a-51c2-4907-96f7-c8477f5c8ff0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 09:22:06.225651+02
74fe547e-ef2f-4067-b5ee-3e58e6afb954	LOGIN	AppUser	5b42f711-f70a-4c79-9b8c-c291ffb2db2f	verify-parent@brightminds.test	\N	2026-08-14 09:22:54.995556+02
9f9caf3b-3dbf-40cd-8d59-f31d41064774	LOGIN	AppUser	bd27676f-5399-40fc-9cfe-afc593049c17	verify-admin2@brightminds.test	\N	2026-08-14 09:34:12.832652+02
cdee6ea7-a34e-4c28-8361-c3997fac54f9	LOGIN	AppUser	bd27676f-5399-40fc-9cfe-afc593049c17	verify-admin2@brightminds.test	\N	2026-08-14 09:38:14.657917+02
2969e4b6-32e8-42b5-a5ab-63aaf42d952c	LOGIN	AppUser	bd27676f-5399-40fc-9cfe-afc593049c17	verify-admin2@brightminds.test	\N	2026-08-14 09:38:25.572266+02
ffe8bfc3-de88-4b76-9366-f5cfc1379bb9	LOGIN	AppUser	bd27676f-5399-40fc-9cfe-afc593049c17	verify-admin2@brightminds.test	\N	2026-08-14 09:38:37.912996+02
b7b29d56-073d-40f8-bb75-dfaea54b4c36	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-14 16:54:24.814611+02
d6243b26-4bb2-4466-ac28-511ea00349d8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-14 16:55:40.228146+02
df4afc28-3b5f-4928-96e8-645a7f233624	LOGIN	AppUser	01943fdd-7197-4aba-8067-56ba109cc873	verify-fees-admin@brightminds.test	\N	2026-08-15 03:54:20.846521+02
78db8316-9292-4e10-ad91-09021794a44b	PROVISION_PARENT_LOGIN	Guardian	79243f84-0331-4d43-872d-6c6a2a4c1822	verify-parent-fees@brightminds.test	01943fdd-7197-4aba-8067-56ba109cc873	2026-08-15 03:59:26.215226+02
34562a78-8917-491e-bf6d-0cb1be54be04	LOGIN	AppUser	11c16fa7-584c-47a2-9a32-440728dc9274	verify-parent-fees@brightminds.test	\N	2026-08-15 03:59:41.874064+02
54c25b2e-f224-4717-913e-444ae7ad5fd4	LOGIN	AppUser	0dde8c72-976a-427c-b2f8-4eec51b83532	verify-big-admin@brightminds.test	\N	2026-08-16 11:03:00.086894+02
0b4be94e-8828-4199-b031-8a829812e293	LOGIN	AppUser	67bca8a4-2127-46f5-9f32-756b253934e8	verify-big-parent@brightminds.test	\N	2026-08-16 11:13:25.822713+02
174c949b-7baf-4876-af98-e4d7d3c52d27	CREATE_ROLE	Role	d6e9e826-fad8-409b-8f72-e605d6a10793	MANAGER	0dde8c72-976a-427c-b2f8-4eec51b83532	2026-08-16 11:13:59.030739+02
10740854-d328-4d15-ab86-2ff43d55e195	PROVISION_STAFF_LOGIN	Staff	f550adfb-81f6-4c0b-98f1-f74aa380910c	verify-teacher-e2e@brightminds.test	0dde8c72-976a-427c-b2f8-4eec51b83532	2026-08-16 11:15:35.76364+02
d2266228-8b4b-40e2-ade0-6d24aab892cc	LOGIN	AppUser	f5d8cba4-481d-4ca5-8305-8d5ad29951c2	verify-teacher-e2e@brightminds.test	\N	2026-08-16 11:32:16.945187+02
a542f668-1a9a-4f12-973b-896433f715d9	LOGIN	AppUser	f5d8cba4-481d-4ca5-8305-8d5ad29951c2	verify-teacher-e2e@brightminds.test	\N	2026-08-16 11:32:17.217897+02
75ebf9dc-0de0-46c9-905e-ec036fbcb2d3	LOGIN	AppUser	97d1a561-3b1a-48b7-ab59-717eed9ebd66	rbac-superadmin@brightminds.test	\N	2026-08-16 12:18:12.748292+02
f65530b6-6017-4256-adef-1a0ebe30026b	LOGIN	AppUser	91a8bf4c-3aa8-4afd-a1de-016865bbcfc3	rbac-headteacher@brightminds.test	\N	2026-08-16 12:18:13.115249+02
f7508a05-faea-478e-b117-9756d22969c4	LOGIN	AppUser	9bf2150f-323b-4ce1-9fef-f3d5afc4fa69	rbac-teacher@brightminds.test	\N	2026-08-16 12:18:13.490223+02
5a36e3a2-be2f-4e58-96e7-f5442fa40748	LOGIN	AppUser	b1982b1e-e0a6-404f-b828-67c0f37a2809	rbac-accountant@brightminds.test	\N	2026-08-16 12:18:13.854824+02
34fafd43-979d-4348-ab73-cdcc7a0bca78	LOGIN	AppUser	d5aa642c-ccad-4b85-9fd6-5a3fd455b3f9	rbac-parent@brightminds.test	\N	2026-08-16 12:18:14.359874+02
2cef3812-b07a-44a9-b778-32d232a1b7ae	CREATE_ROLE	Role	d6907bc3-a6cf-4e17-a547-2f994314e663	MANAGER	97d1a561-3b1a-48b7-ab59-717eed9ebd66	2026-08-16 12:25:11.063422+02
2aecfaa9-9a7c-4f60-b10b-ca5ee3db3530	UPDATE_ROLES	AppUser	f189fb51-a9e4-4897-a401-6ddffb037289	\N	97d1a561-3b1a-48b7-ab59-717eed9ebd66	2026-08-16 12:25:54.579365+02
419d38b5-792f-4564-bec5-558b3e1c53dc	LOGIN	AppUser	f189fb51-a9e4-4897-a401-6ddffb037289	rbac-manager@brightminds.test	\N	2026-08-16 12:26:08.471268+02
c1656942-f7f6-4db4-970c-fe78b52c86f2	LOGIN	AppUser	f0f6ea7c-b05b-458b-a27d-f86d60c08354	bug-superadmin@brightminds.test	\N	2026-08-17 21:17:04.7526+02
8f19bd92-2d6d-49f1-972b-21aaa35b64e9	LOGIN	AppUser	234ffeb5-90e0-409d-a951-cf1324263fb2	bug-superadmin2@brightminds.test	\N	2026-08-18 03:29:11.170762+02
c9ed3b6a-9a29-4bcf-a3cf-0038c41064fd	LOGIN	AppUser	707ba660-f253-47e5-afc6-3d208697e841	scope-admin@brightminds.test	\N	2026-08-18 03:58:22.471734+02
8a0b489e-c731-437a-966a-3d1356008ca2	LOGIN	AppUser	9692dfae-6601-4705-8556-2a1776507dab	teacher-a@brightminds.test	\N	2026-08-18 03:59:32.487233+02
49baabab-6ddc-4f3d-8460-11c862447bb6	LOGIN	AppUser	67b69729-50c2-42e9-a0c3-69f8442e7925	upload-test@brightminds.test	\N	2026-08-18 04:10:11.797641+02
25dcd121-cb41-4c0c-bfb3-02aff71fb8ef	LOGIN	AppUser	67b69729-50c2-42e9-a0c3-69f8442e7925	upload-test@brightminds.test	\N	2026-08-18 04:10:44.475738+02
51eba975-7014-4b6d-83a0-afcab3143f43	LOGIN	AppUser	6aff0d27-b141-4750-b799-952d21eec833	datebug-test@brightminds.test	\N	2026-08-18 04:12:46.293584+02
e2f422e8-ba0b-4d82-a8db-dc47bbc285f9	LOGIN	AppUser	6aff0d27-b141-4750-b799-952d21eec833	datebug-test@brightminds.test	\N	2026-08-18 04:13:01.768199+02
23a932d1-b114-4ff3-8618-f8332c94e4cb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-18 20:51:16.312461+02
af79b105-ed38-4d62-8bc7-dba01bf3d55f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-18 21:23:28.422858+02
e490ad64-28ca-4132-8812-993e6783392a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:13:26.688029+02
f138a29e-4dd9-4208-bade-50a81b5d233d	CREATE_USER	AppUser	c8415964-f1dd-4320-85bf-51242f1a8c78	role-repro-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 01:13:27.061783+02
e59711ff-369e-4be3-94f3-df4f418006dc	UPDATE_ROLES	AppUser	c8415964-f1dd-4320-85bf-51242f1a8c78	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 01:13:27.370506+02
9f9a4b83-e3ad-443b-8d1d-83924f0b1e9c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:13:40.07716+02
3b1946df-92c3-4e24-9476-3f1b9d85c1b6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:13:54.749518+02
0d119801-d0e8-4277-a521-573c0e6d620e	DELETE_USER	AppUser	c8415964-f1dd-4320-85bf-51242f1a8c78	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 01:13:54.846172+02
904fdd9b-a22f-49c5-ba40-1e5c73a1579e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:50:40.573286+02
e968240d-eb7a-4456-b875-244d319d02e7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:50:54.79383+02
4689aa59-ccf0-45f3-8a3a-8b7f339bb7a5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:51:43.680151+02
33900a98-2890-435e-a332-b68956456a9f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:54:13.404977+02
6723d708-2282-43ad-831f-3bd11d44bfaf	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:58:22.43172+02
75dc8186-6036-4124-9fb7-d0aeaaa3943f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 01:58:45.828243+02
c9ffdfa2-3439-4653-9a97-b10d329a278e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 02:28:03.230391+02
59834c6a-b115-4ebc-b419-1f434c7a0097	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 02:29:43.974154+02
32502e06-ad56-4b63-9aaf-ccb255ea5a7c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 02:30:00.803682+02
5e8bdde3-03bc-4c08-9f8a-7cbd2ac5bdc0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 03:08:58.185258+02
fa049393-c900-441c-b3b2-c4b8a5cfead7	PROMOTE_PUPILS	SchoolClass	f94ca2b3-3cf7-4b93-948a-b1f85b4934b1	1 pupil(s) promoted to Repro Grade 2	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 03:08:59.359457+02
6bac27aa-b4b8-42b0-a705-76a5042471a4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 06:49:48.794926+02
dba98e03-1f62-4961-9fb7-909702c54bb1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 06:51:01.272366+02
ed134c56-a603-43d7-9c19-77eb38411c3a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 06:55:31.013211+02
52d60bc9-37b2-4f2f-b88a-bdc5706941cb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 07:04:33.766427+02
41db14e4-adec-4cae-b8de-4bc3a0ef3e1e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 07:11:26.39794+02
7f2f1684-bcea-4dc7-91a1-78835c3e2ad8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 07:11:38.757058+02
c4163754-39eb-4a5c-b1a7-6b5f232af83f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 07:11:52.852935+02
18ddd740-6e83-46ec-842a-a7f3f4dede18	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 07:12:07.867806+02
4130558f-2beb-4120-83da-aa53847f6f53	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 07:33:25.365327+02
065487a2-90d7-4f36-8cc7-3e93e1db032b	RECEIVE_PURCHASE_ORDER	PurchaseOrder	6d0e1354-9223-4889-a637-b648ee82eb4e	1 line item(s) credited to stock (PO null)	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 07:33:27.070023+02
4781e797-d404-47e0-93be-11f89fee9403	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 07:33:56.783229+02
00dba918-2d14-40bb-870e-c3e5fe02afd1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 08:06:37.648139+02
408c6bd5-0a05-4d99-b1be-a5308e73ca69	MARK_PAYROLL_PAID	PayrollPeriod	8ff9c69c-4f6d-41f4-816f-5ab089504320	1 payslip(s) totalling 1050.00 recorded as a Salaries expense	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 08:06:38.904866+02
5bca1118-1c8c-4a14-a132-3762d94859b5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 08:06:58.700958+02
ab0e37cd-9c05-4b14-a79c-973879ff7d72	DELETE_EXPENSE	Expense	cfd4f983-60eb-41ad-ac3b-c7f8c946c69c	amount 1050.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 08:06:59.295475+02
68df073f-8956-4812-ba17-4fa04d0d4231	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-19 08:07:28.72342+02
24d0696f-e5a6-4417-a2a6-2211dbd37b72	DELETE_PAYSLIP	Payslip	841c864f-85d4-42d5-a9a3-faf99bcccd0d	net pay 1050.00 (staff Repro Payroll Staff)	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-19 08:07:29.037541+02
a31dba0c-c59c-453e-876b-d45e414020e9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:23:47.33574+02
643c8e7f-096e-4261-9777-3f2f80603a09	CREATE_USER	AppUser	247effb9-e8ea-4584-9b85-e878433cdfae	perm-verify@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-20 21:23:47.72622+02
c56c7ca1-0a6f-401c-bf13-b5c257fb2f47	UPDATE_ROLES	AppUser	247effb9-e8ea-4584-9b85-e878433cdfae	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-20 21:23:48.015396+02
f9463c23-a5e6-4127-a142-a8b18c259d46	UPDATE_ROLES	AppUser	247effb9-e8ea-4584-9b85-e878433cdfae	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-20 21:23:48.105013+02
70858c68-22c1-43cf-bb59-82a1ff98379a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:24:04.94695+02
2831a565-cd71-4c0c-9988-d28fef2a822c	DELETE_USER	AppUser	247effb9-e8ea-4584-9b85-e878433cdfae	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-20 21:24:05.046498+02
30f39de9-e312-42c9-a61f-2001f108c6ab	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:26:57.072606+02
719a65d4-eebc-4088-8fe9-94078a8506c3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:27:58.013964+02
dba69cde-e4d5-42e4-9086-aea456f4a745	PROVISION_STAFF_LOGIN	Staff	dfbe1835-1852-4de9-8fa2-b23310573dd1	scope-test-teacher@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-20 21:27:58.333747+02
c982a91a-d0a3-454f-a4a0-ee0d6e2a5904	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:28:29.144604+02
e8253f3d-b06e-44af-8b61-35ea4f1da857	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:28:41.577382+02
32bb5028-90ba-4d14-8e6e-425a9005406c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:29:03.908287+02
ee76eb7e-4c2f-4bea-8f66-bc6f55770710	LOGIN	AppUser	a14fd093-3824-4312-9c8c-b64517460241	scope-test-teacher@school.demo	\N	2026-08-20 21:29:19.821341+02
db164df8-f2dd-47eb-a940-cf9c8042283f	LOGIN	AppUser	a14fd093-3824-4312-9c8c-b64517460241	scope-test-teacher@school.demo	\N	2026-08-20 21:37:39.460436+02
c4873b49-8418-4740-8195-34276409c2d1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:37:39.945891+02
fc849a1f-db03-4968-ba98-6948fb0d94eb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:38:03.698503+02
695e0868-55c9-4dc7-b0b0-9b1bb62ecd30	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:38:22.29677+02
646dde63-9ad1-4543-b223-71e0c86d076b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-20 21:39:13.282028+02
2536edbf-635b-4ed6-ad6c-fd7d0829ef88	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:13:39.971827+02
8a6cdf46-ec76-4f5b-8cf2-68ed7b80a478	PROVISION_STAFF_LOGIN	Staff	1ff24437-e858-4e90-a287-f9cf1d43f554	t2-teacher@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:13:41.626955+02
63610a44-4725-4c51-9dcd-f28d9f9e5b31	LOGIN	AppUser	89097c3f-db6a-4051-8a2d-787854cd8020	t2-teacher@school.demo	\N	2026-08-21 02:13:53.61889+02
aab59d6a-1085-4077-9442-58e8b1bc80e3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:14:35.228854+02
5af0cda1-0a11-48a0-a0ea-1dc948badc67	LOGIN	AppUser	89097c3f-db6a-4051-8a2d-787854cd8020	t2-teacher@school.demo	\N	2026-08-21 02:14:35.766793+02
dc2530d6-90a5-45c1-8aa3-c59851980aaf	LOGIN	AppUser	89097c3f-db6a-4051-8a2d-787854cd8020	t2-teacher@school.demo	\N	2026-08-21 02:15:01.628948+02
23403e93-7f67-4a79-acb5-a0a97df0e5d4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:15:30.517574+02
5c4c0b51-5429-4412-9329-534ae0e72114	LOGIN	AppUser	89097c3f-db6a-4051-8a2d-787854cd8020	t2-teacher@school.demo	\N	2026-08-21 02:15:30.971614+02
6430dda7-bd79-4070-9405-31024dd31992	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:15:53.406107+02
97fbd7d2-8447-4f25-9523-26e88b7fe5a3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:16:04.898043+02
18230c5a-a391-41ac-a10f-123d3771bacd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:16:24.525729+02
97db9a2b-70d3-4253-a4d0-28601df0756f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:16:38.818436+02
c2bb2ca1-e957-48f9-ba4c-16c84f3bbdc2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:16:59.66959+02
3a02b45e-0df3-42f4-9900-b1c89d07ebfa	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:17:24.807347+02
e044539a-9073-4618-9e8a-33683dcd01a0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:17:39.542078+02
91bf09ca-4b46-4b63-885d-88f5eea092e8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:17:54.173668+02
231cff29-c409-428c-b55c-bdd96af5f665	LOGIN	AppUser	89097c3f-db6a-4051-8a2d-787854cd8020	t2-teacher@school.demo	\N	2026-08-21 02:18:05.598103+02
b8244a00-a52c-4f4f-9adf-1233491beb33	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:18:27.948993+02
7a19a437-8995-45f8-83ee-de46b7c95567	LOGIN	AppUser	89097c3f-db6a-4051-8a2d-787854cd8020	t2-teacher@school.demo	\N	2026-08-21 02:18:28.268021+02
3cae390d-c8b4-4617-aeb9-4ea799dcc63e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:18:45.591287+02
ae51305f-9dfa-4b55-82f0-e50eedb95ff1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:18:58.44029+02
f3aa6907-ae24-4272-96f1-e0ecb6c0c5c1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:25:15.761004+02
962d4c74-7c2f-4004-96b0-d996b2c4422e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:51:58.491139+02
7d2d9643-643d-46a2-81eb-c48a1a070d87	PROVISION_STAFF_LOGIN	Staff	5f416648-4ecc-4030-8966-ae8313ff73a8	ptc-leak-check@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:25:16.271855+02
3d0461bd-9c71-4834-b7a8-e5f29cd94c2c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:25:26.665477+02
b645ae98-5c7d-4d8a-8bb7-4b50e5ad81b2	LOGIN	AppUser	d007c52a-898b-411d-b9fc-9d55969e9eb4	ptc-leak-check@school.demo	\N	2026-08-21 02:25:45.592565+02
5c49bc27-cbf7-4246-a7c1-02fbe4f71142	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:31:16.464123+02
59fee390-a92f-4bc8-9394-6214478ffef5	CREATE_ROLE	Role	d85a185d-0418-4913-8f0d-10bd7132210e	ZERO_PERM_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:31:16.723587+02
6385b19d-9e44-4a26-8e84-33b1f7012f3c	CREATE_USER	AppUser	9d8bcee4-baa5-46be-909c-6f9dcb8388c9	zero-perm@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:31:16.963396+02
98c626a4-5046-4b45-872d-27dcfd94fd17	LOGIN	AppUser	9d8bcee4-baa5-46be-909c-6f9dcb8388c9	zero-perm@school.demo	\N	2026-08-21 02:31:51.252905+02
f3328996-4620-4c96-9b53-69d11416d996	LOGIN	AppUser	9d8bcee4-baa5-46be-909c-6f9dcb8388c9	zero-perm@school.demo	\N	2026-08-21 02:32:08.865569+02
6c9aee5d-aeb9-471b-b844-35378adbb857	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:32:27.053437+02
087b4a9a-416d-4b1c-8bab-81175ff8421d	LOGIN	AppUser	9d8bcee4-baa5-46be-909c-6f9dcb8388c9	zero-perm@school.demo	\N	2026-08-21 02:32:27.580056+02
2e9b6904-75b6-4cff-a5cd-3ec9518db40c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:32:43.779672+02
a8888e8d-5b7c-4afe-9c18-113e1f48eb4e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:33:04.461962+02
f1204863-f581-4d9d-85c6-eed364692b2b	DELETE_USER	AppUser	9d8bcee4-baa5-46be-909c-6f9dcb8388c9	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:33:04.582363+02
13fbaf27-8ad3-4f00-865b-05b84060cd89	DELETE_ROLE	Role	d85a185d-0418-4913-8f0d-10bd7132210e	ZERO_PERM_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:33:04.668616+02
f3cc7e92-4482-4dcd-8660-419ced4bc5c7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:33:18.70924+02
a76dd78b-221e-4781-b3a0-1d2de41caea7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 02:33:30.841504+02
57dd4179-056f-46a9-91d7-efb16da1503c	DELETE_USER	AppUser	a14fd093-3824-4312-9c8c-b64517460241	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:33:31.384152+02
13abc8d4-bf67-432b-bea1-ecceefa8c30a	DELETE_USER	AppUser	89097c3f-db6a-4051-8a2d-787854cd8020	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:33:31.87051+02
6de1b264-f2b5-4884-8d69-002a32d69270	DELETE_USER	AppUser	d007c52a-898b-411d-b9fc-9d55969e9eb4	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 02:33:32.288219+02
f91192ff-4b01-401a-a0d9-bd093515f7ba	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 03:09:26.045887+02
56003eb3-5415-4edf-8046-f38864f49370	CREATE_ROLE	Role	88fec70d-cafa-4488-96a7-3c5707792615	UI_TEST_ROLE	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:11:38.964536+02
054fa647-2928-4edf-a59d-fe4eac609b64	CREATE_USER	AppUser	98b8b89f-8c87-4af8-9041-bcc52c086642	ui-test-user@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:18:08.384236+02
c74a555f-2a0e-4b96-8abc-72de697b721a	DELETE_USER	AppUser	98b8b89f-8c87-4af8-9041-bcc52c086642	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:19:37.754166+02
9040fa84-ad51-486e-bae3-40b7f9eaa5cf	CREATE_USER	AppUser	3e82d7a2-015a-4e46-b6ad-83330a79a452	ui-test-user@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:21:00.578007+02
c32aefdf-f481-42de-ac24-9b98ac9021ed	LOGIN	AppUser	3e82d7a2-015a-4e46-b6ad-83330a79a452	ui-test-user@school.demo	\N	2026-08-21 03:21:48.546085+02
317bc538-9d14-4820-a381-0f559dcdc10d	LOGIN	AppUser	3e82d7a2-015a-4e46-b6ad-83330a79a452	ui-test-user@school.demo	\N	2026-08-21 03:26:25.931015+02
760fb9a2-0347-4aa6-aa8e-c8f5ceb170fe	LOGIN	AppUser	3e82d7a2-015a-4e46-b6ad-83330a79a452	ui-test-user@school.demo	\N	2026-08-21 03:27:22.359664+02
962ccab2-a6fe-4510-8fa5-3a70d2960a80	UPDATE_ROLES	AppUser	3e82d7a2-015a-4e46-b6ad-83330a79a452	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:28:01.606182+02
4d8c4a31-e847-4bbe-ac2a-fde55c16e58e	DELETE_USER	AppUser	3e82d7a2-015a-4e46-b6ad-83330a79a452	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:29:08.603092+02
7c22732a-c928-4c5e-aa66-b0585f32eca7	DELETE_ROLE	Role	88fec70d-cafa-4488-96a7-3c5707792615	UI_TEST_ROLE	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:31:08.378895+02
b6960e1f-c882-4be2-9415-cf9b0e7aed15	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 03:35:31.735734+02
9d2e9ebb-fe87-4049-9ebf-77e9a483e298	CREATE_USER	AppUser	b2e666c0-299a-4d7e-894e-7cba2786dc9b	pwcheck@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:35:31.960461+02
036d3dd6-927a-4b53-910d-b81237156c74	LOGIN	AppUser	b2e666c0-299a-4d7e-894e-7cba2786dc9b	pwcheck@school.demo	\N	2026-08-21 03:35:32.145338+02
7f47ad32-efc5-45c8-9831-ce04dc6ac02f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 03:35:47.443859+02
1c08ae56-a354-4369-8c56-6dcb4066143b	DELETE_USER	AppUser	b2e666c0-299a-4d7e-894e-7cba2786dc9b	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:35:47.540382+02
0dbd7a71-f0b4-4256-8da9-d6780ef3cbe0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 03:42:45.309601+02
cff1dc3e-cb8f-4f2f-8405-8801eec11c8f	CREATE_ROLE	Role	2b9883da-3ea6-4d6b-9d6e-67e9987510bc	UI_TEST_ROLE2	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:42:45.55916+02
733e4d6b-cb90-41bf-a4a4-aa0bb775ea04	CREATE_USER	AppUser	7818990e-d1dd-4008-b0fd-dd0312c5888f	final-verify@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:42:46.478728+02
237b1e27-02d7-4385-8f3d-103b060420f9	LOGIN	AppUser	7818990e-d1dd-4008-b0fd-dd0312c5888f	final-verify@school.demo	\N	2026-08-21 03:42:46.685295+02
2eb1ca95-7023-4239-bcc8-383994b11720	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 03:43:08.140538+02
93e4fe7c-18d9-4b5b-ab4a-ee66bb619f9c	DELETE_USER	AppUser	7818990e-d1dd-4008-b0fd-dd0312c5888f	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:43:08.261332+02
cb202f73-9d4c-4e12-bd0b-4205e1400e2c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 03:43:22.212447+02
93239ef7-5541-419a-be90-bdbdab010c71	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 03:43:32.312471+02
f0e4d994-211c-4f3f-b9c2-ed290182acd7	DELETE_ROLE	Role	2b9883da-3ea6-4d6b-9d6e-67e9987510bc	UI_TEST_ROLE2	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 03:43:32.439719+02
b373db4a-0417-42c8-9972-c2dc8fbbd294	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 04:18:21.862143+02
316e9f07-ce6b-4657-9bef-957a239e13ca	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 04:22:19.746556+02
35bbb7fd-59f9-4d04-a032-7cb296b07f7f	CREATE_ROLE	Role	49407b1f-bd9e-4a95-96cb-010ebdaa9558	VIEW_ONLY_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 04:38:23.004568+02
416abbef-9a0c-4629-9d1f-fbc2cfbcd113	CREATE_USER	AppUser	8a8ab1b1-7f93-4b56-b243-1550abe7a6b0	gating-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 04:48:37.018615+02
2e0d93be-fa18-4487-a3b3-4ee40411d83c	LOGIN	AppUser	8a8ab1b1-7f93-4b56-b243-1550abe7a6b0	gating-test@school.demo	\N	2026-08-21 04:51:32.05674+02
0d24be93-f231-483f-bda2-a8298cb5cced	DELETE_USER	AppUser	8a8ab1b1-7f93-4b56-b243-1550abe7a6b0	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:01:44.759325+02
dc4bc0e0-31b3-40a8-b310-480c44ed27db	DELETE_ROLE	Role	49407b1f-bd9e-4a95-96cb-010ebdaa9558	VIEW_ONLY_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:09:41.081046+02
03d30f02-d6e6-4735-8b48-c058770d15a7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 05:50:14.454822+02
7db3be51-8afa-4a7e-9d99-5f1b4372bd96	PROVISION_STAFF_LOGIN	Staff	b36389fb-4b4e-442c-9f1c-4a5c1b54f932	v23-teacher@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:50:15.039437+02
b77c41cb-0d29-407f-a7c9-b6d7d094d6ba	CREATE_ROLE	Role	056cb17c-48d0-48de-ae47-d9b493b2c5c7	V23_ZERO_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:50:15.126982+02
28976a3e-b17f-45fa-9bc7-b9a1f300e83f	CREATE_USER	AppUser	59caf006-518d-43ff-9141-9d4b186fae65	v23-zero@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:50:15.515009+02
6f324f7e-7edb-48ea-8475-906e5b273333	LOGIN	AppUser	a6831f03-85cf-4fa0-9a7d-0d112ee4ed23	v23-teacher@school.demo	\N	2026-08-21 05:50:15.75879+02
59b18870-0a68-4c31-8942-9bf80cdcca71	LOGIN	AppUser	59caf006-518d-43ff-9141-9d4b186fae65	v23-zero@school.demo	\N	2026-08-21 05:50:15.999676+02
bc11b7b1-ba0f-4bc4-9229-8810e9a22cbe	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 05:50:35.406293+02
026848f1-38c8-4262-a7f5-58a38f7dbd46	DELETE_USER	AppUser	a6831f03-85cf-4fa0-9a7d-0d112ee4ed23	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:50:36.094001+02
ae6c50d2-0668-4c44-a03b-c352c110c2bb	DELETE_USER	AppUser	59caf006-518d-43ff-9141-9d4b186fae65	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:50:36.550989+02
4d280fdf-0da3-497d-98ba-942cea1102c2	DELETE_ROLE	Role	056cb17c-48d0-48de-ae47-d9b493b2c5c7	V23_ZERO_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:50:37.169055+02
0a2192c8-5a0a-4c5c-8df6-b8d9d4b55d4d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 05:55:54.290916+02
84d259b4-0c3a-46d9-b573-b799ee139bb6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 05:56:03.343096+02
753d4318-085a-4ea5-b24c-ba143b384f0c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 05:56:23.726493+02
f661e912-29ce-49b2-ac7c-31843cfd931d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 05:58:30.69278+02
80ea8e75-a42a-4b82-a90f-4d247462c484	CREATE_ROLE	Role	9869acba-f5d4-4427-9c74-cc358624370c	NO_DOCS_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:58:38.024961+02
10cd077d-2626-442f-b929-32c4b4b2b31f	CREATE_ROLE	Role	4e8a0b5a-be8f-403b-bb8c-5eeebfd848b3	CANTEEN_VIEW_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:58:40.970513+02
324474ec-ac41-406c-a3fe-3f6cc15803a7	CREATE_USER	AppUser	8de341da-add4-4adc-a419-15286ddd9d5a	no-docs-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:58:45.925781+02
1feec96c-a40f-4372-81d3-c16d490e0651	CREATE_USER	AppUser	1a799464-9da0-462d-969a-1b0b503a5927	canteen-view-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:58:48.59726+02
c45adb7c-66f5-4046-84b0-6692604ea92d	LOGIN	AppUser	8de341da-add4-4adc-a419-15286ddd9d5a	no-docs-test@school.demo	\N	2026-08-21 05:58:51.650484+02
6067a5e1-bb2e-47a9-bb6d-4aa2bc00396a	LOGIN	AppUser	1a799464-9da0-462d-969a-1b0b503a5927	canteen-view-test@school.demo	\N	2026-08-21 05:58:59.094328+02
9a354f8f-8231-45fc-bf1d-3877bbeaad27	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 05:59:06.769499+02
b485f5b4-1f51-4a2a-869c-c5a9e948544d	DELETE_USER	AppUser	8de341da-add4-4adc-a419-15286ddd9d5a	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:59:08.88105+02
75b544e4-c7c4-4400-8e5f-1f9f57392264	DELETE_USER	AppUser	1a799464-9da0-462d-969a-1b0b503a5927	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:59:09.695506+02
d74b4e9e-c6ce-4493-bfb5-e571c5ed2914	DELETE_ROLE	Role	9869acba-f5d4-4427-9c74-cc358624370c	NO_DOCS_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:59:11.135452+02
39bb347c-95d6-45c3-a8df-033e77e8879b	DELETE_ROLE	Role	4e8a0b5a-be8f-403b-bb8c-5eeebfd848b3	CANTEEN_VIEW_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 05:59:11.982874+02
39e49ac4-b122-4621-b82f-5a2840cc334b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:01:04.396777+02
e4060aff-ff1c-4cf6-bf15-465e7a21b52a	CREATE_ROLE	Role	5b9df9b7-cc9f-4b44-b47e-533fe3a3d779	NO_DOCS_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:11.850083+02
025c0102-dc7d-4721-b550-3afb3b5f6433	CREATE_ROLE	Role	a4e5a60a-a362-4d45-a4ce-a3c4b15be31d	CANTEEN_VIEW_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:14.762002+02
ce85569c-3af2-4deb-a096-acd8080f3f09	CREATE_USER	AppUser	cb8d1a1f-8dfa-49e5-8206-865ffb3c532d	no-docs-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:19.787772+02
95b63439-35f4-4a81-aa5d-d13b3846d292	CREATE_USER	AppUser	31f9d79d-f154-4e91-bbcd-b4ec749ea7f9	canteen-view-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:22.566176+02
28c4283a-d755-4361-92da-414cbffa536f	LOGIN	AppUser	cb8d1a1f-8dfa-49e5-8206-865ffb3c532d	no-docs-test@school.demo	\N	2026-08-21 06:01:25.834876+02
de67503b-43cb-4bc6-b312-518e4fe33afc	LOGIN	AppUser	31f9d79d-f154-4e91-bbcd-b4ec749ea7f9	canteen-view-test@school.demo	\N	2026-08-21 06:01:33.230305+02
b2b2e2fd-2dcc-4752-923e-8bc1f1abecfc	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:01:41.343255+02
32c37d06-a000-4691-8f80-d3355fc7a9ad	DELETE_USER	AppUser	cb8d1a1f-8dfa-49e5-8206-865ffb3c532d	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:43.396299+02
90aadade-2d44-4249-a698-e0add3ea8bc7	DELETE_USER	AppUser	31f9d79d-f154-4e91-bbcd-b4ec749ea7f9	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:44.207588+02
aa353ac4-2c6a-4507-8d5f-70ecf813c77f	DELETE_ROLE	Role	5b9df9b7-cc9f-4b44-b47e-533fe3a3d779	NO_DOCS_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:45.765615+02
13ae1b25-458b-41bd-a763-9279098da9fc	DELETE_ROLE	Role	a4e5a60a-a362-4d45-a4ce-a3c4b15be31d	CANTEEN_VIEW_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:01:46.625554+02
3c2ca96b-ce48-449f-b01a-c82e0b837e4c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:11:02.026004+02
1ae4dc9e-adc3-4879-9eb6-2ff56033e739	CREATE_ROLE	Role	ebaed809-9b52-4449-ab85-942c1bdf7e89	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:11:03.948089+02
8a6b55ce-faca-4d18-9157-7785dba2a8d2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:12:10.667678+02
a116e71c-ccea-40e1-a2df-5b920309470e	DELETE_ROLE	Role	ebaed809-9b52-4449-ab85-942c1bdf7e89	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:12:12.981511+02
284c2387-9676-4e95-aacc-6186ca70c938	CREATE_ROLE	Role	4deb502a-c67b-4602-8482-048900197a2c	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:12:14.304491+02
bb0de0d2-f588-4649-8cf5-6ce93c24ee97	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:13:09.966035+02
7b2d16b5-f7f9-4512-9653-a77c488f1066	DELETE_ROLE	Role	4deb502a-c67b-4602-8482-048900197a2c	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:13:12.320554+02
d9fe9569-1734-4111-85a8-b6dd6e0437e9	CREATE_ROLE	Role	ea617f02-055f-4a64-a14b-a6ae137e26f8	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:13:13.618946+02
6d66e7ad-f943-4927-9051-b14c829e76e1	CREATE_USER	AppUser	2537efe9-dbd6-43f6-bab8-795c51be7435	toast-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:13:16.133081+02
ce2f4f41-0185-4300-9626-79d88a0e2da1	LOGIN	AppUser	2537efe9-dbd6-43f6-bab8-795c51be7435	toast-test@school.demo	\N	2026-08-21 06:13:19.057359+02
1888f00d-932c-47c4-b488-bdfb40cb4277	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:14:36.656764+02
a6f84001-a6b0-4481-b14a-b79a8062feb8	DELETE_USER	AppUser	2537efe9-dbd6-43f6-bab8-795c51be7435	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:14:38.580871+02
9ab906fd-d60b-45ed-83d5-a4eed1054047	DELETE_ROLE	Role	ea617f02-055f-4a64-a14b-a6ae137e26f8	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:14:40.018673+02
2ab694a0-6523-42a5-88ca-7ee5b431fa24	CREATE_ROLE	Role	c6e80dc0-5aae-4d36-89f2-6279971f24cf	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:14:41.196948+02
15334179-b41a-4911-93a7-a99accd24164	CREATE_USER	AppUser	6fbb92f6-0b62-4ca8-bd5f-d16a935d7be2	toast-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:14:43.55477+02
12beaf0a-3167-4418-a407-7e3edcf7c6bf	LOGIN	AppUser	6fbb92f6-0b62-4ca8-bd5f-d16a935d7be2	toast-test@school.demo	\N	2026-08-21 06:14:46.681954+02
88a0e5f5-6026-4a2e-9cbb-ae2489b9b7a8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:15:27.789507+02
1c066263-6518-4a37-86a6-8bf36b76ef44	DELETE_USER	AppUser	6fbb92f6-0b62-4ca8-bd5f-d16a935d7be2	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:15:29.77909+02
7bc7da9d-1f72-4ea5-926b-e7fd4573be8c	DELETE_ROLE	Role	c6e80dc0-5aae-4d36-89f2-6279971f24cf	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:15:31.230445+02
4959370f-297c-4787-8d39-9951b78f409a	CREATE_ROLE	Role	16c488d4-1403-43cb-b115-0a6a5d18d101	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:15:32.409652+02
82dd17bd-eb49-423c-a7d2-c64c76323e75	CREATE_USER	AppUser	b19da5bc-5bac-42e3-a352-da51b7f94374	toast-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:15:34.814527+02
6bb0eff6-f1a0-4cfc-99ce-b09623432906	LOGIN	AppUser	b19da5bc-5bac-42e3-a352-da51b7f94374	toast-test@school.demo	\N	2026-08-21 06:15:37.680806+02
9eb223a9-b477-4b28-850d-6dc5f59a4834	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:16:09.112292+02
f32e1ca4-6695-4189-ac3e-5e1fe17c450d	DELETE_USER	AppUser	b19da5bc-5bac-42e3-a352-da51b7f94374	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:16:11.028207+02
2eeea679-1756-48e0-80c5-7abbc97da803	DELETE_ROLE	Role	16c488d4-1403-43cb-b115-0a6a5d18d101	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:16:12.477292+02
9b9aaae8-aab2-4473-b438-bcbc9c9cbebf	CREATE_ROLE	Role	0d6cded5-d004-450c-be19-6851e2a66dab	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:16:13.658402+02
5274e0cb-a185-41ea-a2e4-ef9e5c62301e	CREATE_USER	AppUser	b8ff7b25-8368-4c03-9792-3d0520b16782	toast-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:16:15.978155+02
1c77b055-4dc6-4cb9-9a45-ba7ef66ff4bf	LOGIN	AppUser	b8ff7b25-8368-4c03-9792-3d0520b16782	toast-test@school.demo	\N	2026-08-21 06:16:18.83547+02
7eb8c4de-1f86-4b81-8fa4-dc5d1db5b47e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:17:01.876359+02
576500f1-e1a2-45ec-bbac-f8f694e7fc0d	DELETE_USER	AppUser	b8ff7b25-8368-4c03-9792-3d0520b16782	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:17:03.828224+02
25ca36a7-b093-4490-ab10-07552bde7864	DELETE_ROLE	Role	0d6cded5-d004-450c-be19-6851e2a66dab	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:17:05.24045+02
439d0022-2da6-4b22-937f-a30460b9de40	CREATE_ROLE	Role	981501e1-c153-47e1-8170-87f1ec252d47	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:17:06.421174+02
3fb3686f-0d37-4bf8-92fc-322fb6ddb169	CREATE_USER	AppUser	c0e22472-b3d2-44db-b9bf-75a553b006d6	toast-test@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:17:08.83319+02
c0cb9a79-b9b7-4d5d-8c18-fe9129ff2c53	LOGIN	AppUser	c0e22472-b3d2-44db-b9bf-75a553b006d6	toast-test@school.demo	\N	2026-08-21 06:17:11.59101+02
ecd104dc-f273-4cfc-aa91-c786d03c26a4	DELETE_USER	AppUser	c0e22472-b3d2-44db-b9bf-75a553b006d6	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:17:17.409287+02
a295ebc2-1284-4a2f-8713-5aa6ccd1c256	DELETE_ROLE	Role	981501e1-c153-47e1-8170-87f1ec252d47	TOAST_TEST	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-21 06:17:18.522378+02
2105f510-ffa4-4d52-8073-33e230d5f099	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-21 06:18:10.678361+02
9c335bb5-7a38-4409-b8d4-e28f53ee0c48	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 20:45:24.425332+02
8608e079-6c46-40ce-bf80-2e4d26ff5b64	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 20:52:27.297593+02
3b82e304-280f-4022-a27d-6be22b921341	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 20:54:42.309343+02
57825975-913b-41df-9b56-4544d386e45f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 20:54:48.447196+02
dbd1bbe3-1150-4e70-afb9-e2240b98f7bd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 20:57:07.32393+02
89c52f48-3feb-4e2b-a296-f8dacf94c340	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:00:34.473226+02
494f612e-5578-4998-8e48-6ac00aff5caf	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:00:35.816848+02
82dc17bf-9246-42dc-bbc8-930f6a31f668	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:01:01.639738+02
e6fc0dc8-8f16-48a3-97bb-71bcd84579f8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:01:27.484417+02
0239a638-6b4a-458e-b4d6-672cd17896c2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:01:56.191523+02
0d597ee6-5918-4039-81f6-7c10f5f0ead0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:02:04.812195+02
ea87ba77-8379-49c2-a217-e99f3cccb698	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:02:51.35201+02
06d40097-622f-4ae2-9a08-b1b0d22ac613	CREATE_USER	AppUser	1c627232-4894-46a6-abea-b52b436817db	qa_test_teacher@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:02:51.686161+02
53d5e271-e2cd-4290-a479-a8e0a75950ef	LOGIN	AppUser	1c627232-4894-46a6-abea-b52b436817db	qa_test_teacher@brightminds.test	\N	2026-08-23 21:02:52.558226+02
9f3d8447-55ea-4875-9a67-75670be8ff01	DELETE_USER	AppUser	1c627232-4894-46a6-abea-b52b436817db	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:02:52.988406+02
c0f7cf2b-254f-446b-b105-e090faae7b61	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:03:56.426193+02
76e75ae8-6187-4d9f-ae13-aa87113385fb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:06:42.628372+02
dafe221b-7595-4e73-867a-e8f23a739e57	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:07:09.091184+02
52cdad48-1943-4261-b743-9327f6f0e539	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:08:11.736489+02
013b3436-c45c-4820-90d0-cee3c5606e2e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:09:14.91135+02
52c7de99-fced-45c7-b0bb-2fac3858a390	CREATE_USER	AppUser	9e933842-965d-4e44-9401-608d5e987c25	qa_test_headteacher@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:09:15.185726+02
18fdb31b-0b01-4144-88f3-ae7a1b4d2ea8	LOGIN	AppUser	9e933842-965d-4e44-9401-608d5e987c25	qa_test_headteacher@brightminds.test	\N	2026-08-23 21:09:19.6214+02
a224d982-4843-4641-9816-f5f93e67a9eb	DELETE_USER	AppUser	9e933842-965d-4e44-9401-608d5e987c25	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:09:22.269451+02
b75c8a9a-92e4-45cb-8df6-049df13cd430	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:09:33.704547+02
ecfcb98a-9c80-4168-aefb-f2a230feedb9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:10:08.017527+02
e6d2d63d-4607-4f0d-ac45-bc1ecf58480f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:10:22.387856+02
4d89b4f8-6865-4290-9f01-dba04865063d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:10:52.796382+02
2d50106b-d24e-4b8f-a400-840f8f9478d4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:11:10.27073+02
5530df02-d48f-4e77-a3ac-632de8732378	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:11:33.83859+02
e2584424-b81a-4354-965c-f0efd0db9386	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:12:22.225123+02
ac910762-870c-4cb1-ba32-136b34a23298	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:13:32.877654+02
4376afb2-5a7b-4786-935f-692d62d14fe1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:13:45.103607+02
53f85bf8-8015-4077-8cb4-038eb6ae0932	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:16:09.158105+02
60b16cbe-7aed-4be4-8216-f021c4ffdc42	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:16:23.731451+02
37e4d6d7-28ab-4010-9e3b-ca0522744228	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:18:38.394671+02
e7d9c5c2-44d0-4276-8fa9-8969aee84920	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:20:12.395571+02
bb37b231-8032-49f1-a5c6-97516987f70b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:21:31.525198+02
5c27085b-d108-4855-a268-fa7478a81a50	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:24:33.714128+02
fe6aa02f-74ea-425b-b13f-41c151e14f8d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:25:12.887688+02
e4d46148-883b-4daf-8b02-ba8f6883e63d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:26:43.853182+02
eaaf484b-6a2c-4832-803f-9241358419d0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:26:49.364699+02
18fddf60-74f2-4ea7-9d5e-e7feb7e2dcb6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:30:35.390943+02
aa27a20d-f31f-4c6f-a655-da6caf79835e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:32:05.462604+02
b68c1b01-5b57-402f-89a9-310bc669ac39	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:33:07.217478+02
f9898f17-b935-49d3-b4eb-abadebfe2c24	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:34:27.974676+02
79c66151-6335-4df7-ba39-67b2e3d80013	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:35:37.966833+02
dd763dd6-f367-440a-9c69-1af3d261fbb1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:37:34.756517+02
54d80728-6e67-492a-af36-a841af27da32	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:39:56.802479+02
e05ac8ed-18e9-4552-926a-cb2d29febfc6	CREATE_USER	AppUser	f5b11df2-6054-4d11-9f3f-a2401c11df6e	qa-test-user@school.demo	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:40:02.656809+02
7c8bc020-df88-47ad-84f8-a207463f83d6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:41:42.701151+02
2d442c1d-93d4-4206-b545-4076a23daf62	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:42:53.9447+02
f6bbac2e-21a4-4f83-af09-3bbd9f235f0e	UPDATE_ROLES	AppUser	f5b11df2-6054-4d11-9f3f-a2401c11df6e	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:42:58.290855+02
a89799bc-6d72-4eb2-a3a3-c0c2b221be10	DELETE_USER	AppUser	f5b11df2-6054-4d11-9f3f-a2401c11df6e	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:43:01.584074+02
ac72bcfd-3c33-43c0-81a0-24913a427bbf	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:45:13.538143+02
e7a31d6c-b1df-4a56-ad9f-342e401b988e	CREATE_ROLE	Role	9a922d5d-2850-4381-9ec4-2c5ac58a8b26	QA_TEST_ROLE	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:45:17.580776+02
a1ddba60-1304-48cf-959c-769bdb1801ab	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:47:54.050616+02
92bc70e4-567e-4e7c-b9ef-ac88ce72c42a	DELETE_ROLE	Role	9a922d5d-2850-4381-9ec4-2c5ac58a8b26	QA_TEST_ROLE	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:47:58.984449+02
fa577887-dad9-4c4c-a44f-c504ec879024	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:49:08.070168+02
ddf0fd87-0a2e-4000-a915-d9a6c4548362	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:53:32.729677+02
1522723d-2229-4681-b98f-832328319a48	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:55:09.960444+02
b6694d5f-a433-401c-8198-84fd57117935	CORRECT_PAYMENT	Payment	f954cd8f-d50f-47b3-b20a-31ae83eec265	amount 123.45 -> 100 (receipt RCT-260823-9742)	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:57:02.873717+02
96749a92-ce51-48d4-8678-173f5901908c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:57:08.123947+02
4c2f1d2f-5a47-4f7e-ae17-74b6fe0a9a77	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 21:58:23.000744+02
fae2d65b-1fb3-4a1b-a7af-7ab067153877	DELETE_PAYMENT	Payment	f954cd8f-d50f-47b3-b20a-31ae83eec265	amount 100.00, receipt RCT-260823-9742, pupil test pupil	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 21:59:43.376005+02
e2de5a55-a1e0-4c65-ad43-6a4d6286662c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:04:47.867502+02
5fab6248-5270-49a0-af93-a42722bcae1b	CORRECT_EXPENSE	Expense	7edc5f02-1c4b-4a47-9220-be4489f514a1	amount 42.50 -> 55	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:06:53.855808+02
704ddd7d-7ae1-4bd7-be5b-38ab0f3e834f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:07:04.406365+02
6dba297c-2ebe-4989-a64f-8789ca3d1141	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:07:40.553359+02
6001ae22-82e9-43e9-b0fc-7fd49908520c	DELETE_EXPENSE	Expense	7edc5f02-1c4b-4a47-9220-be4489f514a1	amount 55.00, payee QA_TEST_ Payee	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:07:59.521015+02
462f6691-a4b5-4b39-bb6b-6f5168581793	CORRECT_PAYSLIP	Payslip	cd8c3029-9f05-4405-b2b8-2d84a634c2c8	net pay 5150.00 -> 6150 (staff QA_TEST_ Fixture Teacher)	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:15:40.555083+02
bb9ad96c-a953-4968-bc4f-2fc461f2145d	DELETE_PAYSLIP	Payslip	cd8c3029-9f05-4405-b2b8-2d84a634c2c8	net pay 6150.00 (staff QA_TEST_ Fixture Teacher)	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:16:48.337407+02
16f83144-778c-4252-9d78-f66853d7661f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:31:53.441947+02
21077cf4-6419-4c1b-8259-7f8355a66770	DELETE_INVOICE	Invoice	7411c0b5-5a70-43f7-ac68-fe0d502179e3	invoiceNo INV-260823-BD46, total 10.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:31:54.86451+02
417568a6-d19c-45fc-95b2-80767818f565	DELETE_PAYROLL_PERIOD	PayrollPeriod	d421d610-686b-416d-8a77-a59fc2530210	label QA_TEST Period Del	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:31:55.564446+02
2397b3d6-fab9-4513-b1c8-e704c5f6eb75	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:32:15.9466+02
d7f239df-5e74-4a8d-8d6b-cddfefba361e	DELETE_PAYMENT	Payment	41663d62-6050-4a0c-a59d-cf0d9eef9bbd	amount 50.00, receipt RCT-260823-DA62, pupil test pupil	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:32:17.765629+02
f0872c2e-d8d7-403d-864d-4cfec3f7a31d	DELETE_INVOICE	Invoice	c7a62e9b-bbb3-448d-8a86-8aa378fff2f7	invoiceNo INV-260823-85EC, total 50.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:32:17.88088+02
c83f3678-11ee-4dd8-a3e3-e387491d334c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:32:51.98604+02
b0141242-f7fa-40c2-bb54-20f8ac95eee9	DELETE_PAYROLL_PERIOD	PayrollPeriod	79cb15b7-8c16-4e3d-93d5-e17bfffbca64	label QA_TEST_ Period Browser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-23 22:33:01.8124+02
f0319646-68d1-4948-86da-b74ac5ab36ac	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:42:02.099448+02
3e5c64d5-5b5c-45dd-9b32-047d67374228	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-23 22:42:20.60961+02
eb09fad9-2a78-48f3-9787-126ce60fe741	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:03:53.764051+02
c37c2abd-3da8-4a57-a0a5-d448302c844f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:06:47.962118+02
7584d2b3-89ca-4e9a-9d0d-d8682536f9ac	CREATE_USER	AppUser	e1289281-a275-40e2-b774-482f0c1d1783	qa_test_canteen_teacher@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:06:49.513787+02
d3590f0a-bed0-4526-846b-4819f93205e4	LOGIN	AppUser	e1289281-a275-40e2-b774-482f0c1d1783	qa_test_canteen_teacher@brightminds.test	\N	2026-08-24 03:06:50.181932+02
e98a2a73-a4e3-47f6-aa57-6ea0157b10b9	DELETE_USER	AppUser	e1289281-a275-40e2-b774-482f0c1d1783	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:06:50.716845+02
951f993b-09d6-4dfc-81ac-68c9c287e270	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:07:39.85888+02
ff2df47f-9a57-40f2-a1f6-9635a493470a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:08:50.826234+02
691c9fd6-cc18-445d-8fc2-eb787171e8c9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:10:27.916593+02
ba60a972-3813-414a-ae92-e27dab46bc23	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:11:00.313199+02
f70d1779-262d-45e4-a893-a6959aa313de	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:11:14.203705+02
d52aeb16-0b34-42b0-9b84-9bf99daf74bf	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:11:30.932732+02
ad6f6904-bab2-4a6c-820a-9d5e807092d5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:17:14.808858+02
d3f8a534-6baa-4f85-9886-2f485d95dc20	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:20:56.001908+02
fc4a4a65-be0e-47ae-9840-57eeb445f0f5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:21:49.868246+02
848314f9-104f-44f9-8f3e-4e516140d9eb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:21:52.21756+02
5899c8b0-9374-4d59-9f48-3cd11a29f1d9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:23:04.063914+02
c26e2668-65c3-41c0-82ac-f511b48bbd86	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:23:06.201159+02
e011ed46-80ee-4fbd-b517-3afc45f2f5ff	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:23:33.832488+02
81fdbf5e-757d-4d7b-92a4-b172a4de05cd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:26:33.568184+02
0a0ee278-eea1-4619-b088-88e6db4fa066	CREATE_USER	AppUser	6f63533c-326e-4a87-b628-521efb11c566	qa_test_parent_dash@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:26:33.731725+02
9a9f1db9-fafb-42fc-9583-b58fc7b7defc	LOGIN	AppUser	6f63533c-326e-4a87-b628-521efb11c566	qa_test_parent_dash@brightminds.test	\N	2026-08-24 03:26:36.059833+02
c89a53e4-6e32-4156-b6ae-3fd0a00c1a2d	DELETE_USER	AppUser	6f63533c-326e-4a87-b628-521efb11c566	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:26:39.921608+02
72bf8dbe-78eb-4145-bba8-7c17a267ff1b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:28:11.111865+02
542a6629-c118-4096-83ba-506ffe89cd64	CREATE_USER	AppUser	b8d2a407-72ed-49d7-90bd-1f5d18ff70aa	qa_test_parent_dash@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:28:11.277499+02
1282e749-2627-4642-b47c-f5cc8709cb09	LOGIN	AppUser	b8d2a407-72ed-49d7-90bd-1f5d18ff70aa	qa_test_parent_dash@brightminds.test	\N	2026-08-24 03:28:14.118257+02
5464d841-9352-47e4-9f72-6bb303f5b563	DELETE_USER	AppUser	b8d2a407-72ed-49d7-90bd-1f5d18ff70aa	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:28:18.169946+02
78da4016-5e66-4c13-8deb-ef564a7acf94	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:28:38.408741+02
48a2b27b-7208-4250-983f-67d3961dac24	CREATE_USER	AppUser	63e94a51-c7d5-4071-9ee3-f07d53da12ca	qa_test_parent_edit@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:28:38.564315+02
e19a2ebf-8fbf-453f-9cf4-b35891ab0999	LOGIN	AppUser	63e94a51-c7d5-4071-9ee3-f07d53da12ca	qa_test_parent_edit@brightminds.test	\N	2026-08-24 03:28:40.914351+02
981bc817-686d-4d6d-9538-d943ac222ffb	DELETE_USER	AppUser	63e94a51-c7d5-4071-9ee3-f07d53da12ca	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 03:28:43.129925+02
11b5ef6f-1da6-4efb-af4e-25718d95f135	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:41:32.86393+02
1b388628-69e8-421f-9d80-07ad93175afd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:42:42.95472+02
9e79f33d-c7ac-4d97-8779-abd1a0d8a4d2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 03:42:49.973988+02
d5089eb1-50d3-4332-939f-408671504734	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:13:34.159514+02
4c091c80-c6e0-4f9b-96e9-e7753e42bd32	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:13:45.699787+02
6c915327-e763-4dab-a30a-6dbca394f648	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:14:16.768497+02
271690c5-9a02-4632-bf3a-f1f6038c5672	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:22:50.566472+02
8a26a8d1-609c-4d4f-8796-d55950909a2d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:23:29.358363+02
d136520d-9ef7-450d-b722-02ce1bf2ce5a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:23:42.137932+02
42e3c6da-cef6-4b38-84d6-30988166f633	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:24:16.978951+02
89e5b1bf-6a06-4c5b-bd1e-fd0ba2098f60	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:24:45.011855+02
18b775c0-dd82-464e-9c72-53eed00a5406	CREATE_USER	AppUser	f59c1d99-a642-456c-b0a9-751d07dfe9fc	qa_test_head_teacher_pupils@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:24:45.190084+02
8150e6e1-9cb5-4a35-aeab-3b456abcb44d	CREATE_USER	AppUser	ff6ae965-e055-4a52-b270-f2f5498c17e5	qa_test_accountant_pupils@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:24:45.33265+02
84443d71-3005-4eb1-85bd-e971e137cd03	LOGIN	AppUser	f59c1d99-a642-456c-b0a9-751d07dfe9fc	qa_test_head_teacher_pupils@brightminds.test	\N	2026-08-24 04:24:47.910926+02
c03584e0-c0f4-4993-8831-c4e48b1e470d	LOGIN	AppUser	ff6ae965-e055-4a52-b270-f2f5498c17e5	qa_test_accountant_pupils@brightminds.test	\N	2026-08-24 04:24:55.63399+02
603a1ca7-572e-4c0c-89fb-90ec3b304ca7	DELETE_USER	AppUser	f59c1d99-a642-456c-b0a9-751d07dfe9fc	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:25:00.912801+02
7c102a7c-d9a4-41f5-9074-bedb0ff21574	DELETE_USER	AppUser	ff6ae965-e055-4a52-b270-f2f5498c17e5	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:25:00.936808+02
8ad35c16-3ba3-4701-a9e1-a86a0b65711c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:25:18.183285+02
edde9fa7-af99-4b2d-9ef0-cb5a6f616b1d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:25:42.271906+02
aed659b6-0231-4d76-b7bd-f8ae3c03c7f5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:27:12.737454+02
59b92075-c0c5-4d23-a3b5-4ad7e5a4f577	CREATE_USER	AppUser	65c58db9-25f3-4a6f-ba73-6124884edd59	qa_test_head_teacher_pupils@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:27:13.046212+02
168d1b48-dcd3-4ac5-a8b6-8ff38f8c8c1a	CREATE_USER	AppUser	daf08fa3-cbef-434e-b52a-6696aa597826	qa_test_accountant_pupils@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:27:13.198488+02
ef9b9b07-6f39-48b5-b948-f373873100f5	LOGIN	AppUser	65c58db9-25f3-4a6f-ba73-6124884edd59	qa_test_head_teacher_pupils@brightminds.test	\N	2026-08-24 04:27:15.888837+02
8be05530-fd1c-4858-83fe-528aa9345ab0	LOGIN	AppUser	daf08fa3-cbef-434e-b52a-6696aa597826	qa_test_accountant_pupils@brightminds.test	\N	2026-08-24 04:27:23.603987+02
d1ceecb5-b868-49b0-ba5b-8c49ccaa700d	DELETE_USER	AppUser	65c58db9-25f3-4a6f-ba73-6124884edd59	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:27:29.492619+02
dcd152ba-7e71-4667-82ec-36d1485d0edb	DELETE_USER	AppUser	daf08fa3-cbef-434e-b52a-6696aa597826	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-24 04:27:29.519875+02
2d719727-d236-4d2d-b8c7-a0da6431e547	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:27:41.804421+02
eaaa0e5f-78e2-4fce-a455-64685aca00bf	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:27:59.455634+02
a6f29cf3-38e3-42ff-bfe5-2577f062bfbe	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:28:12.791234+02
6dd7aa1d-2c80-447b-b14b-3a4308ba9a55	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:28:27.134121+02
80d2cb51-bc40-4373-bea3-8b4dd60c52e9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:29:07.798122+02
d7ec64b9-0bd8-4d3c-b973-f0154bcb1a65	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:29:23.466793+02
dd2eeff4-4ee4-4a9c-8944-027a7411e445	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:29:36.385521+02
5efeb0b0-da39-4c06-b1cc-e5de4efd3f11	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:30:04.698097+02
63f0b966-94c9-452a-82d0-e53eb738be10	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:31:05.596643+02
86f21c96-66dc-4a67-abfd-62472ce6790a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:31:09.833802+02
576917c7-4979-4cc1-b03a-28c8e23a8472	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:31:39.103644+02
a160d8c7-d250-40c1-9069-e462b673af40	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:31:55.905286+02
191a4db4-44f1-4591-bd7c-90e749b82419	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:32:00.220693+02
69b8c547-a1c3-43c7-b481-0a3888b3453e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:32:13.23729+02
2145b680-7292-4aae-b937-391b6863107c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:32:40.10814+02
b5bc5de8-9f0f-49a5-9ab6-80f7c0695b90	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:37:47.380201+02
e1b3d0e3-0fed-4ea7-bcb4-c9c59ab6f167	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:37:55.735772+02
82539664-baad-4ecf-a1d5-49433f188c52	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:38:45.465119+02
deaf13f9-e4a1-4231-99c2-f7fdb38d4e62	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:38:51.215742+02
f2e851df-78d0-4866-b8c0-afd5076d2c93	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:39:33.426558+02
dc40bf34-97da-4243-8f6e-13ebe3eb4d09	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:40:26.71774+02
3f504e6d-8b27-42c0-97f5-77309f2fce88	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:40:50.287861+02
d714b0a4-69d4-470b-b934-28231de9c06e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 04:41:20.915819+02
d4528289-f8ea-4c30-a784-650c94efd0f6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 05:53:15.414725+02
1f753ea3-1b27-4f60-838d-362dd9643d8d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 05:53:25.595591+02
df1de67f-ac8e-4246-a132-c717b8253c6a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 05:54:05.909861+02
c3456a36-ea09-471a-9fba-5467eaa8f781	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-24 05:54:43.845083+02
fc6316af-fc37-4a7e-8565-8afd146010f7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:26:14.003898+02
e2ae8b63-9b07-4f7d-96a5-df5de1ad9d09	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:27:53.807009+02
00ab5f29-b036-47d0-aff2-e1fd58f543c7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:28:57.715796+02
3cb4f46f-31c5-4f60-aeba-f69d754c2fa2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:29:36.999094+02
86b61c38-3878-4cc7-b838-b9afc9c89fe5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:30:25.386186+02
92507155-9ccf-42ac-b94c-5b8f4974a02e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:31:02.247303+02
562e50d5-17c4-4f6b-97b6-d1584bf65746	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:31:51.655872+02
ae8d2c6f-d792-4c0e-afc0-c468eead7a57	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:32:11.742543+02
d01bbb1a-948b-4a89-b3db-007e9c1e665b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:32:46.446384+02
f2524c16-5a92-4b9a-8c35-d0ce1987d712	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:38:49.132916+02
3188eb16-853a-453d-b356-fb5a5f6fd526	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:38:54.117921+02
5d692330-f116-4e3c-99fc-e827b27cc4c6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:39:08.637701+02
84b7e319-1f60-44a9-ae0a-073050555e22	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:40:12.974318+02
f88498e5-d388-4bf6-8569-0be7665e779b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:40:36.831798+02
61244bd4-3bff-4199-afaa-db6f54ba81ed	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:55:57.6121+02
9ff8aba1-b73e-44fb-84db-b4aeacbc657d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:58:47.068843+02
fb015717-0628-4e88-895a-1e9f18748e96	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:58:51.538249+02
d4f17833-c2e0-416d-b82b-443b7b9f0b3b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 09:59:05.134393+02
ecbb9b85-43e3-4cbb-82f8-39e468126e0d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 10:46:46.771848+02
c00e6780-5e68-4573-bc7c-a51a01b7b7f9	CREATE_USER	AppUser	035ecea8-bec9-49f4-a214-8233a9371c60	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 10:46:47.13684+02
12013bbe-6888-4402-9f05-0375769b4c18	LOGIN	AppUser	035ecea8-bec9-49f4-a214-8233a9371c60	qa_test_newuser@brightminds.test	\N	2026-08-25 10:46:54.975049+02
5b7a27b4-71a4-49b7-aa30-3b6125863fa3	LOGIN	AppUser	035ecea8-bec9-49f4-a214-8233a9371c60	qa_test_newuser@brightminds.test	\N	2026-08-25 10:47:05.73276+02
6b2bec63-6924-4273-bcc8-22d1d7c949d9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 10:47:10.25107+02
1df04073-5bff-4391-a017-5954d664679b	UPDATE_ROLES	AppUser	035ecea8-bec9-49f4-a214-8233a9371c60	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 10:47:12.945419+02
bb01556d-22af-49b3-8c4f-9e9149a67591	DELETE_USER	AppUser	035ecea8-bec9-49f4-a214-8233a9371c60	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 10:47:17.831346+02
4164c87c-6602-4c59-b6b1-f010f79efd34	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 10:47:52.181951+02
00f0d556-b935-4566-bbe8-34fbc7e7fa78	CREATE_USER	AppUser	55c01e67-ef1c-4f0c-82bf-99c29f6e1ea5	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 10:47:52.353542+02
ab1e1abb-354a-45b2-9c4a-658e5b9324ea	LOGIN	AppUser	55c01e67-ef1c-4f0c-82bf-99c29f6e1ea5	qa_test_newuser@brightminds.test	\N	2026-08-25 10:47:55.144987+02
ad82aa84-fe92-4bee-b404-e6f61185ff1c	LOGIN	AppUser	55c01e67-ef1c-4f0c-82bf-99c29f6e1ea5	qa_test_newuser@brightminds.test	\N	2026-08-25 10:48:05.93618+02
12a94f1a-be6d-4c67-88ea-de9021907b44	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 10:48:10.540456+02
29572796-de5e-4b70-a53a-3f0f60b756bb	RESET_PASSWORD	AppUser	55c01e67-ef1c-4f0c-82bf-99c29f6e1ea5	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 10:48:13.929304+02
5d55a7ff-918a-40f9-b58f-af05fbde8713	LOGIN	AppUser	55c01e67-ef1c-4f0c-82bf-99c29f6e1ea5	qa_test_newuser@brightminds.test	\N	2026-08-25 10:48:17.301202+02
7f501850-b048-417c-b32e-14dca242d2e1	DELETE_USER	AppUser	55c01e67-ef1c-4f0c-82bf-99c29f6e1ea5	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 10:48:19.329825+02
4e55ea29-ba0a-4a21-9138-66db083e1149	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 10:48:32.070469+02
31468eeb-e021-4f0a-811e-1506ab08754f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:02:14.686618+02
fb8acc3f-94fe-47cc-9f69-ccf6d10b7331	CREATE_USER	AppUser	f52ea4cb-0488-43b1-b7b9-362a73662f1e	qa_test_forgotpw@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:02:15.069322+02
84d72188-be90-45d7-95fe-9fbf5a7c02a3	LOGIN	AppUser	f52ea4cb-0488-43b1-b7b9-362a73662f1e	qa_test_forgotpw@brightminds.test	\N	2026-08-25 11:02:39.113364+02
0c7a688f-2ee9-40b0-9b1e-d45437aa080e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:02:48.157952+02
d11015a6-bc7d-489c-8925-26515eda33a1	DELETE_USER	AppUser	f52ea4cb-0488-43b1-b7b9-362a73662f1e	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:02:48.326764+02
2cd8dcec-09f1-4190-80be-41a917fce2dd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:03:49.212899+02
f9501d43-39ec-4fe6-a895-97405d4c61fc	CREATE_USER	AppUser	dcbef19e-affe-4973-80f6-04b36c0aa800	qa_test_uiforgot@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:03:49.392756+02
abe39a94-6728-4dbb-9c6c-7ea0a565228c	DELETE_USER	AppUser	dcbef19e-affe-4973-80f6-04b36c0aa800	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:04:31.24627+02
9ac0b2ca-aa7b-4e52-951e-e99f3195324b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:04:44.714931+02
91802890-d01b-483a-8116-6fd4a6c72db5	CREATE_USER	AppUser	32698572-09de-4584-8a76-2610a8c88f1f	qa_test_debug@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:04:44.960625+02
49b900e0-dbe9-4ed9-9f27-c8e08b3b5d01	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:05:50.014342+02
d7e56339-eca0-436b-add2-4bebb8e60eeb	LOGIN	AppUser	32698572-09de-4584-8a76-2610a8c88f1f	qa_test_debug@brightminds.test	\N	2026-08-25 11:05:58.028466+02
2cb9eb96-4a4c-4fe9-bad9-cad05441bc5b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:06:18.956945+02
e14e2ef7-a95d-4ac6-b425-7a569a60a95f	DELETE_USER	AppUser	32698572-09de-4584-8a76-2610a8c88f1f	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:06:19.147102+02
dbbf426b-9d75-4ac9-b0b9-073e2f633bf7	CREATE_USER	AppUser	132e8333-8dcf-4398-8d7c-8be3fc127003	qa_test_debug2@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:06:19.383044+02
a066e06f-2e82-4c1c-b04b-e1930267dd13	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:06:54.757386+02
6bee5fd9-8205-4918-bd59-70b52a2f9ec5	DELETE_USER	AppUser	132e8333-8dcf-4398-8d7c-8be3fc127003	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:06:54.869797+02
01f68cff-2878-454b-9785-2ca3adbb4066	CREATE_USER	AppUser	95b037b1-7c8a-4bf3-aac1-17c1a7e1b542	qa_test_debug3@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:06:55.103365+02
fb79d1a8-514f-46a3-8864-e30ff1067f2e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:07:49.388252+02
ae8b9458-a98c-4154-aa47-18688154c457	RESET_PASSWORD	AppUser	95b037b1-7c8a-4bf3-aac1-17c1a7e1b542	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:07:49.636128+02
d96bf0ff-081f-43df-9b21-b779bdd56511	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:08:44.652513+02
a9a5b020-71a4-43dd-b01b-d8eaa2ef8b5a	DELETE_USER	AppUser	95b037b1-7c8a-4bf3-aac1-17c1a7e1b542	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:08:44.816158+02
49147421-d8ee-47d8-a5c4-3a45f3bcba50	CREATE_USER	AppUser	ad0f11dd-3a07-40a3-af0e-d6d74f64158e	qa_test_debug4@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:08:45.072459+02
73a55bf8-7db4-4bae-90ff-edc16977d2d2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:09:16.519129+02
93160113-2c2d-41e3-89ad-8f20cee358d5	DELETE_USER	AppUser	ad0f11dd-3a07-40a3-af0e-d6d74f64158e	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:09:16.62929+02
ee2317ca-97f5-415b-bb93-cebe323906de	CREATE_USER	AppUser	f73208d8-e396-4705-9535-e006ca48000d	qa_test_uiforgot@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:09:16.86096+02
901a3b0f-20d3-4b58-95c2-6e6e7a6c31fd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:09:27.12262+02
3207c7bb-e021-4fde-9a59-3e28437e91b6	DELETE_USER	AppUser	f73208d8-e396-4705-9535-e006ca48000d	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:09:27.24071+02
06651e4c-7ca8-4126-b48a-bbc9184282e6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:09:28.340972+02
f02684e2-ab2d-49b1-90cd-2e37809b4806	CREATE_USER	AppUser	158e71e8-e9f3-418f-9ea0-e52e850c5802	qa_test_uiforgot@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:09:28.497568+02
6f12f43c-ff76-47ea-ba35-6ecff942425b	LOGIN	AppUser	158e71e8-e9f3-418f-9ea0-e52e850c5802	qa_test_uiforgot@brightminds.test	\N	2026-08-25 11:09:36.846612+02
76fa2f78-a57a-4140-8c5a-31ef0d0feae8	DELETE_USER	AppUser	158e71e8-e9f3-418f-9ea0-e52e850c5802	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:09:36.886627+02
e5b14910-bd4c-4f1e-ac86-d3440a183339	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:10:00.561835+02
26f6c67f-f545-44d8-b9a7-4662b91371af	CREATE_USER	AppUser	85b38450-cdf8-4332-b1d6-35c160f3c390	qa_test_adminreset@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:10:00.740752+02
f7e4c528-02d2-4582-b698-252f34367a98	DELETE_USER	AppUser	85b38450-cdf8-4332-b1d6-35c160f3c390	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:10:12.639244+02
2eb921f5-70e5-43a1-a7bd-b6212365fd4f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:11:09.310766+02
3d6ddde2-7d6b-4a26-84fb-6e8b36348622	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:11:28.140694+02
79cd039f-9cff-42fb-93b4-74c4fc46f9d2	CREATE_USER	AppUser	3ba9b97f-89f8-4cf1-9465-a6e1cd09d0aa	qa_test_adminreset@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:11:28.309602+02
20c289cd-0308-420e-9abe-0113a8d42f92	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:11:31.029048+02
a0763277-da65-4df9-a7e8-e98a51da18ac	RESET_PASSWORD	AppUser	3ba9b97f-89f8-4cf1-9465-a6e1cd09d0aa	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:11:33.282373+02
4d27cd3f-3989-4cba-ab4a-0dca29b41cac	LOGIN	AppUser	3ba9b97f-89f8-4cf1-9465-a6e1cd09d0aa	qa_test_adminreset@brightminds.test	\N	2026-08-25 11:11:34.769345+02
353e06f1-823c-4b61-ab80-ef4897b78050	DELETE_USER	AppUser	3ba9b97f-89f8-4cf1-9465-a6e1cd09d0aa	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:11:34.797097+02
0d93834b-54a4-4576-a2e5-d523c6e7a830	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:11:51.234096+02
9ea3e0ca-9c62-4500-9771-ac0a5cfc6128	CREATE_USER	AppUser	caf7d118-6add-4b92-bc84-f23b597f44b5	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:11:51.417103+02
af5d78a8-b68b-4377-926c-b56cba950ce4	LOGIN	AppUser	caf7d118-6add-4b92-bc84-f23b597f44b5	qa_test_newuser@brightminds.test	\N	2026-08-25 11:11:54.826801+02
d719d2a9-05b6-42f7-944b-bd1587eaeebf	LOGIN	AppUser	caf7d118-6add-4b92-bc84-f23b597f44b5	qa_test_newuser@brightminds.test	\N	2026-08-25 11:12:05.649952+02
fd89c812-937f-4fc0-839d-c4a3385cad08	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:12:11.346867+02
04c9f311-ec9c-4cc8-8f5e-e6f8fbf079ff	RESET_PASSWORD	AppUser	caf7d118-6add-4b92-bc84-f23b597f44b5	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:12:14.59528+02
6c5a3b91-2bed-483c-82ac-e61ef9bab6ac	LOGIN	AppUser	caf7d118-6add-4b92-bc84-f23b597f44b5	qa_test_newuser@brightminds.test	\N	2026-08-25 11:12:18.01032+02
bcc58b28-f918-41ae-8d88-819009cf97d5	DELETE_USER	AppUser	caf7d118-6add-4b92-bc84-f23b597f44b5	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:12:20.080035+02
03cdbfb8-3382-49c5-8905-61265e1df9a2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:24:13.281388+02
f5974c40-448e-477e-a261-3bc19d3b8214	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:24:23.867013+02
6aad168e-a69c-44fb-9f1e-bf2a0f1c7963	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:34:27.789631+02
e2462c35-5e1a-46ca-98b7-933a2b901f76	CREATE_USER	AppUser	1f1b768d-d983-4f2b-9a6f-dfcaa7487a48	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:34:27.992743+02
e213fbc0-4773-4a22-9b4d-02be73031d1c	LOGIN	AppUser	1f1b768d-d983-4f2b-9a6f-dfcaa7487a48	qa_test_newuser@brightminds.test	\N	2026-08-25 11:34:30.845972+02
e8a15243-fc92-48cb-af15-3b47fd555c5c	LOGIN	AppUser	1f1b768d-d983-4f2b-9a6f-dfcaa7487a48	qa_test_newuser@brightminds.test	\N	2026-08-25 11:34:41.462378+02
2c4f76e9-1155-44ab-b974-9077fe7a35e5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:34:45.820367+02
addcc6fc-9465-43ca-b3b7-90a0bb835781	RESET_PASSWORD	AppUser	1f1b768d-d983-4f2b-9a6f-dfcaa7487a48	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:34:49.143763+02
a2b71f96-13d4-4ad2-920d-acf0802b47a7	LOGIN	AppUser	1f1b768d-d983-4f2b-9a6f-dfcaa7487a48	qa_test_newuser@brightminds.test	\N	2026-08-25 11:34:52.700079+02
83a66d62-e5c7-4cf2-8c14-aa2a4fc24632	DELETE_USER	AppUser	1f1b768d-d983-4f2b-9a6f-dfcaa7487a48	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:34:54.751731+02
3d1b4fd1-e363-482a-9033-2de9ed7da0a9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:40:23.613386+02
324335f5-0ccf-4cb3-8ed6-d874921fdd4c	CREATE_USER	AppUser	56b9e7a7-e026-4b3e-aa67-ab070885ec40	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:40:23.780244+02
1c70352a-1e12-4921-a480-3c71f3eef13a	LOGIN	AppUser	56b9e7a7-e026-4b3e-aa67-ab070885ec40	qa_test_newuser@brightminds.test	\N	2026-08-25 11:40:26.386852+02
c57158e8-40eb-488c-a711-85b4b503cdd8	LOGIN	AppUser	56b9e7a7-e026-4b3e-aa67-ab070885ec40	qa_test_newuser@brightminds.test	\N	2026-08-25 11:40:36.943281+02
b5dff7a3-3da5-42a4-bc0f-fa5b1d646727	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:40:41.171829+02
dd3af7ef-b52c-4607-afa4-a158b337e249	RESET_PASSWORD	AppUser	56b9e7a7-e026-4b3e-aa67-ab070885ec40	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:40:44.27134+02
61a67695-232a-4254-8620-8b238199cac4	LOGIN	AppUser	56b9e7a7-e026-4b3e-aa67-ab070885ec40	qa_test_newuser@brightminds.test	\N	2026-08-25 11:40:47.653696+02
a233f958-b923-4533-aa73-431767fe0ad9	DELETE_USER	AppUser	56b9e7a7-e026-4b3e-aa67-ab070885ec40	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:40:49.679402+02
9aacb827-3631-45e7-bfa3-6ddc2193d946	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:47:27.721896+02
4aa7d49f-cd11-4da4-8c7e-3209c535a966	CREATE_USER	AppUser	a954f263-3857-4303-a620-39138f71f7c9	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:47:27.896282+02
c330e604-b437-4ce3-b1fb-bbe88a18fc57	LOGIN	AppUser	a954f263-3857-4303-a620-39138f71f7c9	qa_test_newuser@brightminds.test	\N	2026-08-25 11:47:30.583396+02
435c3f34-6f3d-4314-b64a-e0729f7747f3	LOGIN	AppUser	a954f263-3857-4303-a620-39138f71f7c9	qa_test_newuser@brightminds.test	\N	2026-08-25 11:47:41.133423+02
00163078-93fa-4066-ab3e-91c2b0804aec	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:47:45.653623+02
cb693f1e-8904-4339-80e4-7d6e29a0df93	RESET_PASSWORD	AppUser	a954f263-3857-4303-a620-39138f71f7c9	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:47:48.868295+02
a4dee241-d6b2-4ac1-b2b9-faf9ce3b852d	LOGIN	AppUser	a954f263-3857-4303-a620-39138f71f7c9	qa_test_newuser@brightminds.test	\N	2026-08-25 11:47:52.337714+02
456329ab-a8e8-4272-8591-d2bbae1ed215	DELETE_USER	AppUser	a954f263-3857-4303-a620-39138f71f7c9	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 11:47:54.376957+02
5af91f2d-4ea1-465d-b9a9-7932430268e3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:48:16.002351+02
215b157d-053f-4bd1-b602-71987d4c42c5	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:56:55.082167+02
a22193af-3159-4a1e-9788-baa15578fb0e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 11:58:06.914657+02
507cf2e6-1b84-421a-b518-3a7bbc767394	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:02:45.951043+02
d43fff58-5dd8-45ce-b56e-f6e510ce4474	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:11:14.933127+02
bc3369f9-1c1a-439a-b71b-e976d6804f79	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:12:52.586273+02
0f6c7227-ebd0-4648-bb9e-7ea46ac40906	CREATE_USER	AppUser	4144656e-135d-40bc-b6df-34a64ec3e8c8	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 12:12:52.774031+02
21ebd9da-44ad-4e37-9258-6df2ba5e3ae0	LOGIN	AppUser	4144656e-135d-40bc-b6df-34a64ec3e8c8	qa_test_newuser@brightminds.test	\N	2026-08-25 12:12:55.614209+02
54116d13-833e-492f-8609-f5864bab1aa3	LOGIN	AppUser	4144656e-135d-40bc-b6df-34a64ec3e8c8	qa_test_newuser@brightminds.test	\N	2026-08-25 12:13:06.25823+02
32ec3687-591e-46ab-a689-93aaca6cfdfb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:13:10.55973+02
3187cd07-1457-4a34-ae9b-c81e3ba86bdf	RESET_PASSWORD	AppUser	4144656e-135d-40bc-b6df-34a64ec3e8c8	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 12:13:14.006321+02
b748648b-8f24-4d7b-80d3-83f96b8b1a83	LOGIN	AppUser	4144656e-135d-40bc-b6df-34a64ec3e8c8	qa_test_newuser@brightminds.test	\N	2026-08-25 12:13:17.277251+02
952d7b8d-fe60-4034-b2b4-0d7aa333bfa2	DELETE_USER	AppUser	4144656e-135d-40bc-b6df-34a64ec3e8c8	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 12:13:19.340658+02
8cc04c6f-ead9-47f6-83a7-f3230208b3d8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:13:48.051264+02
89c9024b-adc0-4b39-b3d8-3e59db2af6b7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:18:14.749947+02
5d568516-cd3d-40c3-bd49-13f65dbd447b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:18:27.962108+02
176be351-791a-4c7c-a264-e6640e019f13	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:19:04.829745+02
b58444b6-709f-4818-98e7-c6d6b794abf2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:20:27.447189+02
b926d5e6-e4bf-48bb-bc79-08e7f4e1378c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:21:07.93721+02
dc4a0b63-3b74-4484-8fe7-a09a12e85b07	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:21:15.875303+02
ef1a788c-7b4f-4b71-a180-77ce05a60127	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:21:31.378792+02
d66a46b9-213e-4554-945e-bd4389910cc0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:21:51.9474+02
735f986c-8125-4067-ad7b-3f4600dbe1c8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:22:07.738348+02
f6c9131a-5420-410c-8085-e85fac00d225	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:23:26.903312+02
53e6e1ff-25e6-41d3-aba7-0a84919802cc	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:24:28.47909+02
2b4e7fda-557e-4b7f-97d1-3ba16b94ee7d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:24:32.83238+02
a7366bb2-1bc3-40cc-a782-ecba9093c0b2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:25:31.79826+02
935707e6-a389-4018-a3ac-61879d6d7c6f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:26:26.485567+02
c0c52097-4050-49c7-99d9-0fddc90d3056	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:26:30.867895+02
c65d4977-7b79-4ccd-b4e9-deeb16d99ef0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:27:15.508377+02
d242cffb-ae95-4409-b5f3-f95befa4cb73	LOGIN	AppUser	12056fbe-592c-4276-875f-61c8a5bfa930	qa_test_newuser@brightminds.test	\N	2026-08-25 12:27:51.016842+02
ddb3ba05-9f1f-4940-95da-7ddb625cb30c	DELETE_USER	AppUser	12056fbe-592c-4276-875f-61c8a5bfa930	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 12:27:53.076108+02
dbdf848a-1567-434c-b640-295a6abea7c8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:25:32.673175+02
4b5158aa-142e-4067-8d98-d12ad35b1db3	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:25:37.126365+02
789e531a-8b8d-42a5-9bd8-e52c0b8d8499	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:26:25.586497+02
a235e723-9f3a-4ef0-9c40-46b3df42c7dd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:27:26.487974+02
b911ba51-ba67-467d-a256-ae61b79efda1	CREATE_USER	AppUser	12056fbe-592c-4276-875f-61c8a5bfa930	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 12:27:26.663588+02
8305b547-6b3e-4ef3-82a6-a80a3034b759	LOGIN	AppUser	12056fbe-592c-4276-875f-61c8a5bfa930	qa_test_newuser@brightminds.test	\N	2026-08-25 12:27:39.985265+02
2cfc5884-67bf-4938-811c-8e0654f7957d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 12:27:44.60997+02
885c86b3-9223-48d9-9c30-50952e497d90	RESET_PASSWORD	AppUser	12056fbe-592c-4276-875f-61c8a5bfa930	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 12:27:47.743561+02
f594acb0-c9f0-4856-bc77-84965c8ab0ae	LOGIN	AppUser	12056fbe-592c-4276-875f-61c8a5bfa930	qa_test_newuser@brightminds.test	\N	2026-08-25 12:27:29.332617+02
f20c4940-afeb-4a9b-b761-b423b761df81	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 13:16:28.416609+02
2d19b184-56d5-4934-abeb-9dc6c86e57bb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 13:23:38.327519+02
a87d10f1-c9af-4d20-8739-3f77f85be1b0	CREATE_USER	AppUser	e759723b-9390-4c03-90cb-23a36a5f1a45	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 13:23:38.503136+02
c1c9d169-9869-49f5-9f90-6dc804a49209	LOGIN	AppUser	e759723b-9390-4c03-90cb-23a36a5f1a45	qa_test_newuser@brightminds.test	\N	2026-08-25 13:23:41.27499+02
b6afa879-9e6c-4a0a-aee3-3b22d5c4ee3b	LOGIN	AppUser	e759723b-9390-4c03-90cb-23a36a5f1a45	qa_test_newuser@brightminds.test	\N	2026-08-25 13:23:52.013774+02
c62c06ae-c1e9-44e9-8ca4-7c9e4ac30e01	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-25 13:23:56.360905+02
a3f85111-93e4-4cfc-9d43-2bd0f1bd5a95	RESET_PASSWORD	AppUser	e759723b-9390-4c03-90cb-23a36a5f1a45	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 13:23:59.758045+02
8baa62d7-6915-43eb-ac14-22c0a8bd0c59	LOGIN	AppUser	e759723b-9390-4c03-90cb-23a36a5f1a45	qa_test_newuser@brightminds.test	\N	2026-08-25 13:24:03.069157+02
751b56ef-b401-4956-8b54-dd97e1531dcf	DELETE_USER	AppUser	e759723b-9390-4c03-90cb-23a36a5f1a45	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-25 13:24:05.144689+02
23b600dc-dfbf-4894-9a06-c4ef391d1f3f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:54:31.001152+02
9ec4556a-6042-4a2c-9a89-9c1c8a5b9c97	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:54:43.39088+02
bbbfc827-ec2d-488d-aa20-18eff47c3c5b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:54:55.346345+02
35484568-943a-4029-9752-3a8d9fdea328	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:55:07.400809+02
d34d0303-e4f3-4b19-9d58-74dbdeffb2d5	DELETE_INVOICE	Invoice	91292c47-5377-451d-afa0-8fd411bf7ef1	invoiceNo UNI-260826-5EF5, total 300.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 07:55:07.548345+02
c2cd9089-7c24-4bad-81d9-f73b9a70d40f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:55:54.495352+02
391bc6f9-23a3-45d9-a0fc-c827b42a6e16	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:56:23.274932+02
ffbdda87-3d1d-463e-97ef-69318f0d487e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:56:49.702161+02
b63c07d4-9ebb-466e-958c-f34441612166	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:57:07.438096+02
18fb8e64-90d7-4b00-ac2a-b512568bb029	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:57:51.810199+02
75f6b130-bb61-4ce5-a9e9-8afc7ffaf3af	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 07:58:04.955104+02
4acdfc1d-ac06-4c10-aa1a-9294b4d7739a	PROVISION_STAFF_LOGIN	Staff	432a576b-67fb-48c9-8c00-393da147b301	qa_teacher@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 07:58:05.270064+02
7173bd4c-8d71-44e1-9fba-1f91f19c428f	LOGIN	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	qa_teacher@brightminds.test	\N	2026-08-26 07:58:26.78708+02
383371eb-6945-4a20-a8c3-5415c048fe30	LOGIN	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	qa_teacher@brightminds.test	\N	2026-08-26 07:59:21.577477+02
6d8f6d5b-e8e4-4087-b0e5-24885ac32edd	LOGIN	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	qa_teacher@brightminds.test	\N	2026-08-26 08:00:16.768179+02
a28e2dad-47b6-4651-a7b7-91c7aced8d7c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:01:01.936622+02
f5bc9c49-1a4b-462e-b408-96e3d3f84479	RESET_PASSWORD	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:01:02.227239+02
a856283b-0ee7-4aaa-9eed-76118e6dea6c	LOGIN	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	qa_teacher@brightminds.test	\N	2026-08-26 08:01:15.353525+02
4051ee9b-6fb4-43ae-8b5c-2573f1fd07ba	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:02:34.100272+02
8907e2a4-19ed-4947-b64a-144952ad0763	RESET_PASSWORD	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:02:34.355785+02
dd8a49a4-f61f-4ecc-a203-f831de154b65	LOGIN	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	qa_teacher@brightminds.test	\N	2026-08-26 08:02:37.746126+02
55980fa0-089f-4765-ad9f-239b67de5876	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:03:06.143932+02
40d9b854-6b1f-4c41-b2bb-2784f639efe8	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:03:18.088615+02
c034b962-6478-4a2d-a5d1-aec110ccccd0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:03:30.887115+02
15d0a5d5-dfd6-4f8a-92f4-7731fc003e05	DELETE_USER	AppUser	c15ad481-4808-40db-af61-b1a5f8b88303	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:03:31.433242+02
d2f522f3-9819-4299-9aaf-aba0f442599a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:03:43.195564+02
61ee19dc-5c63-4db0-9365-366adf7b288c	CREATE_USER	AppUser	ac819b48-1b87-4eb7-a719-0faf799375ed	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:03:43.363704+02
7b37eb81-c6c3-4e59-8688-84d215c69a99	LOGIN	AppUser	ac819b48-1b87-4eb7-a719-0faf799375ed	qa_test_newuser@brightminds.test	\N	2026-08-26 08:03:45.846463+02
3b06ac28-4871-4104-a281-242da989faef	LOGIN	AppUser	ac819b48-1b87-4eb7-a719-0faf799375ed	qa_test_newuser@brightminds.test	\N	2026-08-26 08:03:56.487207+02
75f3bb58-81cd-4af4-ba2b-6574a836c507	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:04:00.622385+02
a7ccc9df-84c7-4477-95bf-06c4d0f3a549	RESET_PASSWORD	AppUser	ac819b48-1b87-4eb7-a719-0faf799375ed	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:04:03.860341+02
52454de5-6e21-4de3-b332-46014d52bd84	LOGIN	AppUser	ac819b48-1b87-4eb7-a719-0faf799375ed	qa_test_newuser@brightminds.test	\N	2026-08-26 08:04:06.843962+02
09908bca-bca2-4642-ba10-b0033967d8bb	DELETE_USER	AppUser	ac819b48-1b87-4eb7-a719-0faf799375ed	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:04:08.886542+02
4a6be409-8318-474f-a1fd-50de35a41a8b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:08:09.469061+02
ab60eec3-4086-4215-ac87-cd76dfea0733	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:08:34.634191+02
0d902933-51be-4f0d-b197-129aa4bd3c37	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:11:43.906902+02
408132a6-476d-43df-bcb3-50d957a4e1b0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:12:32.935615+02
0e542dae-50f1-4d6a-b424-adcfc763d146	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:12:49.080659+02
f25487f0-b62a-42d3-be16-b2934d293dd6	DELETE_INVOICE	Invoice	0688f859-afd7-4ce2-a66a-04eadd224c12	invoiceNo INV-260826-ECB1, total 250.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:12:49.249299+02
96478ae1-6d6c-47ec-86e8-2daca29f01f7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:13:04.120628+02
ab4c7b01-1fdd-474f-a1b7-9841e641afbd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:13:15.850018+02
19858258-6b81-405f-9171-adb1f219a638	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:13:46.802071+02
96d64f4f-80a2-419f-83e7-ccadb2444b9d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:14:23.073188+02
103c2c88-d674-480d-8f2e-d9901b888918	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:15:13.288967+02
4f618ce2-038b-4545-a2fc-8f3d1933dce8	CREATE_USER	AppUser	f6a44569-6e16-4684-9d4e-4bfedebb3488	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:15:13.444054+02
6c20350b-b84d-4122-8159-165093b451e0	LOGIN	AppUser	f6a44569-6e16-4684-9d4e-4bfedebb3488	qa_test_newuser@brightminds.test	\N	2026-08-26 08:15:16.364406+02
199c777b-0ac7-4554-9f2b-074f154c1818	LOGIN	AppUser	f6a44569-6e16-4684-9d4e-4bfedebb3488	qa_test_newuser@brightminds.test	\N	2026-08-26 08:15:26.960781+02
625d7a50-d42a-469d-81bc-8bd1e35516df	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:15:31.381309+02
94e07003-db57-41af-820f-b42fd516cba2	RESET_PASSWORD	AppUser	f6a44569-6e16-4684-9d4e-4bfedebb3488	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:15:34.522897+02
c19d462e-949e-4271-8237-6e0021ae4973	LOGIN	AppUser	f6a44569-6e16-4684-9d4e-4bfedebb3488	qa_test_newuser@brightminds.test	\N	2026-08-26 08:15:37.744635+02
8bdd39b5-7153-4d40-b863-2d428f390545	DELETE_USER	AppUser	f6a44569-6e16-4684-9d4e-4bfedebb3488	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 08:15:39.774986+02
a3d05ee1-1291-4dc2-90c8-1547b7eb38f9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 08:15:52.447947+02
18f945e9-7819-45d5-a651-7d6160605ffd	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:01:41.720501+02
b512e490-b711-4f57-9bb3-f7c43aafbf26	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:05:42.889545+02
9ab341ff-9d0b-478a-8387-59b552a87688	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:06:00.172957+02
da920751-65c2-4eef-a4dc-07d3620dbb3b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:06:19.709272+02
c4d03d24-ba20-4797-be0a-172b729d1b9f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:06:47.898996+02
f3743d04-8d54-4c45-a6a4-a3f22b5fb0a0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:07:17.19725+02
77c1109a-04ba-49c2-b38c-12fad8f17dcc	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:08:00.073823+02
34fab4af-8829-4d74-b602-5930a9bca350	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:11:50.780556+02
1b677fc7-6fe1-4fee-9de1-122bc7897546	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:13:59.999926+02
302a08e5-03f6-460b-a44f-2ff1427e6678	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:14:33.94754+02
ba75f994-de9f-4b43-926b-6a027d45db6a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:14:53.741811+02
ba8d9f2f-81ee-4130-88ca-648658b5a88f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:15:24.719194+02
7c502dfe-fcaf-4876-ac98-5eeff9c1c4fa	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:15:44.392906+02
506b0cf1-f978-45e6-aa75-908fff7f3280	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:16:46.737763+02
a0bc7b50-ca75-4ede-835d-163785b1ae98	DELETE_PAYMENT	Payment	081b3323-1626-47c3-8db3-94d7ff79f915	amount 100.00, receipt RCT-260826-4E0F, pupil test pupil	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:16:46.880685+02
6c6ad414-1763-419a-84d6-8171248515ff	DELETE_INVOICE	Invoice	614cc64d-20fe-406d-b225-99b0ece9d506	invoiceNo INV-260826-9F93, total 100.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:16:47.050146+02
fb053fcf-efa0-4e38-9dc5-58342db8951c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:17:07.773952+02
cbb446f1-e364-4872-91bb-6fef3eb6d53f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:17:54.11966+02
dc2f480c-3a92-4611-8c0e-1bc71e116e47	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:18:09.630342+02
7ed85145-579f-45c7-a6ed-909648026792	CREATE_USER	AppUser	32e745d9-b34f-477f-9cf7-4106b2422456	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:18:09.92273+02
ba891916-4f33-4d14-91ea-c283cabf3989	LOGIN	AppUser	32e745d9-b34f-477f-9cf7-4106b2422456	qa_test_newuser@brightminds.test	\N	2026-08-26 13:18:13.029666+02
c6a8207c-111d-4258-8df6-e2519713959b	LOGIN	AppUser	32e745d9-b34f-477f-9cf7-4106b2422456	qa_test_newuser@brightminds.test	\N	2026-08-26 13:18:23.957031+02
209e6797-f853-43b8-98c7-9d59d9e9fe72	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:18:28.717925+02
d311060d-f062-4a3c-a9e5-982b1f995673	RESET_PASSWORD	AppUser	32e745d9-b34f-477f-9cf7-4106b2422456	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:18:32.138044+02
9c3e4d5d-49d6-4f92-bc40-e1d219709ce8	LOGIN	AppUser	32e745d9-b34f-477f-9cf7-4106b2422456	qa_test_newuser@brightminds.test	\N	2026-08-26 13:18:35.75353+02
96d5e177-74c9-488a-a554-8205c0eacbe4	DELETE_USER	AppUser	32e745d9-b34f-477f-9cf7-4106b2422456	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:18:37.854842+02
86d0c60c-7f87-46ff-b8fe-3f2b421e73a0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:33:16.390789+02
9a2664b1-0e5c-47f7-8493-d5eee5bd01d0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:33:47.677532+02
5d880d8e-0146-4207-af1c-19e1c2c26542	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:34:36.182978+02
75896cb0-119d-4682-bffd-19656938d343	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:34:50.824014+02
9ccb9fad-1d74-4ae1-8183-af63c9d63e50	CREATE_USER	AppUser	fdc41699-dde8-4a6f-8f01-f0738077aa46	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:34:51.036944+02
264923ef-3a81-421f-99be-361420a14f06	LOGIN	AppUser	fdc41699-dde8-4a6f-8f01-f0738077aa46	qa_test_newuser@brightminds.test	\N	2026-08-26 13:34:54.285736+02
27b84e6d-34c9-4abe-ac00-a86556fd1b98	LOGIN	AppUser	fdc41699-dde8-4a6f-8f01-f0738077aa46	qa_test_newuser@brightminds.test	\N	2026-08-26 13:35:05.123901+02
a4d9b3f7-3881-4c27-9fab-a441b7aff10a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 13:35:09.51674+02
e37ee929-504f-47ac-a69b-dd26a44d3386	RESET_PASSWORD	AppUser	fdc41699-dde8-4a6f-8f01-f0738077aa46	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:35:12.744616+02
54c71bff-595c-4cad-bf62-0f0a70ce128e	LOGIN	AppUser	fdc41699-dde8-4a6f-8f01-f0738077aa46	qa_test_newuser@brightminds.test	\N	2026-08-26 13:35:16.206406+02
157c1edb-d4a3-4cb4-afab-62acf7db631e	DELETE_USER	AppUser	fdc41699-dde8-4a6f-8f01-f0738077aa46	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 13:35:18.254776+02
1ceea887-2996-4bd9-bfde-c0aee0073a62	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 20:36:14.590986+02
d02e271c-812e-4288-939b-b1cf3511fb90	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 20:39:10.937709+02
9cdf75e8-1b74-43fb-928d-2ed51f408a91	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 20:40:13.102464+02
b178b578-23ae-4405-af21-c1e259cd472f	CREATE_USER	AppUser	5c9fb5ee-a21c-40b9-884f-d3309cd13703	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 20:40:13.415953+02
56d1164b-58ab-43ad-af4b-9bdd5072f75d	LOGIN	AppUser	5c9fb5ee-a21c-40b9-884f-d3309cd13703	qa_test_newuser@brightminds.test	\N	2026-08-26 20:40:18.503547+02
7a3609dd-f278-47f8-916e-f6d8ebd05169	LOGIN	AppUser	5c9fb5ee-a21c-40b9-884f-d3309cd13703	qa_test_newuser@brightminds.test	\N	2026-08-26 20:40:29.76953+02
ecd8298b-b74d-41c4-a7b2-afaa6c0a2ddb	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-26 20:40:34.64154+02
2ec27605-0216-48b5-b754-20756948bbbf	RESET_PASSWORD	AppUser	5c9fb5ee-a21c-40b9-884f-d3309cd13703	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 20:40:38.144077+02
d2ab5708-9500-4291-b704-890c63ab8c5a	LOGIN	AppUser	5c9fb5ee-a21c-40b9-884f-d3309cd13703	qa_test_newuser@brightminds.test	\N	2026-08-26 20:40:42.178022+02
48260153-a082-4456-9f59-1df13f604df6	DELETE_USER	AppUser	5c9fb5ee-a21c-40b9-884f-d3309cd13703	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-26 20:40:44.434922+02
4a9aed6f-0277-4e77-a087-3f9a3cc972fa	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 05:22:04.578844+02
0950e38c-b187-4186-8cd2-29bd3585cf7f	RESTORE_BACKUP	System	\N	4 file(s) restored; database restored from uploaded archive	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:22:25.974938+02
5cffb4a0-4011-4480-b85b-74c4a4775e31	LOGIN	AppUser	d9b7a507-d0e5-4490-afb8-82f27f8fd717	qa_test_newuser@brightminds.test	\N	2026-08-28 07:45:38.162406+02
211b080f-9895-441e-b653-180984029ee2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:55:58.606564+02
1a0bf18a-fd1f-45ea-b431-e887504faec5	RESET_PASSWORD	AppUser	e0cd5e88-edef-43f2-a310-03e367494862	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:56:33.668449+02
03dc0080-b49c-4e39-8232-1be6250e681c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 11:31:17.243233+02
073e169c-ba8d-4be7-9686-df84d00ae4c2	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:23:39.997145+02
83412911-b138-49fe-8273-415d4d0abd67	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:24:10.932731+02
d0a3bd0a-e6c4-47a4-ad5f-bb13190144fe	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:25:24.524154+02
b3b6b548-1158-4208-b1e9-6387f3afec69	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:25:37.572959+02
4729d770-3a88-4e55-86bd-01d6992aeaf0	CREATE_USER	AppUser	db27bbc1-6e22-44c9-b291-428bc2f87ddc	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:25:37.791918+02
45f0bf41-d314-4593-86b7-e1d9279c24de	LOGIN	AppUser	db27bbc1-6e22-44c9-b291-428bc2f87ddc	qa_test_newuser@brightminds.test	\N	2026-08-28 07:25:40.564519+02
c46d2f3d-83e3-4133-8c50-cb75b00a2b52	LOGIN	AppUser	db27bbc1-6e22-44c9-b291-428bc2f87ddc	qa_test_newuser@brightminds.test	\N	2026-08-28 07:25:51.368898+02
68eefc2f-7fff-4c4b-8fb3-98705ae8e2c0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:25:55.472177+02
2605d12d-e414-4f00-9b7a-2c28f7d7b579	LOGIN	AppUser	db27bbc1-6e22-44c9-b291-428bc2f87ddc	qa_test_newuser@brightminds.test	\N	2026-08-28 07:26:01.930956+02
2c3f0e85-4823-42a7-9fc8-bdd18712926d	DELETE_USER	AppUser	db27bbc1-6e22-44c9-b291-428bc2f87ddc	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:26:03.975067+02
b9a5df7c-1e3f-4f17-8fde-3143b4a99851	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:43:28.23698+02
82177ebc-20c4-4420-b53f-1d541571f7c4	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:45:18.675748+02
c0bb542e-bd41-4886-a91c-2d3d6bd3f205	LOGIN	AppUser	d9b7a507-d0e5-4490-afb8-82f27f8fd717	qa_test_newuser@brightminds.test	\N	2026-08-28 07:45:48.986625+02
ed962ecf-20f5-49aa-a6bf-fbdba6ce6c8f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:45:53.12622+02
0a044027-bfb7-4d53-b5b4-ebb5fc76b774	LOGIN	AppUser	d9b7a507-d0e5-4490-afb8-82f27f8fd717	qa_test_newuser@brightminds.test	\N	2026-08-28 07:45:59.318246+02
fd23327c-7954-4c5e-a836-5be1677b49ce	DELETE_USER	AppUser	baa561f7-3880-45f6-b618-43e94d12a426	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:55:59.039413+02
8a90b424-480b-458b-bc7c-ddecd8b9a2bc	LOGIN	AppUser	e0cd5e88-edef-43f2-a310-03e367494862	qa_test_newuser@brightminds.test	\N	2026-08-28 07:56:26.212607+02
dc465e27-6d1a-4f62-8e3b-9ccc9a7dfb94	RESET_PASSWORD	AppUser	db27bbc1-6e22-44c9-b291-428bc2f87ddc	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:25:58.841431+02
75167e6a-4f87-4c70-bfa3-31e93df86fe0	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:43:57.358335+02
fa49c371-545e-4806-93c9-a868b1a91cdc	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:44:31.803022+02
56c39d4e-94b0-4312-b0a7-26cd1b9765ef	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:45:04.439529+02
5485ce47-962a-4e62-959a-c79fe79676b6	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:45:35.332942+02
19ec96b7-b56e-4ddf-9189-43d9dc498c96	CREATE_USER	AppUser	d9b7a507-d0e5-4490-afb8-82f27f8fd717	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:45:35.517265+02
310864b1-858b-4369-9b1d-de9467133004	RESET_PASSWORD	AppUser	d9b7a507-d0e5-4490-afb8-82f27f8fd717	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:45:56.304854+02
eba5ede4-6168-4a74-bc51-e91071dc5014	DELETE_USER	AppUser	d9b7a507-d0e5-4490-afb8-82f27f8fd717	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:46:01.33906+02
4d4e8c4d-656c-4b23-8c93-5eaa15f2614b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:54:01.687418+02
69b4470d-3b7c-4f13-a2b3-cee6213d4847	PROVISION_STAFF_LOGIN	Staff	97c81d27-9306-4b1b-b5bb-75e5ecd9260f	qa_remark_teacher@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:54:03.847556+02
23f1051b-6881-4864-a67a-c2af772b63a2	LOGIN	AppUser	baa561f7-3880-45f6-b618-43e94d12a426	qa_remark_teacher@brightminds.test	\N	2026-08-28 07:54:20.95673+02
19fa03ae-f0ed-4e11-b190-a0efadb514e9	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:54:38.792208+02
ac7be5bf-455c-4e59-8270-5de4aa191cf1	LOGIN	AppUser	baa561f7-3880-45f6-b618-43e94d12a426	qa_remark_teacher@brightminds.test	\N	2026-08-28 07:54:39.44174+02
8f025763-bf10-4f0c-9fd4-b05ad89f73aa	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:54:54.513428+02
5d241847-6a7e-4c65-8138-f5f4c26d2cbe	RESET_PASSWORD	AppUser	baa561f7-3880-45f6-b618-43e94d12a426	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:54:54.755078+02
20f19463-6933-47b5-a0f8-b122e54a3784	LOGIN	AppUser	baa561f7-3880-45f6-b618-43e94d12a426	qa_remark_teacher@brightminds.test	\N	2026-08-28 07:55:21.691344+02
ac094a18-6ff7-4a12-84fa-bf07c27c3789	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:56:13.153805+02
cb6c41cf-6cf0-4e89-a0e7-5ee1d0ee15d9	CREATE_USER	AppUser	e0cd5e88-edef-43f2-a310-03e367494862	qa_test_newuser@brightminds.test	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:56:13.321514+02
64af2422-4943-4e00-859d-9f86ecbde7e6	LOGIN	AppUser	e0cd5e88-edef-43f2-a310-03e367494862	qa_test_newuser@brightminds.test	\N	2026-08-28 07:56:15.64578+02
acff440c-0078-4a2a-8d88-b39c81bfeb3c	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 07:56:30.511127+02
cfe818fe-a62f-4bcc-9897-5065102a4ae0	LOGIN	AppUser	e0cd5e88-edef-43f2-a310-03e367494862	qa_test_newuser@brightminds.test	\N	2026-08-28 07:56:36.734091+02
9139a264-584b-4510-84ba-86fb575eb883	DELETE_USER	AppUser	e0cd5e88-edef-43f2-a310-03e367494862	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 07:56:38.752347+02
3d8d890d-544c-4430-beb5-457231b092d9	RESTORE_BACKUP	System	\N	4 file(s) restored; safety snapshot saved as pre-restore-2026-08-28T113210.zip	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-28 11:32:12.100315+02
c8b3fd24-1546-4458-b1cd-1c0daf790eda	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 08:02:58.656629+02
783362cb-5de7-4cea-8c33-61cebd774f77	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 08:05:02.528919+02
2274d2ed-ba96-4b9e-a60c-bdf2df3ff40e	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 08:05:25.009701+02
ffbf4eb8-b34d-44b9-a099-d807ab66268e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 08:21:18.190836+02
3ba1e9df-d4e6-4e3a-ad41-106d4426e762	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 08:22:17.395693+02
e50007f9-392a-4f8a-826a-b0066dbb912f	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 08:26:11.519426+02
023bbbf2-1b6d-40b4-ad08-0763e7350d14	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-05 14:53:50.487999+02
ca080b46-a058-451e-b70c-b33232a4b047	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-07 03:14:52.902998+02
c87c3fed-cd72-4b8f-86ad-01deaa73535a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-07 03:20:20.338525+02
30893b68-9f97-4509-9c29-a14482eac460	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-28 11:51:37.572664+02
0e461b31-b7ad-463f-8c50-e5704d27b994	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 07:15:14.613407+02
7596216a-816e-4543-8b87-1424a6bbea97	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 07:15:14.997333+02
bddd9bf6-599f-469d-a885-8ae5e83ffdf1	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 07:15:35.080214+02
0bedd890-27a7-451c-a29a-da6e56f7a03b	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 07:15:56.945936+02
e6e31756-227b-4a2a-81b9-2b52bdcbd858	RESET_PASSWORD	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	\N	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-08-29 07:15:57.23121+02
e82b1345-0f76-4255-946a-2a3f78fc549c	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 07:16:08.124517+02
18a73ffd-2f1f-4922-967a-88a6c5e5a9d8	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 07:16:19.607814+02
e8a6bbfb-af87-4280-b3d1-c8fef5247b3f	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 07:17:16.891396+02
bb74ecc2-3649-4b1e-9553-a33f302c308a	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 08:22:25.627905+02
b5e7c4b6-d833-4f8d-9e01-6cc7cbb2e004	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 08:23:56.654588+02
1f9c500e-ce5f-460b-bb82-e5c4147d8441	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-05 14:10:45.223279+02
3bcd5d06-b0ff-498e-abd1-32e2bb9963b7	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-05 14:17:23.858109+02
11dcaf06-1924-4e67-a67d-256a9a37428e	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-05 14:55:47.58655+02
0b0fe314-6e79-4eba-9a21-041fd7dc9992	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-07 03:20:37.711986+02
3844b83b-ac20-45ac-9051-584fd167a553	DELETE_INVOICE	Invoice	3cf3dd2e-d887-4bbd-b796-0b2708a1e8bc	invoiceNo INV-260907-47DA, total 50.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-09-07 03:21:15.502495+02
aa3f0396-a633-4042-b932-33a1feaf32dc	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-08-29 07:19:29.828465+02
f405b3b9-2f04-4584-bde9-a52f9e3427a7	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 07:20:14.22136+02
21d62252-b87d-4efd-b6bf-0298e38336c0	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 08:26:27.000864+02
564bf496-c7f9-416b-a77a-10987910ace5	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-08-29 08:27:31.279958+02
d887fd46-6585-4f11-83a6-0f9ff4dece27	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-05 14:47:58.617627+02
7390e40a-0463-474d-b640-4a028c36194a	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-05 14:48:39.284754+02
1bff0eb6-aac7-479b-a7a5-08f0442f2093	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-05 14:49:29.582453+02
74350ecb-d0df-43cf-9f4a-b578719ac8af	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-05 14:50:38.568303+02
cf54c707-79f7-408b-affc-18727296e005	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-05 14:59:07.680916+02
56e74ee4-e8bf-477c-a28c-f8293a20d18e	DELETE_INVOICE	Invoice	84376cf5-6515-4f02-a395-e5fd7c98c3ed	invoiceNo INV-260905-BE87, total 5.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-09-05 15:00:54.353813+02
bbc232e5-b92d-48f8-ad9e-3c419ce2bfd4	DELETE_INVOICE	Invoice	1980ee11-accc-4b78-aea9-d44b5087cfe7	invoiceNo INV-260905-CC0F, total 1.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-09-05 15:00:54.512866+02
30fa1baa-6317-43a0-9ad1-6cfcdc194b3d	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-05 15:01:46.047414+02
60af2879-f453-4cf6-bb8c-44c74ed5fd1a	LOGIN	AppUser	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	testparent@test.com	\N	2026-09-05 15:02:12.819755+02
492f1772-d365-4d4e-8c72-fad53afca1f0	DELETE_INVOICE	Invoice	59598d61-5e2e-4862-bf11-3ce2848c2457	invoiceNo INV-260905-9864, total 1.00	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	2026-09-05 15:21:34.979764+02
483410dd-b51a-4265-8d29-12916205f84a	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-08 16:54:56.274175+02
c43c7414-4aa9-4bfb-8b55-435319a9052e	LOGIN	AppUser	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	admin@school.demo	\N	2026-09-08 16:56:20.077801+02
\.


--
-- Data for Name: canteen_meal_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.canteen_meal_plans (id, name, description, meals_per_day, price_per_term, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: canteen_menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.canteen_menu_items (id, name, category, description, price, image_url, is_available, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: canteen_sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.canteen_sales (id, item_id, item_name, pupil_id, staff_id, quantity, unit_price, total, payment_method, served_on, notes, created_at) FROM stdin;
\.


--
-- Data for Name: canteen_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.canteen_subscriptions (id, pupil_id, plan_id, term_id, start_date, end_date, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, name, stream, level_order, capacity, class_teacher_id, created_at) FROM stdin;
b436c50e-1846-4110-a584-64d288106bdc	Grade 1	B	0	30	\N	2026-07-10 17:24:35.966727+02
\.


--
-- Data for Name: discipline_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discipline_records (id, pupil_id, kind, description, action_taken, occurred_on, points, reported_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, title, url, category, description, pupil_id, staff_id, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, title, description, starts_at, ends_at, location, audience, class_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exams (id, name, term_id, exam_date, out_of, weight, created_at, assessment_type) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, category, amount, payee, description, payment_method, ref_no, spent_on, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fee_items (id, name, amount, class_id, term_id, is_recurring, created_at, category, due_date) FROM stdin;
59b1d79e-55f0-4ae2-9360-a48b40f6a59c	Transport - Kabwata route	150.00	\N	\N	f	2026-08-16 11:04:13.276303+02	TRANSPORT	\N
91e9060f-ed3f-4fa7-9ba2-6076aff11070	Administrative Late Fee	35.00	\N	\N	f	2026-08-19 01:51:44.134569+02	LATE_FEE	\N
528d23c6-1ccd-46e3-89e4-d5cb5b34a099	QA_TEST Route A	50.00	\N	\N	t	2026-08-23 21:26:56.540641+02	TRANSPORT	\N
abe81665-6575-469d-adde-d031f6c76e80	Uniform	0.00	\N	\N	f	2026-08-26 07:53:49.478167+02	UNIFORM	\N
0dccf7d8-f9a4-4af1-9640-8745fc4cd87a	P.E. Attire	0.00	\N	\N	f	2026-08-26 07:53:49.478167+02	UNIFORM	\N
c0da90ac-595f-4dbd-991d-5ec1351b7a0b	Socks	0.00	\N	\N	f	2026-08-26 07:53:49.478167+02	UNIFORM	\N
e6fb3d06-17fd-4f19-bf21-af0589106d6f	Other	0.00	\N	\N	f	2026-08-26 07:53:49.478167+02	UNIFORM	\N
0c0a256e-29ed-4598-87e7-adad3ca8ff52	Jersey	0.00	\N	\N	f	2026-08-26 07:53:49.478167+02	UNIFORM	\N
a71ea6a2-e07b-4dfb-ad53-378575888534	QA Test Route	250.00	\N	\N	t	2026-08-26 08:12:33.925955+02	TRANSPORT	\N
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	init	SQL	V1__init.sql	1644536229	postgres	2026-07-01 09:05:39.524705	322	t
2	2	enhancements	SQL	V2__enhancements.sql	-1846244746	postgres	2026-07-01 09:05:39.9088	60	t
3	3	school branding	SQL	V3__school_branding.sql	1082287521	postgres	2026-07-01 09:05:39.984358	6	t
4	4	exam assessment type	SQL	V4__exam_assessment_type.sql	-1144072508	postgres	2026-07-01 09:05:39.997155	2	t
5	5	ptc meetings	SQL	V5__ptc_meetings.sql	-282815786	postgres	2026-07-01 09:11:43.519623	152	t
6	6	user roles varchar	SQL	V6__user_roles_varchar.sql	439714464	postgres	2026-07-01 09:20:07.107025	56	t
7	7	jsonb to text	SQL	V7__jsonb_to_text.sql	-868600970	postgres	2026-07-01 09:23:31.227622	48	t
8	8	parent portal and promotion history	SQL	V8__parent_portal_and_promotion_history.sql	1633062233	postgres	2026-07-10 12:42:43.862093	245	t
9	9	staff role category and contract end	SQL	V9__staff_role_category_and_contract_end.sql	-758301387	postgres	2026-08-13 18:45:55.676983	44	t
10	10	payment status and pending claims	SQL	V10__payment_status_and_pending_claims.sql	-1829579710	postgres	2026-08-13 19:51:09.678796	137	t
11	11	invoice fee item link	SQL	V11__invoice_fee_item_link.sql	985748421	postgres	2026-08-13 20:59:11.078463	21	t
12	12	report card remarks	SQL	V12__report_card_remarks.sql	-1460043830	postgres	2026-08-14 09:06:55.081771	194	t
13	13	signatures	SQL	V13__signatures.sql	2073508492	postgres	2026-08-14 09:06:55.310885	5	t
14	14	invoice late fee	SQL	V14__invoice_late_fee.sql	-698657146	postgres	2026-08-16 11:01:47.738142	111	t
15	15	permission enforcement	SQL	V15__permission_enforcement.sql	-182653475	postgres	2026-08-16 12:16:43.877641	43	t
16	16	fees reverse permission	SQL	V16__fees_reverse_permission.sql	-430882748	postgres	2026-08-19 01:12:22.847393	50	t
17	17	fee item due date	SQL	V17__fee_item_due_date.sql	1923002389	postgres	2026-08-19 01:12:22.938109	28	t
18	18	school banner	SQL	V18__school_banner.sql	1658944754	postgres	2026-08-19 01:12:22.977775	4	t
19	19	transport pickup points	SQL	V19__transport_pickup_points.sql	-224599026	postgres	2026-08-19 01:39:23.399332	173	t
20	20	accounts reverse permission	SQL	V20__accounts_reverse_permission.sql	-1088151913	postgres	2026-08-19 02:02:10.557023	30	t
21	21	admission registration fee	SQL	V21__admission_registration_fee.sql	236551339	postgres	2026-08-19 02:23:03.179141	45	t
22	22	purchase order items	SQL	V22__purchase_order_items.sql	584214225	postgres	2026-08-19 07:32:10.784756	234	t
23	23	documents subjects view	SQL	V23__documents_subjects_view.sql	1966690970	postgres	2026-08-21 05:48:56.597472	22	t
24	24	dashboard content	SQL	V24__dashboard_content.sql	1066796257	postgres	2026-08-23 20:59:44.351477	69	t
25	25	message recipient label	SQL	V25__message_recipient_label.sql	564406748	postgres	2026-08-23 22:04:10.932356	27	t
26	26	login page button	SQL	V26__login_page_button.sql	-1365482118	postgres	2026-08-24 03:41:06.383639	23	t
27	27	accountant pupils view	SQL	V27__accountant_pupils_view.sql	1809654877	postgres	2026-08-24 04:26:36.224962	36	t
28	28	landing page	SQL	V28__landing_page.sql	130013357	postgres	2026-08-25 09:25:11.397058	105	t
29	29	inquiries	SQL	V29__inquiries.sql	-1997536411	postgres	2026-08-25 09:25:11.547788	168	t
30	30	password reset	SQL	V30__password_reset.sql	-932785401	postgres	2026-08-25 10:59:17.061536	124	t
31	31	facebook url	SQL	V31__facebook_url.sql	1891405817	postgres	2026-08-25 12:10:40.199948	12	t
32	32	uniform module	SQL	V32__uniform_module.sql	726657523	postgres	2026-08-26 07:53:49.451702	51	t
33	33	backup restore permission	SQL	V33__backup_restore_permission.sql	-1322467702	postgres	2026-08-28 05:21:16.729745	41	t
34	34	report card remarks term scoped	SQL	V34__report_card_remarks_term_scoped.sql	-1389254878	postgres	2026-08-29 08:00:22.093644	163	t
35	35	gateway transactions	SQL	V35__gateway_transactions.sql	-1650936253	postgres	2026-09-05 14:46:55.994682	120	t
\.


--
-- Data for Name: gateway_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gateway_transactions (id, provider, reference, lenco_id, lenco_reference, invoice_id, guardian_id, phone, operator, amount, status, payment_id, failure_reason, raw_response, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: guardian_pupils; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guardian_pupils (id, guardian_id, pupil_id, is_primary) FROM stdin;
16fd610f-724a-4838-8208-62f64f63a059	2f1633d1-3fa8-4d90-9ede-c252560781ff	7451c3b1-3401-491a-874d-908b224fd662	t
\.


--
-- Data for Name: guardians; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guardians (id, full_name, relationship, phone, email, address, occupation, national_id, user_id, created_at, updated_at) FROM stdin;
2f1633d1-3fa8-4d90-9ede-c252560781ff	Test Parent	Father	0976911338	testparent@test.com	\N	\N	\N	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	2026-07-10 17:26:03.938336+02	2026-07-10 17:26:03.944347+02
\.


--
-- Data for Name: health_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_records (id, pupil_id, visit_date, complaint, diagnosis, treatment, medication, notes, attended_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: homework; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.homework (id, title, description, class_id, subject_id, due_date, attachment_url, assigned_by, created_at) FROM stdin;
\.


--
-- Data for Name: inquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inquiries (id, full_name, email, phone, message, read, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_items (id, name, sku, category, unit, location, quantity, reorder_level, unit_cost, supplier_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_txns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_txns (id, item_id, direction, quantity, reason, reference, occurred_on, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, invoice_no, pupil_id, term_id, total, paid, status, due_date, description, created_at, updated_at, fee_item_id, late_fee_applied) FROM stdin;
c6522f31-7e85-4783-807d-8be074d16f1c	INV-260814-612E	7451c3b1-3401-491a-874d-908b224fd662	\N	100.00	50.00	PARTIAL	\N	payment	2026-08-14 08:17:56.976376+02	2026-08-14 08:18:27.091734+02	\N	f
f1defef6-2374-4063-908c-1897e7ab3be7	INV-260823-FBE6	7451c3b1-3401-491a-874d-908b224fd662	\N	50.00	0.00	UNPAID	\N	Transport — QA_TEST Route A	2026-08-23 21:26:56.547157+02	2026-08-23 21:26:56.547157+02	528d23c6-1ccd-46e3-89e4-d5cb5b34a099	f
0693a1ca-6086-45c7-91af-1e72c523f108	INV-260823-B081	7451c3b1-3401-491a-874d-908b224fd662	\N	123.45	0.00	UNPAID	2026-10-01	QA_TEST_ Invoice Description	2026-08-23 21:51:46.944348+02	2026-08-23 21:59:43.389812+02	\N	f
\.


--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_requests (id, staff_id, leave_type, start_date, end_date, reason, status, approver_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: library_books; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_books (id, title, author, isbn, category, shelf, copies_total, copies_available, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: library_loans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_loans (id, book_id, pupil_id, staff_id, borrowed_on, due_on, returned_on, status, fine, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: marks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marks (id, pupil_id, exam_id, subject_id, score, comment, entered_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, body, subject, channel, audience, class_id, recipient_count, sent_by, sent_at, created_at, recipient_label) FROM stdin;
530dec24-c574-4554-a572-9c4c555a628b	QA_TEST_ automated smoke test message (in_app channel, safe, no external dispatch)	QA_TEST_ Message Subject	IN_APP	STAFF	\N	\N	\N	2026-08-23 21:26:52.384974+02	2026-08-23 21:26:52.386483+02	\N
eebb77a1-83f8-4746-89d0-122bfe4217e9	QA test	\N	IN_APP	INDIVIDUAL	\N	\N	\N	2026-08-23 22:04:48.964349+02	2026-08-23 22:04:48.966348+02	Jane Banda - 097xxxxxxx
02f69607-2a08-46b9-8128-29504e71921c	QA_TEST individual message body		EMAIL	INDIVIDUAL	\N	\N	\N	2026-08-23 22:07:47.832818+02	2026-08-23 22:07:47.833816+02	QA_TEST Jane Banda - 0970000000
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, receipt_no, pupil_id, invoice_id, amount, method, paid_on, reference, notes, recorded_by, created_at, status, submitted_by_guardian_id, rejection_reason) FROM stdin;
82d4c389-a702-4c6f-80ec-69c47e17632c	RCT-260814-07C0	7451c3b1-3401-491a-874d-908b224fd662	c6522f31-7e85-4783-807d-8be074d16f1c	50.00	MOBILE_MONEY	2026-08-14	234567890	\N	\N	2026-08-14 08:18:27.108726+02	CONFIRMED	\N	\N
\.


--
-- Data for Name: payroll_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_periods (id, period_label, period_start, period_end, status, notes, created_at, updated_at) FROM stdin;
8ff9c69c-4f6d-41f4-816f-5ab089504320	Repro Period	2026-08-01	2026-08-31	PAID	\N	2026-08-19 08:06:38.303859+02	2026-08-19 08:06:38.892309+02
2ee9db26-8d5f-4901-9b8f-bba66650b7bd	QA_TEST_ Payroll Period	2026-08-01	2026-08-31	DRAFT	\N	2026-08-23 22:11:17.075527+02	2026-08-23 22:11:17.075527+02
\.


--
-- Data for Name: payslips; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payslips (id, staff_id, period_id, basic, allowances, deductions, tax, net_pay, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, description, module, created_at) FROM stdin;
ecf48163-f667-450c-84ad-c651bbdebfb1	pupils:view	View pupil records	PUPILS	2026-07-01 09:05:39.919695+02
6b4b9114-75a8-4fd8-9df2-5ddaef4ceeb3	pupils:create	Enrol new pupils	PUPILS	2026-07-01 09:05:39.919695+02
dd87411d-de6a-46af-9aaf-8917330c547d	pupils:edit	Edit pupil records	PUPILS	2026-07-01 09:05:39.919695+02
004a3bae-d4ba-4f08-b761-c8bec3bed798	pupils:delete	Delete pupil records	PUPILS	2026-07-01 09:05:39.919695+02
8970a5c0-2eb6-439c-8915-c1497babf705	staff:view	View staff records	STAFF	2026-07-01 09:05:39.919695+02
64f7d190-3823-4959-8370-117ab6fe2cfe	staff:manage	Add / edit / delete staff	STAFF	2026-07-01 09:05:39.919695+02
71581d32-ef45-49ef-96d7-6f5fec36799b	fees:view	View fee items and invoices	FEES	2026-07-01 09:05:39.919695+02
923bb9f6-264e-4388-9559-9fc7b72d6cbf	fees:create	Create invoices	FEES	2026-07-01 09:05:39.919695+02
3fccc5ab-7f0c-4a9e-83a1-0c562d8e39dc	fees:collect	Record payments	FEES	2026-07-01 09:05:39.919695+02
0ba430f6-8148-4375-bc4d-7f548e699c50	fees:configure	Configure fee items	FEES	2026-07-01 09:05:39.919695+02
17bcbe4f-c505-4e1a-8148-12fc2b9c84bd	attendance:view	View attendance records	ATTENDANCE	2026-07-01 09:05:39.919695+02
dff6daef-f58c-45ef-91af-053071679167	attendance:mark	Mark attendance	ATTENDANCE	2026-07-01 09:05:39.919695+02
71349d02-1836-4b06-8696-f7df96d44203	exams:view	View exams and marks	EXAMS	2026-07-01 09:05:39.919695+02
12f0c9a8-93b7-4b29-9f34-a6cd7ca9dba1	exams:manage	Create exams and enter marks	EXAMS	2026-07-01 09:05:39.919695+02
c4c6aef7-826d-402b-b969-794e6a85c5f2	library:view	View library	LIBRARY	2026-07-01 09:05:39.919695+02
0ba621f1-850b-4fcd-86ee-026dabb212cc	library:manage	Manage books and loans	LIBRARY	2026-07-01 09:05:39.919695+02
2eb7782e-f2cf-4ee4-9a6d-f6156d15fb9f	transport:view	View transport	TRANSPORT	2026-07-01 09:05:39.919695+02
18c5b528-7a09-489c-9348-b66bccab4996	transport:manage	Manage vehicles and routes	TRANSPORT	2026-07-01 09:05:39.919695+02
883d95cd-1f63-41e9-885a-b33bfdc25a49	canteen:view	View canteen	CANTEEN	2026-07-01 09:05:39.919695+02
3982c34d-dd01-44bc-81ac-7a306be274fe	canteen:manage	Manage canteen	CANTEEN	2026-07-01 09:05:39.919695+02
cd80384a-9f8a-4a31-ba28-f80ec03be233	announcements:view	View announcements	COMMS	2026-07-01 09:05:39.919695+02
d56d97a2-4670-46f2-9bee-d0f03af6abf4	announcements:post	Post announcements	COMMS	2026-07-01 09:05:39.919695+02
0c38caf2-af64-445f-ae3c-a31e0801c343	payroll:view	View payroll	PAYROLL	2026-07-01 09:05:39.919695+02
bb45c066-6728-4b5d-8855-e719f32fc390	payroll:manage	Manage payroll	PAYROLL	2026-07-01 09:05:39.919695+02
d64afef8-9d09-497b-a1ce-3b4b9e657371	reports:view	View reports	REPORTS	2026-07-01 09:05:39.919695+02
ae7a68ef-0071-473d-aa6a-fe125a06312e	backup:create	Create system backup	ADMIN	2026-07-01 09:05:39.919695+02
73d05809-0f26-4bd1-b8cc-29fae9713ae4	settings:edit	Edit school settings	ADMIN	2026-07-01 09:05:39.919695+02
e8ded114-690e-45b3-891a-b8d10b22a5ac	users:manage	Manage user accounts	ADMIN	2026-07-01 09:05:39.919695+02
096059f6-bc0e-401e-8d2f-ee808022fcf1	roles:manage	Manage roles and permissions	ADMIN	2026-07-01 09:05:39.919695+02
b64df75b-ca58-4ba4-b78e-8729eb2636f2	audit:view	View audit logs	ADMIN	2026-07-01 09:05:39.919695+02
9bc7f40d-2b20-4a35-98bd-aea4eb2977ce	academic_years:manage	Manage academic years and terms	ACADEMIC	2026-08-16 12:16:43.903654+02
d00e4b6c-76fa-467a-97e6-4e351031d391	classes:view	View classes	CLASSES	2026-08-16 12:16:43.903654+02
c0b3d131-3c9f-4dc9-9859-360dc275e897	classes:manage	Create / edit / delete classes	CLASSES	2026-08-16 12:16:43.903654+02
7a32a74e-1b55-418d-9472-ee3e36695e60	subjects:manage	Manage subjects	ACADEMIC	2026-08-16 12:16:43.903654+02
290244be-df46-492c-819d-617dece8daf7	admissions:manage	Manage admissions	ADMISSIONS	2026-08-16 12:16:43.903654+02
bb6f890f-de5b-41bd-b0fb-f935781d0a96	discipline:view	View discipline records	DISCIPLINE	2026-08-16 12:16:43.903654+02
b7517a4f-2858-4f44-85ff-c6d79ba041f9	discipline:manage	Record discipline incidents	DISCIPLINE	2026-08-16 12:16:43.903654+02
e2c5ba70-af1d-4708-a3e2-8c69c148a2a9	homework:manage	Post / edit / delete homework	HOMEWORK	2026-08-16 12:16:43.903654+02
ace1c92f-761f-45a4-b471-8afd38635531	timetable:manage	Edit timetable slots	TIMETABLE	2026-08-16 12:16:43.903654+02
cf42bd3c-c9fb-4ad4-889f-9335eb168adf	report_cards:view	Enter report card remarks	EXAMS	2026-08-16 12:16:43.903654+02
ec654d02-af3f-42aa-ba76-18d66dda40d6	promotions:manage	Promote / demote pupils between grades	PROMOTIONS	2026-08-16 12:16:43.903654+02
b411ea7b-3bef-4040-8641-af4555d689f1	guardians:manage	Add / edit / delete parent records	GUARDIANS	2026-08-16 12:16:43.903654+02
1393744f-48bc-42f5-a15b-3876261f60d5	health:manage	Manage clinic / health records	HEALTH	2026-08-16 12:16:43.903654+02
a1c24b6b-e221-4ceb-8456-fe67b9ab9668	leave:manage	Approve / manage staff leave	LEAVE	2026-08-16 12:16:43.903654+02
cfe4cba8-1d52-4972-abe6-ce0358182a4c	procurement:manage	Manage purchase orders and suppliers	PROCUREMENT	2026-08-16 12:16:43.903654+02
26877611-930a-4ad0-bcd9-12bcc984a2e3	inventory:manage	Manage inventory / stock	INVENTORY	2026-08-16 12:16:43.903654+02
ef2947bd-4588-407c-857d-7bba3a51a17c	ptc:manage	Manage parent-teacher conference sessions	PTC	2026-08-16 12:16:43.903654+02
1f108aa1-0615-43e6-ba17-7dc3c94da27e	events:manage	Create / edit / delete calendar events	EVENTS	2026-08-16 12:16:43.903654+02
ed4587ea-05aa-4f37-8a00-190473641c4c	documents:manage	Upload / delete official documents	DOCUMENTS	2026-08-16 12:16:43.903654+02
496dc810-79e5-44f6-881b-e63c23102a40	communication:manage	Send broadcast SMS / email	COMMS	2026-08-16 12:16:43.903654+02
9a57b940-f314-47b3-afc0-c347850a0437	accounts:manage	Record / edit school expenses	ACCOUNTS	2026-08-16 12:16:43.903654+02
439b880b-5013-457c-bb5c-a09fd84f3fc2	fees:reverse	Edit, delete or reverse a recorded payment	FEES	2026-08-19 01:12:22.874103+02
4c2f0a45-0340-40c2-9d24-a2057b6716e4	payroll:reverse	Edit or delete a recorded payslip	PAYROLL	2026-08-19 01:12:22.874103+02
dd0a8694-9225-4178-ad1f-cb4851ed23e4	accounts:reverse	Edit or delete a recorded expense	ACCOUNTS	2026-08-19 02:02:10.576539+02
eb7d5ec5-03a0-4c35-96a4-3bfae74ba27b	admissions:view	View admission applications (read-only)	ADMISSIONS	2026-08-19 02:23:03.201711+02
62cf9617-a9e2-46b9-b3e0-bb8917154ddf	documents:view	View documents	DOCUMENTS	2026-08-21 05:48:56.617356+02
eb561bbd-835f-4b20-8576-ca74e59b254c	subjects:view	View subjects	SUBJECTS	2026-08-21 05:48:56.617356+02
18801b16-9b7f-474a-ac35-1e4e27027701	inquiries:view	View inquiries submitted from the public website	INQUIRIES	2026-08-25 09:25:11.558751+02
88095d45-34e2-41ed-877e-7ff4ea745cd0	inquiries:manage	Manage (clear/respond to) inquiries submitted from the public website	INQUIRIES	2026-08-25 09:25:11.558751+02
98a24c66-8db0-448d-bfdc-3a10fd9b38c1	uniform:view	View uniform catalog and sales	UNIFORM	2026-08-26 07:53:49.478167+02
dc62571b-d86c-4a0f-b9e4-d847a6737893	uniform:manage	Manage uniform catalog and record sales	UNIFORM	2026-08-26 07:53:49.478167+02
da797075-7438-4038-922a-195f98d95805	backup:restore	Restore the system from a backup archive (destructive)	SYSTEM	2026-08-28 05:21:16.751263+02
\.


--
-- Data for Name: ptc_meetings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ptc_meetings (id, session_id, staff_id, guardian_id, pupil_id, meeting_date, start_time, end_time, venue, status, agenda, teacher_notes, admin_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ptc_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ptc_sessions (id, title, session_date, venue, description, start_time, end_time, term_id, created_at) FROM stdin;
\.


--
-- Data for Name: pupil_enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pupil_enrollments (id, pupil_id, class_id, academic_year_id, started_on, ended_on, created_at) FROM stdin;
b333063c-6a79-43df-8b12-c62628bee5b6	7451c3b1-3401-491a-874d-908b224fd662	b436c50e-1846-4110-a584-64d288106bdc	\N	2026-07-10	\N	2026-07-10 17:26:03.784083+02
\.


--
-- Data for Name: pupil_promotions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pupil_promotions (id, pupil_id, from_class_id, to_class_id, academic_year_id, promoted_on, promoted_by, notes, created_at) FROM stdin;
\.


--
-- Data for Name: pupils; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pupils (id, admission_no, full_name, gender, dob, address, town, province, postal_code, nationality, tribe, religion, home_language, blood_group, allergies, medical_info, special_needs, nrc_no, birth_cert_no, previous_school, referral_source, siblings_in_school, house, boarding_status, transport_mode, emergency_contact, photo_url, notes, admitted_on, status, class_id, created_at, updated_at) FROM stdin;
7451c3b1-3401-491a-874d-908b224fd662	121	test pupil	Female	2021-08-13	jhgfdsasdfghj	\N	\N	\N	\N	\N	\N	\N	A+	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-10	ACTIVE	b436c50e-1846-4110-a584-64d288106bdc	2026-07-10 17:26:03.769082+02	2026-07-10 17:26:03.769082+02
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_items (id, purchase_order_id, item_id, quantity, unit_cost, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, po_no, supplier_id, order_date, status, total, notes, created_by, created_at, updated_at, received_at) FROM stdin;
\.


--
-- Data for Name: report_card_remarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_card_remarks (id, pupil_id, class_teacher_remark, head_teacher_remark, created_at, updated_at, term_id) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
3da7509f-7ccf-48bd-9ccc-f9976386acb2	ecf48163-f667-450c-84ad-c651bbdebfb1
3da7509f-7ccf-48bd-9ccc-f9976386acb2	6b4b9114-75a8-4fd8-9df2-5ddaef4ceeb3
3da7509f-7ccf-48bd-9ccc-f9976386acb2	dd87411d-de6a-46af-9aaf-8917330c547d
3da7509f-7ccf-48bd-9ccc-f9976386acb2	004a3bae-d4ba-4f08-b761-c8bec3bed798
3da7509f-7ccf-48bd-9ccc-f9976386acb2	8970a5c0-2eb6-439c-8915-c1497babf705
3da7509f-7ccf-48bd-9ccc-f9976386acb2	64f7d190-3823-4959-8370-117ab6fe2cfe
3da7509f-7ccf-48bd-9ccc-f9976386acb2	71581d32-ef45-49ef-96d7-6f5fec36799b
3da7509f-7ccf-48bd-9ccc-f9976386acb2	923bb9f6-264e-4388-9559-9fc7b72d6cbf
3da7509f-7ccf-48bd-9ccc-f9976386acb2	3fccc5ab-7f0c-4a9e-83a1-0c562d8e39dc
3da7509f-7ccf-48bd-9ccc-f9976386acb2	0ba430f6-8148-4375-bc4d-7f548e699c50
3da7509f-7ccf-48bd-9ccc-f9976386acb2	17bcbe4f-c505-4e1a-8148-12fc2b9c84bd
3da7509f-7ccf-48bd-9ccc-f9976386acb2	dff6daef-f58c-45ef-91af-053071679167
3da7509f-7ccf-48bd-9ccc-f9976386acb2	71349d02-1836-4b06-8696-f7df96d44203
3da7509f-7ccf-48bd-9ccc-f9976386acb2	12f0c9a8-93b7-4b29-9f34-a6cd7ca9dba1
3da7509f-7ccf-48bd-9ccc-f9976386acb2	c4c6aef7-826d-402b-b969-794e6a85c5f2
3da7509f-7ccf-48bd-9ccc-f9976386acb2	0ba621f1-850b-4fcd-86ee-026dabb212cc
3da7509f-7ccf-48bd-9ccc-f9976386acb2	2eb7782e-f2cf-4ee4-9a6d-f6156d15fb9f
3da7509f-7ccf-48bd-9ccc-f9976386acb2	18c5b528-7a09-489c-9348-b66bccab4996
3da7509f-7ccf-48bd-9ccc-f9976386acb2	883d95cd-1f63-41e9-885a-b33bfdc25a49
3da7509f-7ccf-48bd-9ccc-f9976386acb2	3982c34d-dd01-44bc-81ac-7a306be274fe
3da7509f-7ccf-48bd-9ccc-f9976386acb2	cd80384a-9f8a-4a31-ba28-f80ec03be233
3da7509f-7ccf-48bd-9ccc-f9976386acb2	d56d97a2-4670-46f2-9bee-d0f03af6abf4
3da7509f-7ccf-48bd-9ccc-f9976386acb2	0c38caf2-af64-445f-ae3c-a31e0801c343
3da7509f-7ccf-48bd-9ccc-f9976386acb2	bb45c066-6728-4b5d-8855-e719f32fc390
3da7509f-7ccf-48bd-9ccc-f9976386acb2	d64afef8-9d09-497b-a1ce-3b4b9e657371
3da7509f-7ccf-48bd-9ccc-f9976386acb2	ae7a68ef-0071-473d-aa6a-fe125a06312e
3da7509f-7ccf-48bd-9ccc-f9976386acb2	73d05809-0f26-4bd1-b8cc-29fae9713ae4
3da7509f-7ccf-48bd-9ccc-f9976386acb2	e8ded114-690e-45b3-891a-b8d10b22a5ac
3da7509f-7ccf-48bd-9ccc-f9976386acb2	096059f6-bc0e-401e-8d2f-ee808022fcf1
3da7509f-7ccf-48bd-9ccc-f9976386acb2	b64df75b-ca58-4ba4-b78e-8729eb2636f2
7faea9b7-175e-4180-9855-aedf47d9cb9d	ecf48163-f667-450c-84ad-c651bbdebfb1
9277c65f-4541-4aae-ad87-f36f73536398	ecf48163-f667-450c-84ad-c651bbdebfb1
b277b9af-a8a8-4044-b5b4-79c335f38198	ecf48163-f667-450c-84ad-c651bbdebfb1
7faea9b7-175e-4180-9855-aedf47d9cb9d	6b4b9114-75a8-4fd8-9df2-5ddaef4ceeb3
9277c65f-4541-4aae-ad87-f36f73536398	6b4b9114-75a8-4fd8-9df2-5ddaef4ceeb3
b277b9af-a8a8-4044-b5b4-79c335f38198	6b4b9114-75a8-4fd8-9df2-5ddaef4ceeb3
3da7509f-7ccf-48bd-9ccc-f9976386acb2	eb7d5ec5-03a0-4c35-96a4-3bfae74ba27b
7faea9b7-175e-4180-9855-aedf47d9cb9d	dd87411d-de6a-46af-9aaf-8917330c547d
9277c65f-4541-4aae-ad87-f36f73536398	dd87411d-de6a-46af-9aaf-8917330c547d
b277b9af-a8a8-4044-b5b4-79c335f38198	dd87411d-de6a-46af-9aaf-8917330c547d
e6e4a242-5893-49a7-ab32-db180d2ddbb5	eb7d5ec5-03a0-4c35-96a4-3bfae74ba27b
7faea9b7-175e-4180-9855-aedf47d9cb9d	004a3bae-d4ba-4f08-b761-c8bec3bed798
9277c65f-4541-4aae-ad87-f36f73536398	004a3bae-d4ba-4f08-b761-c8bec3bed798
b277b9af-a8a8-4044-b5b4-79c335f38198	004a3bae-d4ba-4f08-b761-c8bec3bed798
7faea9b7-175e-4180-9855-aedf47d9cb9d	eb7d5ec5-03a0-4c35-96a4-3bfae74ba27b
7faea9b7-175e-4180-9855-aedf47d9cb9d	8970a5c0-2eb6-439c-8915-c1497babf705
9277c65f-4541-4aae-ad87-f36f73536398	8970a5c0-2eb6-439c-8915-c1497babf705
b277b9af-a8a8-4044-b5b4-79c335f38198	8970a5c0-2eb6-439c-8915-c1497babf705
9277c65f-4541-4aae-ad87-f36f73536398	eb7d5ec5-03a0-4c35-96a4-3bfae74ba27b
7faea9b7-175e-4180-9855-aedf47d9cb9d	17bcbe4f-c505-4e1a-8148-12fc2b9c84bd
9277c65f-4541-4aae-ad87-f36f73536398	17bcbe4f-c505-4e1a-8148-12fc2b9c84bd
b277b9af-a8a8-4044-b5b4-79c335f38198	17bcbe4f-c505-4e1a-8148-12fc2b9c84bd
03238a37-3b71-4a29-b074-8c113f3a3522	eb7d5ec5-03a0-4c35-96a4-3bfae74ba27b
7faea9b7-175e-4180-9855-aedf47d9cb9d	dff6daef-f58c-45ef-91af-053071679167
9277c65f-4541-4aae-ad87-f36f73536398	dff6daef-f58c-45ef-91af-053071679167
b277b9af-a8a8-4044-b5b4-79c335f38198	dff6daef-f58c-45ef-91af-053071679167
7faea9b7-175e-4180-9855-aedf47d9cb9d	71349d02-1836-4b06-8696-f7df96d44203
9277c65f-4541-4aae-ad87-f36f73536398	71349d02-1836-4b06-8696-f7df96d44203
b277b9af-a8a8-4044-b5b4-79c335f38198	71349d02-1836-4b06-8696-f7df96d44203
7faea9b7-175e-4180-9855-aedf47d9cb9d	12f0c9a8-93b7-4b29-9f34-a6cd7ca9dba1
9277c65f-4541-4aae-ad87-f36f73536398	12f0c9a8-93b7-4b29-9f34-a6cd7ca9dba1
b277b9af-a8a8-4044-b5b4-79c335f38198	12f0c9a8-93b7-4b29-9f34-a6cd7ca9dba1
3da7509f-7ccf-48bd-9ccc-f9976386acb2	d00e4b6c-76fa-467a-97e6-4e351031d391
7faea9b7-175e-4180-9855-aedf47d9cb9d	d00e4b6c-76fa-467a-97e6-4e351031d391
9277c65f-4541-4aae-ad87-f36f73536398	d00e4b6c-76fa-467a-97e6-4e351031d391
b277b9af-a8a8-4044-b5b4-79c335f38198	d00e4b6c-76fa-467a-97e6-4e351031d391
3da7509f-7ccf-48bd-9ccc-f9976386acb2	bb6f890f-de5b-41bd-b0fb-f935781d0a96
03238a37-3b71-4a29-b074-8c113f3a3522	ecf48163-f667-450c-84ad-c651bbdebfb1
7faea9b7-175e-4180-9855-aedf47d9cb9d	bb6f890f-de5b-41bd-b0fb-f935781d0a96
9277c65f-4541-4aae-ad87-f36f73536398	bb6f890f-de5b-41bd-b0fb-f935781d0a96
b277b9af-a8a8-4044-b5b4-79c335f38198	bb6f890f-de5b-41bd-b0fb-f935781d0a96
3da7509f-7ccf-48bd-9ccc-f9976386acb2	b7517a4f-2858-4f44-85ff-c6d79ba041f9
3da7509f-7ccf-48bd-9ccc-f9976386acb2	98a24c66-8db0-448d-bfdc-3a10fd9b38c1
7faea9b7-175e-4180-9855-aedf47d9cb9d	b7517a4f-2858-4f44-85ff-c6d79ba041f9
9277c65f-4541-4aae-ad87-f36f73536398	b7517a4f-2858-4f44-85ff-c6d79ba041f9
b277b9af-a8a8-4044-b5b4-79c335f38198	b7517a4f-2858-4f44-85ff-c6d79ba041f9
3da7509f-7ccf-48bd-9ccc-f9976386acb2	e2c5ba70-af1d-4708-a3e2-8c69c148a2a9
3da7509f-7ccf-48bd-9ccc-f9976386acb2	dc62571b-d86c-4a0f-b9e4-d847a6737893
7faea9b7-175e-4180-9855-aedf47d9cb9d	e2c5ba70-af1d-4708-a3e2-8c69c148a2a9
9277c65f-4541-4aae-ad87-f36f73536398	e2c5ba70-af1d-4708-a3e2-8c69c148a2a9
b277b9af-a8a8-4044-b5b4-79c335f38198	e2c5ba70-af1d-4708-a3e2-8c69c148a2a9
3da7509f-7ccf-48bd-9ccc-f9976386acb2	ace1c92f-761f-45a4-b471-8afd38635531
e6e4a242-5893-49a7-ab32-db180d2ddbb5	98a24c66-8db0-448d-bfdc-3a10fd9b38c1
7faea9b7-175e-4180-9855-aedf47d9cb9d	ace1c92f-761f-45a4-b471-8afd38635531
9277c65f-4541-4aae-ad87-f36f73536398	ace1c92f-761f-45a4-b471-8afd38635531
b277b9af-a8a8-4044-b5b4-79c335f38198	ace1c92f-761f-45a4-b471-8afd38635531
3da7509f-7ccf-48bd-9ccc-f9976386acb2	cf42bd3c-c9fb-4ad4-889f-9335eb168adf
e6e4a242-5893-49a7-ab32-db180d2ddbb5	dc62571b-d86c-4a0f-b9e4-d847a6737893
7faea9b7-175e-4180-9855-aedf47d9cb9d	cf42bd3c-c9fb-4ad4-889f-9335eb168adf
9277c65f-4541-4aae-ad87-f36f73536398	cf42bd3c-c9fb-4ad4-889f-9335eb168adf
b277b9af-a8a8-4044-b5b4-79c335f38198	cf42bd3c-c9fb-4ad4-889f-9335eb168adf
7faea9b7-175e-4180-9855-aedf47d9cb9d	98a24c66-8db0-448d-bfdc-3a10fd9b38c1
7faea9b7-175e-4180-9855-aedf47d9cb9d	64f7d190-3823-4959-8370-117ab6fe2cfe
9277c65f-4541-4aae-ad87-f36f73536398	64f7d190-3823-4959-8370-117ab6fe2cfe
7faea9b7-175e-4180-9855-aedf47d9cb9d	dc62571b-d86c-4a0f-b9e4-d847a6737893
7faea9b7-175e-4180-9855-aedf47d9cb9d	d56d97a2-4670-46f2-9bee-d0f03af6abf4
9277c65f-4541-4aae-ad87-f36f73536398	d56d97a2-4670-46f2-9bee-d0f03af6abf4
9277c65f-4541-4aae-ad87-f36f73536398	98a24c66-8db0-448d-bfdc-3a10fd9b38c1
7faea9b7-175e-4180-9855-aedf47d9cb9d	d64afef8-9d09-497b-a1ce-3b4b9e657371
9277c65f-4541-4aae-ad87-f36f73536398	d64afef8-9d09-497b-a1ce-3b4b9e657371
9277c65f-4541-4aae-ad87-f36f73536398	dc62571b-d86c-4a0f-b9e4-d847a6737893
7faea9b7-175e-4180-9855-aedf47d9cb9d	73d05809-0f26-4bd1-b8cc-29fae9713ae4
9277c65f-4541-4aae-ad87-f36f73536398	73d05809-0f26-4bd1-b8cc-29fae9713ae4
3da7509f-7ccf-48bd-9ccc-f9976386acb2	9bc7f40d-2b20-4a35-98bd-aea4eb2977ce
03238a37-3b71-4a29-b074-8c113f3a3522	98a24c66-8db0-448d-bfdc-3a10fd9b38c1
7faea9b7-175e-4180-9855-aedf47d9cb9d	9bc7f40d-2b20-4a35-98bd-aea4eb2977ce
9277c65f-4541-4aae-ad87-f36f73536398	9bc7f40d-2b20-4a35-98bd-aea4eb2977ce
3da7509f-7ccf-48bd-9ccc-f9976386acb2	c0b3d131-3c9f-4dc9-9859-360dc275e897
03238a37-3b71-4a29-b074-8c113f3a3522	dc62571b-d86c-4a0f-b9e4-d847a6737893
7faea9b7-175e-4180-9855-aedf47d9cb9d	c0b3d131-3c9f-4dc9-9859-360dc275e897
9277c65f-4541-4aae-ad87-f36f73536398	c0b3d131-3c9f-4dc9-9859-360dc275e897
3da7509f-7ccf-48bd-9ccc-f9976386acb2	7a32a74e-1b55-418d-9472-ee3e36695e60
7faea9b7-175e-4180-9855-aedf47d9cb9d	7a32a74e-1b55-418d-9472-ee3e36695e60
9277c65f-4541-4aae-ad87-f36f73536398	7a32a74e-1b55-418d-9472-ee3e36695e60
3da7509f-7ccf-48bd-9ccc-f9976386acb2	290244be-df46-492c-819d-617dece8daf7
3da7509f-7ccf-48bd-9ccc-f9976386acb2	439b880b-5013-457c-bb5c-a09fd84f3fc2
7faea9b7-175e-4180-9855-aedf47d9cb9d	290244be-df46-492c-819d-617dece8daf7
9277c65f-4541-4aae-ad87-f36f73536398	290244be-df46-492c-819d-617dece8daf7
3da7509f-7ccf-48bd-9ccc-f9976386acb2	ec654d02-af3f-42aa-ba76-18d66dda40d6
3da7509f-7ccf-48bd-9ccc-f9976386acb2	4c2f0a45-0340-40c2-9d24-a2057b6716e4
7faea9b7-175e-4180-9855-aedf47d9cb9d	ec654d02-af3f-42aa-ba76-18d66dda40d6
9277c65f-4541-4aae-ad87-f36f73536398	ec654d02-af3f-42aa-ba76-18d66dda40d6
3da7509f-7ccf-48bd-9ccc-f9976386acb2	b411ea7b-3bef-4040-8641-af4555d689f1
e6e4a242-5893-49a7-ab32-db180d2ddbb5	439b880b-5013-457c-bb5c-a09fd84f3fc2
7faea9b7-175e-4180-9855-aedf47d9cb9d	b411ea7b-3bef-4040-8641-af4555d689f1
9277c65f-4541-4aae-ad87-f36f73536398	b411ea7b-3bef-4040-8641-af4555d689f1
3da7509f-7ccf-48bd-9ccc-f9976386acb2	1393744f-48bc-42f5-a15b-3876261f60d5
e6e4a242-5893-49a7-ab32-db180d2ddbb5	4c2f0a45-0340-40c2-9d24-a2057b6716e4
7faea9b7-175e-4180-9855-aedf47d9cb9d	1393744f-48bc-42f5-a15b-3876261f60d5
9277c65f-4541-4aae-ad87-f36f73536398	1393744f-48bc-42f5-a15b-3876261f60d5
3da7509f-7ccf-48bd-9ccc-f9976386acb2	a1c24b6b-e221-4ceb-8456-fe67b9ab9668
9277c65f-4541-4aae-ad87-f36f73536398	439b880b-5013-457c-bb5c-a09fd84f3fc2
7faea9b7-175e-4180-9855-aedf47d9cb9d	a1c24b6b-e221-4ceb-8456-fe67b9ab9668
9277c65f-4541-4aae-ad87-f36f73536398	a1c24b6b-e221-4ceb-8456-fe67b9ab9668
3da7509f-7ccf-48bd-9ccc-f9976386acb2	cfe4cba8-1d52-4972-abe6-ce0358182a4c
9277c65f-4541-4aae-ad87-f36f73536398	4c2f0a45-0340-40c2-9d24-a2057b6716e4
7faea9b7-175e-4180-9855-aedf47d9cb9d	cfe4cba8-1d52-4972-abe6-ce0358182a4c
9277c65f-4541-4aae-ad87-f36f73536398	cfe4cba8-1d52-4972-abe6-ce0358182a4c
3da7509f-7ccf-48bd-9ccc-f9976386acb2	26877611-930a-4ad0-bcd9-12bcc984a2e3
7faea9b7-175e-4180-9855-aedf47d9cb9d	26877611-930a-4ad0-bcd9-12bcc984a2e3
9277c65f-4541-4aae-ad87-f36f73536398	26877611-930a-4ad0-bcd9-12bcc984a2e3
3da7509f-7ccf-48bd-9ccc-f9976386acb2	ef2947bd-4588-407c-857d-7bba3a51a17c
7faea9b7-175e-4180-9855-aedf47d9cb9d	ef2947bd-4588-407c-857d-7bba3a51a17c
9277c65f-4541-4aae-ad87-f36f73536398	ef2947bd-4588-407c-857d-7bba3a51a17c
3da7509f-7ccf-48bd-9ccc-f9976386acb2	1f108aa1-0615-43e6-ba17-7dc3c94da27e
7faea9b7-175e-4180-9855-aedf47d9cb9d	1f108aa1-0615-43e6-ba17-7dc3c94da27e
9277c65f-4541-4aae-ad87-f36f73536398	1f108aa1-0615-43e6-ba17-7dc3c94da27e
3da7509f-7ccf-48bd-9ccc-f9976386acb2	ed4587ea-05aa-4f37-8a00-190473641c4c
7faea9b7-175e-4180-9855-aedf47d9cb9d	ed4587ea-05aa-4f37-8a00-190473641c4c
9277c65f-4541-4aae-ad87-f36f73536398	ed4587ea-05aa-4f37-8a00-190473641c4c
3da7509f-7ccf-48bd-9ccc-f9976386acb2	496dc810-79e5-44f6-881b-e63c23102a40
7faea9b7-175e-4180-9855-aedf47d9cb9d	496dc810-79e5-44f6-881b-e63c23102a40
9277c65f-4541-4aae-ad87-f36f73536398	496dc810-79e5-44f6-881b-e63c23102a40
9277c65f-4541-4aae-ad87-f36f73536398	71581d32-ef45-49ef-96d7-6f5fec36799b
03238a37-3b71-4a29-b074-8c113f3a3522	71581d32-ef45-49ef-96d7-6f5fec36799b
9277c65f-4541-4aae-ad87-f36f73536398	923bb9f6-264e-4388-9559-9fc7b72d6cbf
03238a37-3b71-4a29-b074-8c113f3a3522	923bb9f6-264e-4388-9559-9fc7b72d6cbf
9277c65f-4541-4aae-ad87-f36f73536398	3fccc5ab-7f0c-4a9e-83a1-0c562d8e39dc
03238a37-3b71-4a29-b074-8c113f3a3522	3fccc5ab-7f0c-4a9e-83a1-0c562d8e39dc
9277c65f-4541-4aae-ad87-f36f73536398	0ba430f6-8148-4375-bc4d-7f548e699c50
03238a37-3b71-4a29-b074-8c113f3a3522	0ba430f6-8148-4375-bc4d-7f548e699c50
9277c65f-4541-4aae-ad87-f36f73536398	883d95cd-1f63-41e9-885a-b33bfdc25a49
03238a37-3b71-4a29-b074-8c113f3a3522	883d95cd-1f63-41e9-885a-b33bfdc25a49
9277c65f-4541-4aae-ad87-f36f73536398	3982c34d-dd01-44bc-81ac-7a306be274fe
03238a37-3b71-4a29-b074-8c113f3a3522	3982c34d-dd01-44bc-81ac-7a306be274fe
9277c65f-4541-4aae-ad87-f36f73536398	0c38caf2-af64-445f-ae3c-a31e0801c343
03238a37-3b71-4a29-b074-8c113f3a3522	0c38caf2-af64-445f-ae3c-a31e0801c343
9277c65f-4541-4aae-ad87-f36f73536398	bb45c066-6728-4b5d-8855-e719f32fc390
03238a37-3b71-4a29-b074-8c113f3a3522	bb45c066-6728-4b5d-8855-e719f32fc390
3da7509f-7ccf-48bd-9ccc-f9976386acb2	9a57b940-f314-47b3-afc0-c347850a0437
9277c65f-4541-4aae-ad87-f36f73536398	9a57b940-f314-47b3-afc0-c347850a0437
03238a37-3b71-4a29-b074-8c113f3a3522	9a57b940-f314-47b3-afc0-c347850a0437
9277c65f-4541-4aae-ad87-f36f73536398	ae7a68ef-0071-473d-aa6a-fe125a06312e
9277c65f-4541-4aae-ad87-f36f73536398	096059f6-bc0e-401e-8d2f-ee808022fcf1
9277c65f-4541-4aae-ad87-f36f73536398	e8ded114-690e-45b3-891a-b8d10b22a5ac
9277c65f-4541-4aae-ad87-f36f73536398	b64df75b-ca58-4ba4-b78e-8729eb2636f2
25b10d0c-c798-43d8-a97b-a07511846148	ecf48163-f667-450c-84ad-c651bbdebfb1
25b10d0c-c798-43d8-a97b-a07511846148	6b4b9114-75a8-4fd8-9df2-5ddaef4ceeb3
25b10d0c-c798-43d8-a97b-a07511846148	dd87411d-de6a-46af-9aaf-8917330c547d
25b10d0c-c798-43d8-a97b-a07511846148	004a3bae-d4ba-4f08-b761-c8bec3bed798
7faea9b7-175e-4180-9855-aedf47d9cb9d	c4c6aef7-826d-402b-b969-794e6a85c5f2
7faea9b7-175e-4180-9855-aedf47d9cb9d	0ba621f1-850b-4fcd-86ee-026dabb212cc
7faea9b7-175e-4180-9855-aedf47d9cb9d	2eb7782e-f2cf-4ee4-9a6d-f6156d15fb9f
7faea9b7-175e-4180-9855-aedf47d9cb9d	18c5b528-7a09-489c-9348-b66bccab4996
9277c65f-4541-4aae-ad87-f36f73536398	c4c6aef7-826d-402b-b969-794e6a85c5f2
9277c65f-4541-4aae-ad87-f36f73536398	0ba621f1-850b-4fcd-86ee-026dabb212cc
9277c65f-4541-4aae-ad87-f36f73536398	2eb7782e-f2cf-4ee4-9a6d-f6156d15fb9f
9277c65f-4541-4aae-ad87-f36f73536398	18c5b528-7a09-489c-9348-b66bccab4996
25b10d0c-c798-43d8-a97b-a07511846148	8970a5c0-2eb6-439c-8915-c1497babf705
25b10d0c-c798-43d8-a97b-a07511846148	17bcbe4f-c505-4e1a-8148-12fc2b9c84bd
25b10d0c-c798-43d8-a97b-a07511846148	dff6daef-f58c-45ef-91af-053071679167
25b10d0c-c798-43d8-a97b-a07511846148	71349d02-1836-4b06-8696-f7df96d44203
25b10d0c-c798-43d8-a97b-a07511846148	12f0c9a8-93b7-4b29-9f34-a6cd7ca9dba1
25b10d0c-c798-43d8-a97b-a07511846148	d00e4b6c-76fa-467a-97e6-4e351031d391
25b10d0c-c798-43d8-a97b-a07511846148	bb6f890f-de5b-41bd-b0fb-f935781d0a96
25b10d0c-c798-43d8-a97b-a07511846148	b7517a4f-2858-4f44-85ff-c6d79ba041f9
25b10d0c-c798-43d8-a97b-a07511846148	e2c5ba70-af1d-4708-a3e2-8c69c148a2a9
25b10d0c-c798-43d8-a97b-a07511846148	ace1c92f-761f-45a4-b471-8afd38635531
25b10d0c-c798-43d8-a97b-a07511846148	cf42bd3c-c9fb-4ad4-889f-9335eb168adf
3da7509f-7ccf-48bd-9ccc-f9976386acb2	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
3da7509f-7ccf-48bd-9ccc-f9976386acb2	eb561bbd-835f-4b20-8576-ca74e59b254c
e6e4a242-5893-49a7-ab32-db180d2ddbb5	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
e6e4a242-5893-49a7-ab32-db180d2ddbb5	eb561bbd-835f-4b20-8576-ca74e59b254c
7faea9b7-175e-4180-9855-aedf47d9cb9d	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
7faea9b7-175e-4180-9855-aedf47d9cb9d	eb561bbd-835f-4b20-8576-ca74e59b254c
9277c65f-4541-4aae-ad87-f36f73536398	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
9277c65f-4541-4aae-ad87-f36f73536398	eb561bbd-835f-4b20-8576-ca74e59b254c
03238a37-3b71-4a29-b074-8c113f3a3522	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
03238a37-3b71-4a29-b074-8c113f3a3522	eb561bbd-835f-4b20-8576-ca74e59b254c
25b10d0c-c798-43d8-a97b-a07511846148	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
25b10d0c-c798-43d8-a97b-a07511846148	eb561bbd-835f-4b20-8576-ca74e59b254c
b277b9af-a8a8-4044-b5b4-79c335f38198	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
b277b9af-a8a8-4044-b5b4-79c335f38198	eb561bbd-835f-4b20-8576-ca74e59b254c
0fbd1b44-a21e-4901-89ab-afc180cbff4c	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
0fbd1b44-a21e-4901-89ab-afc180cbff4c	eb561bbd-835f-4b20-8576-ca74e59b254c
82dff047-8100-4c2c-b34b-366156a4ab6b	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
82dff047-8100-4c2c-b34b-366156a4ab6b	eb561bbd-835f-4b20-8576-ca74e59b254c
31057223-f84c-4914-953e-3d8dddb9a0d5	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
31057223-f84c-4914-953e-3d8dddb9a0d5	eb561bbd-835f-4b20-8576-ca74e59b254c
82568de7-a209-4a66-a261-4e4e33d301fc	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
82568de7-a209-4a66-a261-4e4e33d301fc	eb561bbd-835f-4b20-8576-ca74e59b254c
08fa398e-5bb5-429d-a7ef-346ceb4bed97	62cf9617-a9e2-46b9-b3e0-bb8917154ddf
08fa398e-5bb5-429d-a7ef-346ceb4bed97	eb561bbd-835f-4b20-8576-ca74e59b254c
3da7509f-7ccf-48bd-9ccc-f9976386acb2	18801b16-9b7f-474a-ac35-1e4e27027701
3da7509f-7ccf-48bd-9ccc-f9976386acb2	88095d45-34e2-41ed-877e-7ff4ea745cd0
e6e4a242-5893-49a7-ab32-db180d2ddbb5	ecf48163-f667-450c-84ad-c651bbdebfb1
e6e4a242-5893-49a7-ab32-db180d2ddbb5	6b4b9114-75a8-4fd8-9df2-5ddaef4ceeb3
e6e4a242-5893-49a7-ab32-db180d2ddbb5	dd87411d-de6a-46af-9aaf-8917330c547d
e6e4a242-5893-49a7-ab32-db180d2ddbb5	004a3bae-d4ba-4f08-b761-c8bec3bed798
e6e4a242-5893-49a7-ab32-db180d2ddbb5	8970a5c0-2eb6-439c-8915-c1497babf705
e6e4a242-5893-49a7-ab32-db180d2ddbb5	64f7d190-3823-4959-8370-117ab6fe2cfe
e6e4a242-5893-49a7-ab32-db180d2ddbb5	71581d32-ef45-49ef-96d7-6f5fec36799b
e6e4a242-5893-49a7-ab32-db180d2ddbb5	923bb9f6-264e-4388-9559-9fc7b72d6cbf
e6e4a242-5893-49a7-ab32-db180d2ddbb5	3fccc5ab-7f0c-4a9e-83a1-0c562d8e39dc
e6e4a242-5893-49a7-ab32-db180d2ddbb5	0ba430f6-8148-4375-bc4d-7f548e699c50
e6e4a242-5893-49a7-ab32-db180d2ddbb5	17bcbe4f-c505-4e1a-8148-12fc2b9c84bd
e6e4a242-5893-49a7-ab32-db180d2ddbb5	dff6daef-f58c-45ef-91af-053071679167
e6e4a242-5893-49a7-ab32-db180d2ddbb5	71349d02-1836-4b06-8696-f7df96d44203
e6e4a242-5893-49a7-ab32-db180d2ddbb5	12f0c9a8-93b7-4b29-9f34-a6cd7ca9dba1
e6e4a242-5893-49a7-ab32-db180d2ddbb5	c4c6aef7-826d-402b-b969-794e6a85c5f2
e6e4a242-5893-49a7-ab32-db180d2ddbb5	0ba621f1-850b-4fcd-86ee-026dabb212cc
e6e4a242-5893-49a7-ab32-db180d2ddbb5	2eb7782e-f2cf-4ee4-9a6d-f6156d15fb9f
e6e4a242-5893-49a7-ab32-db180d2ddbb5	18c5b528-7a09-489c-9348-b66bccab4996
e6e4a242-5893-49a7-ab32-db180d2ddbb5	883d95cd-1f63-41e9-885a-b33bfdc25a49
e6e4a242-5893-49a7-ab32-db180d2ddbb5	3982c34d-dd01-44bc-81ac-7a306be274fe
e6e4a242-5893-49a7-ab32-db180d2ddbb5	d56d97a2-4670-46f2-9bee-d0f03af6abf4
e6e4a242-5893-49a7-ab32-db180d2ddbb5	0c38caf2-af64-445f-ae3c-a31e0801c343
e6e4a242-5893-49a7-ab32-db180d2ddbb5	bb45c066-6728-4b5d-8855-e719f32fc390
e6e4a242-5893-49a7-ab32-db180d2ddbb5	d64afef8-9d09-497b-a1ce-3b4b9e657371
e6e4a242-5893-49a7-ab32-db180d2ddbb5	73d05809-0f26-4bd1-b8cc-29fae9713ae4
e6e4a242-5893-49a7-ab32-db180d2ddbb5	e8ded114-690e-45b3-891a-b8d10b22a5ac
e6e4a242-5893-49a7-ab32-db180d2ddbb5	b64df75b-ca58-4ba4-b78e-8729eb2636f2
e6e4a242-5893-49a7-ab32-db180d2ddbb5	9bc7f40d-2b20-4a35-98bd-aea4eb2977ce
e6e4a242-5893-49a7-ab32-db180d2ddbb5	d00e4b6c-76fa-467a-97e6-4e351031d391
e6e4a242-5893-49a7-ab32-db180d2ddbb5	c0b3d131-3c9f-4dc9-9859-360dc275e897
e6e4a242-5893-49a7-ab32-db180d2ddbb5	7a32a74e-1b55-418d-9472-ee3e36695e60
e6e4a242-5893-49a7-ab32-db180d2ddbb5	290244be-df46-492c-819d-617dece8daf7
e6e4a242-5893-49a7-ab32-db180d2ddbb5	bb6f890f-de5b-41bd-b0fb-f935781d0a96
e6e4a242-5893-49a7-ab32-db180d2ddbb5	b7517a4f-2858-4f44-85ff-c6d79ba041f9
e6e4a242-5893-49a7-ab32-db180d2ddbb5	e2c5ba70-af1d-4708-a3e2-8c69c148a2a9
e6e4a242-5893-49a7-ab32-db180d2ddbb5	ace1c92f-761f-45a4-b471-8afd38635531
e6e4a242-5893-49a7-ab32-db180d2ddbb5	cf42bd3c-c9fb-4ad4-889f-9335eb168adf
e6e4a242-5893-49a7-ab32-db180d2ddbb5	ec654d02-af3f-42aa-ba76-18d66dda40d6
e6e4a242-5893-49a7-ab32-db180d2ddbb5	b411ea7b-3bef-4040-8641-af4555d689f1
e6e4a242-5893-49a7-ab32-db180d2ddbb5	1393744f-48bc-42f5-a15b-3876261f60d5
e6e4a242-5893-49a7-ab32-db180d2ddbb5	a1c24b6b-e221-4ceb-8456-fe67b9ab9668
e6e4a242-5893-49a7-ab32-db180d2ddbb5	cfe4cba8-1d52-4972-abe6-ce0358182a4c
e6e4a242-5893-49a7-ab32-db180d2ddbb5	26877611-930a-4ad0-bcd9-12bcc984a2e3
e6e4a242-5893-49a7-ab32-db180d2ddbb5	ef2947bd-4588-407c-857d-7bba3a51a17c
e6e4a242-5893-49a7-ab32-db180d2ddbb5	1f108aa1-0615-43e6-ba17-7dc3c94da27e
e6e4a242-5893-49a7-ab32-db180d2ddbb5	ed4587ea-05aa-4f37-8a00-190473641c4c
e6e4a242-5893-49a7-ab32-db180d2ddbb5	496dc810-79e5-44f6-881b-e63c23102a40
e6e4a242-5893-49a7-ab32-db180d2ddbb5	9a57b940-f314-47b3-afc0-c347850a0437
3da7509f-7ccf-48bd-9ccc-f9976386acb2	dd0a8694-9225-4178-ad1f-cb4851ed23e4
e6e4a242-5893-49a7-ab32-db180d2ddbb5	dd0a8694-9225-4178-ad1f-cb4851ed23e4
9277c65f-4541-4aae-ad87-f36f73536398	dd0a8694-9225-4178-ad1f-cb4851ed23e4
e6e4a242-5893-49a7-ab32-db180d2ddbb5	18801b16-9b7f-474a-ac35-1e4e27027701
e6e4a242-5893-49a7-ab32-db180d2ddbb5	88095d45-34e2-41ed-877e-7ff4ea745cd0
7faea9b7-175e-4180-9855-aedf47d9cb9d	18801b16-9b7f-474a-ac35-1e4e27027701
7faea9b7-175e-4180-9855-aedf47d9cb9d	88095d45-34e2-41ed-877e-7ff4ea745cd0
9277c65f-4541-4aae-ad87-f36f73536398	18801b16-9b7f-474a-ac35-1e4e27027701
9277c65f-4541-4aae-ad87-f36f73536398	88095d45-34e2-41ed-877e-7ff4ea745cd0
3da7509f-7ccf-48bd-9ccc-f9976386acb2	da797075-7438-4038-922a-195f98d95805
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, is_system, created_at) FROM stdin;
3da7509f-7ccf-48bd-9ccc-f9976386acb2	SUPER_ADMIN	Super Administrator with full system access	t	2026-07-01 09:05:39.919695+02
e6e4a242-5893-49a7-ab32-db180d2ddbb5	HEAD_TEACHER	Head Teacher	t	2026-07-01 09:05:39.919695+02
7faea9b7-175e-4180-9855-aedf47d9cb9d	DEPUTY_HEAD	Deputy Head Teacher	t	2026-07-01 09:05:39.919695+02
9277c65f-4541-4aae-ad87-f36f73536398	ADMIN	School Administrator	t	2026-07-01 09:05:39.919695+02
03238a37-3b71-4a29-b074-8c113f3a3522	ACCOUNTANT	Accountant - manages fees and finances	t	2026-07-01 09:05:39.919695+02
25b10d0c-c798-43d8-a97b-a07511846148	TEACHER	Teacher	t	2026-07-01 09:05:39.919695+02
b277b9af-a8a8-4044-b5b4-79c335f38198	CLASS_TEACHER	Class Teacher	t	2026-07-01 09:05:39.919695+02
8025954f-13be-4647-b21a-c2a7e59e41f8	PARENT	Parent / Guardian	t	2026-07-01 09:05:39.919695+02
0fbd1b44-a21e-4901-89ab-afc180cbff4c	LIBRARIAN	Librarian	t	2026-07-01 09:05:39.919695+02
82dff047-8100-4c2c-b34b-366156a4ab6b	STORE_OFFICER	Store Officer	t	2026-07-01 09:05:39.919695+02
31057223-f84c-4914-953e-3d8dddb9a0d5	TRANSPORT_OFFICER	Transport Officer	t	2026-07-01 09:05:39.919695+02
82568de7-a209-4a66-a261-4e4e33d301fc	NURSE	School Nurse	t	2026-07-01 09:05:39.919695+02
08fa398e-5bb5-429d-a7ef-346ceb4bed97	SECURITY	Security Officer	t	2026-07-01 09:05:39.919695+02
\.


--
-- Data for Name: school_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.school_settings (id, name, address, city, district, province, country, po_box, postal_code, plot_number, phone, email, website, motto, head_teacher, deputy_head, registration_no, tpin, established_year, currency, logo_url, map_url, latitude, longitude, grading_scale, current_academic_year_id, current_term_id, updated_at, head_teacher_signature_url, banner_url, dashboard_hero_heading, dashboard_hero_subtext, dashboard_hero_image_url, dashboard_button_label, dashboard_button_url, dashboard_links, login_button_label, login_button_url, landing_hero_heading, landing_hero_subtext, landing_hero_images, landing_about_title, landing_about_body, facebook_url) FROM stdin;
1	Chaz Crestview Academy	Lusoke Village, off Kanakantapa Rd, Near Lusoke grounds	Chongwe	\N	\N	Zambia	\N	\N	\N	0977192139 / 0977519221	chazcrestview@gmail.com	http://www.webchazcrestviewacademy.com	For Premium Education	\N	\N	\N	\N	\N	ZMW	\N	https://maps.app.goo.gl/UxrS2LfWo3FDRfbR6	\N	\N	[]	\N	\N	2026-08-25 13:16:28.566459+02	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	\N	[]	\N	\N	https://www.facebook.com/groups/1322917398610798/?ref=share&mibextid=KtfwRi
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff (id, staff_no, full_name, gender, email, phone, address, dob, date_joined, employment_type, is_teacher, basic_salary, qualifications, next_of_kin, bank_name, bank_account, photo_url, status, user_id, created_at, updated_at, role_category, contract_end_date, signature_url) FROM stdin;
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subjects (id, name, code, created_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, contact_person, phone, email, address, tax_no, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: teacher_subjects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teacher_subjects (id, teacher_id, subject_id, class_id) FROM stdin;
\.


--
-- Data for Name: terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terms (id, academic_year_id, name, start_date, end_date, is_current) FROM stdin;
\.


--
-- Data for Name: timetable_slots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.timetable_slots (id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room, created_at) FROM stdin;
\.


--
-- Data for Name: transport_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transport_assignments (id, pupil_id, route_id, pickup_point, active, created_at, pickup_point_id) FROM stdin;
\.


--
-- Data for Name: transport_pickup_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transport_pickup_points (id, route_id, name, fee, created_at) FROM stdin;
\.


--
-- Data for Name: transport_routes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transport_routes (id, name, pickup_points, vehicle_id, fee, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role, created_at) FROM stdin;
a554a63f-2fd6-460c-a713-9ca4898e00d6	f632e9ed-e0f7-4ecd-a6ae-c5f73cdb4c1a	SUPER_ADMIN	2026-07-01 09:20:15.21578+02
f36c1154-d588-4777-a303-1fd4b364abb4	a9fc4aae-2c0d-4f22-b35e-573ee9f02446	PARENT	2026-07-10 17:26:03.943343+02
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicles (id, reg_no, model, capacity, driver_name, driver_phone, notes, created_at, updated_at) FROM stdin;
\.


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: admissions admissions_application_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_application_no_key UNIQUE (application_no);


--
-- Name: admissions admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: app_users app_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_users
    ADD CONSTRAINT app_users_email_key UNIQUE (email);


--
-- Name: app_users app_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_users
    ADD CONSTRAINT app_users_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: canteen_meal_plans canteen_meal_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_meal_plans
    ADD CONSTRAINT canteen_meal_plans_pkey PRIMARY KEY (id);


--
-- Name: canteen_menu_items canteen_menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_menu_items
    ADD CONSTRAINT canteen_menu_items_pkey PRIMARY KEY (id);


--
-- Name: canteen_sales canteen_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_sales
    ADD CONSTRAINT canteen_sales_pkey PRIMARY KEY (id);


--
-- Name: canteen_subscriptions canteen_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_subscriptions
    ADD CONSTRAINT canteen_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: discipline_records discipline_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_records
    ADD CONSTRAINT discipline_records_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: exams exams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: fee_items fee_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fee_items
    ADD CONSTRAINT fee_items_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: gateway_transactions gateway_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_transactions
    ADD CONSTRAINT gateway_transactions_pkey PRIMARY KEY (id);


--
-- Name: gateway_transactions gateway_transactions_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_transactions
    ADD CONSTRAINT gateway_transactions_reference_key UNIQUE (reference);


--
-- Name: guardian_pupils guardian_pupils_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_pupils
    ADD CONSTRAINT guardian_pupils_pkey PRIMARY KEY (id);


--
-- Name: guardians guardians_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardians
    ADD CONSTRAINT guardians_pkey PRIMARY KEY (id);


--
-- Name: health_records health_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_records
    ADD CONSTRAINT health_records_pkey PRIMARY KEY (id);


--
-- Name: homework homework_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homework
    ADD CONSTRAINT homework_pkey PRIMARY KEY (id);


--
-- Name: inquiries inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_txns inventory_txns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_txns
    ADD CONSTRAINT inventory_txns_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_no_key UNIQUE (invoice_no);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: library_books library_books_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_books
    ADD CONSTRAINT library_books_pkey PRIMARY KEY (id);


--
-- Name: library_loans library_loans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_loans
    ADD CONSTRAINT library_loans_pkey PRIMARY KEY (id);


--
-- Name: marks marks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_pkey PRIMARY KEY (id);


--
-- Name: marks marks_pupil_id_exam_id_subject_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_pupil_id_exam_id_subject_id_key UNIQUE (pupil_id, exam_id, subject_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payments payments_receipt_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_no_key UNIQUE (receipt_no);


--
-- Name: payroll_periods payroll_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT payroll_periods_pkey PRIMARY KEY (id);


--
-- Name: payslips payslips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payslips
    ADD CONSTRAINT payslips_pkey PRIMARY KEY (id);


--
-- Name: payslips payslips_staff_id_period_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payslips
    ADD CONSTRAINT payslips_staff_id_period_id_key UNIQUE (staff_id, period_id);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: ptc_meetings ptc_meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ptc_meetings
    ADD CONSTRAINT ptc_meetings_pkey PRIMARY KEY (id);


--
-- Name: ptc_sessions ptc_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ptc_sessions
    ADD CONSTRAINT ptc_sessions_pkey PRIMARY KEY (id);


--
-- Name: pupil_enrollments pupil_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_enrollments
    ADD CONSTRAINT pupil_enrollments_pkey PRIMARY KEY (id);


--
-- Name: pupil_promotions pupil_promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_promotions
    ADD CONSTRAINT pupil_promotions_pkey PRIMARY KEY (id);


--
-- Name: pupils pupils_admission_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupils
    ADD CONSTRAINT pupils_admission_no_key UNIQUE (admission_no);


--
-- Name: pupils pupils_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupils
    ADD CONSTRAINT pupils_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_po_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_po_no_key UNIQUE (po_no);


--
-- Name: report_card_remarks report_card_remarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_card_remarks
    ADD CONSTRAINT report_card_remarks_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: school_settings school_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_settings
    ADD CONSTRAINT school_settings_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff staff_staff_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_staff_no_key UNIQUE (staff_no);


--
-- Name: subjects subjects_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_code_key UNIQUE (code);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: teacher_subjects teacher_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_subjects
    ADD CONSTRAINT teacher_subjects_pkey PRIMARY KEY (id);


--
-- Name: terms terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms
    ADD CONSTRAINT terms_pkey PRIMARY KEY (id);


--
-- Name: timetable_slots timetable_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetable_slots
    ADD CONSTRAINT timetable_slots_pkey PRIMARY KEY (id);


--
-- Name: transport_assignments transport_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_assignments
    ADD CONSTRAINT transport_assignments_pkey PRIMARY KEY (id);


--
-- Name: transport_pickup_points transport_pickup_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_pickup_points
    ADD CONSTRAINT transport_pickup_points_pkey PRIMARY KEY (id);


--
-- Name: transport_routes transport_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_routes
    ADD CONSTRAINT transport_routes_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_reg_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_reg_no_key UNIQUE (reg_no);


--
-- Name: attendance_pupil_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX attendance_pupil_date_idx ON public.attendance USING btree (pupil_id, date);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: gateway_transactions_guardian_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gateway_transactions_guardian_idx ON public.gateway_transactions USING btree (guardian_id);


--
-- Name: gateway_transactions_invoice_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gateway_transactions_invoice_idx ON public.gateway_transactions USING btree (invoice_id);


--
-- Name: guardian_pupils_guardian_pupil_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX guardian_pupils_guardian_pupil_uidx ON public.guardian_pupils USING btree (guardian_id, pupil_id);


--
-- Name: guardians_user_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX guardians_user_id_uidx ON public.guardians USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: idx_app_users_reset_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_app_users_reset_token ON public.app_users USING btree (reset_token) WHERE (reset_token IS NOT NULL);


--
-- Name: idx_purchase_order_items_po; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchase_order_items_po ON public.purchase_order_items USING btree (purchase_order_id);


--
-- Name: idx_transport_pickup_points_route; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transport_pickup_points_route ON public.transport_pickup_points USING btree (route_id);


--
-- Name: pupil_enrollments_active_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pupil_enrollments_active_uidx ON public.pupil_enrollments USING btree (pupil_id) WHERE (ended_on IS NULL);


--
-- Name: pupil_enrollments_pupil_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pupil_enrollments_pupil_idx ON public.pupil_enrollments USING btree (pupil_id);


--
-- Name: pupil_enrollments_year_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pupil_enrollments_year_idx ON public.pupil_enrollments USING btree (academic_year_id);


--
-- Name: pupil_promotions_pupil_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pupil_promotions_pupil_idx ON public.pupil_promotions USING btree (pupil_id, promoted_on DESC);


--
-- Name: report_card_remarks_pupil_term_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX report_card_remarks_pupil_term_idx ON public.report_card_remarks USING btree (pupil_id, term_id);


--
-- Name: admissions admissions_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE SET NULL;


--
-- Name: admissions admissions_target_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admissions
    ADD CONSTRAINT admissions_target_class_id_fkey FOREIGN KEY (target_class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: attendance attendance_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: attendance attendance_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: canteen_sales canteen_sales_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_sales
    ADD CONSTRAINT canteen_sales_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.canteen_menu_items(id) ON DELETE SET NULL;


--
-- Name: canteen_sales canteen_sales_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_sales
    ADD CONSTRAINT canteen_sales_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE SET NULL;


--
-- Name: canteen_sales canteen_sales_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_sales
    ADD CONSTRAINT canteen_sales_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE SET NULL;


--
-- Name: canteen_subscriptions canteen_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_subscriptions
    ADD CONSTRAINT canteen_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.canteen_meal_plans(id) ON DELETE CASCADE;


--
-- Name: canteen_subscriptions canteen_subscriptions_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_subscriptions
    ADD CONSTRAINT canteen_subscriptions_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: canteen_subscriptions canteen_subscriptions_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.canteen_subscriptions
    ADD CONSTRAINT canteen_subscriptions_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON DELETE SET NULL;


--
-- Name: classes classes_class_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_class_teacher_id_fkey FOREIGN KEY (class_teacher_id) REFERENCES public.staff(id) ON DELETE SET NULL;


--
-- Name: discipline_records discipline_records_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_records
    ADD CONSTRAINT discipline_records_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: documents documents_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: documents documents_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: events events_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: exams exams_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON DELETE SET NULL;


--
-- Name: fee_items fee_items_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fee_items
    ADD CONSTRAINT fee_items_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: fee_items fee_items_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fee_items
    ADD CONSTRAINT fee_items_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON DELETE SET NULL;


--
-- Name: gateway_transactions gateway_transactions_guardian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_transactions
    ADD CONSTRAINT gateway_transactions_guardian_id_fkey FOREIGN KEY (guardian_id) REFERENCES public.guardians(id) ON DELETE SET NULL;


--
-- Name: gateway_transactions gateway_transactions_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_transactions
    ADD CONSTRAINT gateway_transactions_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: gateway_transactions gateway_transactions_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_transactions
    ADD CONSTRAINT gateway_transactions_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id) ON DELETE SET NULL;


--
-- Name: guardian_pupils guardian_pupils_guardian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_pupils
    ADD CONSTRAINT guardian_pupils_guardian_id_fkey FOREIGN KEY (guardian_id) REFERENCES public.guardians(id) ON DELETE CASCADE;


--
-- Name: guardian_pupils guardian_pupils_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_pupils
    ADD CONSTRAINT guardian_pupils_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: guardians guardians_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardians
    ADD CONSTRAINT guardians_user_id_fk FOREIGN KEY (user_id) REFERENCES public.app_users(id) ON DELETE SET NULL;


--
-- Name: health_records health_records_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_records
    ADD CONSTRAINT health_records_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: homework homework_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homework
    ADD CONSTRAINT homework_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: homework homework_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homework
    ADD CONSTRAINT homework_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE SET NULL;


--
-- Name: inventory_items inventory_items_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: inventory_txns inventory_txns_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_txns
    ADD CONSTRAINT inventory_txns_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.inventory_items(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_fee_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_fee_item_id_fkey FOREIGN KEY (fee_item_id) REFERENCES public.fee_items(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON DELETE SET NULL;


--
-- Name: leave_requests leave_requests_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: library_loans library_loans_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_loans
    ADD CONSTRAINT library_loans_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.library_books(id) ON DELETE CASCADE;


--
-- Name: library_loans library_loans_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_loans
    ADD CONSTRAINT library_loans_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE SET NULL;


--
-- Name: library_loans library_loans_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_loans
    ADD CONSTRAINT library_loans_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE SET NULL;


--
-- Name: marks marks_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exams(id) ON DELETE CASCADE;


--
-- Name: marks marks_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: marks marks_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: messages messages_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: payments payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: payments payments_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: payments payments_submitted_by_guardian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_submitted_by_guardian_id_fkey FOREIGN KEY (submitted_by_guardian_id) REFERENCES public.guardians(id) ON DELETE SET NULL;


--
-- Name: payslips payslips_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payslips
    ADD CONSTRAINT payslips_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.payroll_periods(id) ON DELETE CASCADE;


--
-- Name: payslips payslips_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payslips
    ADD CONSTRAINT payslips_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: ptc_meetings ptc_meetings_guardian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ptc_meetings
    ADD CONSTRAINT ptc_meetings_guardian_id_fkey FOREIGN KEY (guardian_id) REFERENCES public.guardians(id) ON DELETE CASCADE;


--
-- Name: ptc_meetings ptc_meetings_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ptc_meetings
    ADD CONSTRAINT ptc_meetings_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE SET NULL;


--
-- Name: ptc_meetings ptc_meetings_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ptc_meetings
    ADD CONSTRAINT ptc_meetings_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.ptc_sessions(id) ON DELETE CASCADE;


--
-- Name: ptc_meetings ptc_meetings_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ptc_meetings
    ADD CONSTRAINT ptc_meetings_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: ptc_sessions ptc_sessions_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ptc_sessions
    ADD CONSTRAINT ptc_sessions_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON DELETE SET NULL;


--
-- Name: pupil_enrollments pupil_enrollments_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_enrollments
    ADD CONSTRAINT pupil_enrollments_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE SET NULL;


--
-- Name: pupil_enrollments pupil_enrollments_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_enrollments
    ADD CONSTRAINT pupil_enrollments_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE RESTRICT;


--
-- Name: pupil_enrollments pupil_enrollments_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_enrollments
    ADD CONSTRAINT pupil_enrollments_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: pupil_promotions pupil_promotions_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_promotions
    ADD CONSTRAINT pupil_promotions_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE SET NULL;


--
-- Name: pupil_promotions pupil_promotions_from_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_promotions
    ADD CONSTRAINT pupil_promotions_from_class_id_fkey FOREIGN KEY (from_class_id) REFERENCES public.classes(id) ON DELETE RESTRICT;


--
-- Name: pupil_promotions pupil_promotions_promoted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_promotions
    ADD CONSTRAINT pupil_promotions_promoted_by_fkey FOREIGN KEY (promoted_by) REFERENCES public.app_users(id) ON DELETE SET NULL;


--
-- Name: pupil_promotions pupil_promotions_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_promotions
    ADD CONSTRAINT pupil_promotions_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: pupil_promotions pupil_promotions_to_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupil_promotions
    ADD CONSTRAINT pupil_promotions_to_class_id_fkey FOREIGN KEY (to_class_id) REFERENCES public.classes(id) ON DELETE RESTRICT;


--
-- Name: pupils pupils_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pupils
    ADD CONSTRAINT pupils_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.inventory_items(id);


--
-- Name: purchase_order_items purchase_order_items_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: report_card_remarks report_card_remarks_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_card_remarks
    ADD CONSTRAINT report_card_remarks_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: report_card_remarks report_card_remarks_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_card_remarks
    ADD CONSTRAINT report_card_remarks_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: teacher_subjects teacher_subjects_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_subjects
    ADD CONSTRAINT teacher_subjects_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: teacher_subjects teacher_subjects_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_subjects
    ADD CONSTRAINT teacher_subjects_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: teacher_subjects teacher_subjects_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_subjects
    ADD CONSTRAINT teacher_subjects_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: terms terms_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms
    ADD CONSTRAINT terms_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE CASCADE;


--
-- Name: timetable_slots timetable_slots_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetable_slots
    ADD CONSTRAINT timetable_slots_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: timetable_slots timetable_slots_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetable_slots
    ADD CONSTRAINT timetable_slots_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE SET NULL;


--
-- Name: timetable_slots timetable_slots_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetable_slots
    ADD CONSTRAINT timetable_slots_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.staff(id) ON DELETE SET NULL;


--
-- Name: transport_assignments transport_assignments_pickup_point_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_assignments
    ADD CONSTRAINT transport_assignments_pickup_point_id_fkey FOREIGN KEY (pickup_point_id) REFERENCES public.transport_pickup_points(id) ON DELETE SET NULL;


--
-- Name: transport_assignments transport_assignments_pupil_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_assignments
    ADD CONSTRAINT transport_assignments_pupil_id_fkey FOREIGN KEY (pupil_id) REFERENCES public.pupils(id) ON DELETE CASCADE;


--
-- Name: transport_assignments transport_assignments_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_assignments
    ADD CONSTRAINT transport_assignments_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.transport_routes(id) ON DELETE CASCADE;


--
-- Name: transport_pickup_points transport_pickup_points_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_pickup_points
    ADD CONSTRAINT transport_pickup_points_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.transport_routes(id) ON DELETE CASCADE;


--
-- Name: transport_routes transport_routes_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_routes
    ADD CONSTRAINT transport_routes_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE SET NULL;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.app_users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict pietQanvXflMzOBoeetumatoExUlN3UkjJ8LHIRy1bdJHqq7ciByXWGZLOTB9Ei

